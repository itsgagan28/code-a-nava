const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const Sale = require('../models/Sale');
const Purchase = require('../models/Purchase');
const Supplier = require('../models/Supplier');
const auth = require('../middleware/auth');

router.get('/stats', auth, async (req, res) => {
  try {
    const today = new Date();
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const startOfLastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
    const endOfLastMonth = new Date(today.getFullYear(), today.getMonth(), 0);

    // Product stats
    const totalProducts = await Product.countDocuments({ isActive: true });
    const allProducts = await Product.find({ isActive: true });
    const lowStockItems = allProducts.filter(p => p.stock <= p.minStockLevel).length;
    const outOfStockItems = allProducts.filter(p => p.stock === 0).length;
    const totalInventoryValue = allProducts.reduce((sum, p) => sum + p.stock * p.costPrice, 0);

    // Sales stats
    const currentMonthSales = await Sale.find({ createdAt: { $gte: startOfMonth }, status: 'completed' });
    const lastMonthSales = await Sale.find({
      createdAt: { $gte: startOfLastMonth, $lte: endOfLastMonth },
      status: 'completed'
    });

    const currentRevenue = currentMonthSales.reduce((sum, s) => sum + s.total, 0);
    const lastRevenue = lastMonthSales.reduce((sum, s) => sum + s.total, 0);
    const revenueGrowth = lastRevenue > 0 ? ((currentRevenue - lastRevenue) / lastRevenue * 100).toFixed(1) : 0;

    // Recent sales
    const recentSales = await Sale.find()
      .populate('items.product', 'name')
      .sort({ createdAt: -1 })
      .limit(5);

    // Sales chart (last 7 days)
    const salesChart = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dayStart = new Date(date.setHours(0, 0, 0, 0));
      const dayEnd = new Date(date.setHours(23, 59, 59, 999));

      const daySales = await Sale.find({
        createdAt: { $gte: dayStart, $lte: dayEnd },
        status: 'completed'
      });

      salesChart.push({
        date: dayStart.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }),
        revenue: daySales.reduce((sum, s) => sum + s.total, 0),
        orders: daySales.length
      });
    }

    // Top products by sales
    const allSales = await Sale.find({ status: 'completed' }).populate('items.product', 'name');
    const productSales = {};
    allSales.forEach(sale => {
      sale.items.forEach(item => {
        const pid = item.product?._id?.toString();
        if (pid) {
          productSales[pid] = productSales[pid] || { name: item.product.name, qty: 0, revenue: 0 };
          productSales[pid].qty += item.quantity;
          productSales[pid].revenue += item.total;
        }
      });
    });
    const topProducts = Object.values(productSales)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);

    // Suppliers count
    const totalSuppliers = await Supplier.countDocuments({ isActive: true });

    res.json({
      totalProducts,
      lowStockItems,
      outOfStockItems,
      totalInventoryValue,
      currentRevenue,
      revenueGrowth,
      totalOrders: currentMonthSales.length,
      totalSuppliers,
      recentSales,
      salesChart,
      topProducts
    });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
