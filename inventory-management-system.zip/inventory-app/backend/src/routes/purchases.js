const express = require('express');
const router = express.Router();
const Purchase = require('../models/Purchase');
const Product = require('../models/Product');
const auth = require('../middleware/auth');

router.get('/', auth, async (req, res) => {
  try {
    const purchases = await Purchase.find()
      .populate('supplier', 'name')
      .populate('items.product', 'name sku')
      .sort({ createdAt: -1 });
    res.json(purchases);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

router.post('/', auth, async (req, res) => {
  try {
    const count = await Purchase.countDocuments();
    const purchaseNumber = `PO-${String(count + 1).padStart(5, '0')}`;

    const purchase = new Purchase({ ...req.body, purchaseNumber, createdBy: req.user.id });
    await purchase.save();

    // Update stock if received
    if (purchase.status === 'received') {
      for (const item of purchase.items) {
        await Product.findByIdAndUpdate(item.product, { $inc: { stock: item.quantity } });
      }
    }

    res.status(201).json(purchase);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

router.put('/:id/status', auth, async (req, res) => {
  try {
    const purchase = await Purchase.findById(req.params.id);
    if (!purchase) return res.status(404).json({ message: 'Purchase not found' });

    if (req.body.status === 'received' && purchase.status !== 'received') {
      for (const item of purchase.items) {
        await Product.findByIdAndUpdate(item.product, { $inc: { stock: item.quantity } });
      }
    }

    purchase.status = req.body.status;
    await purchase.save();
    res.json(purchase);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
