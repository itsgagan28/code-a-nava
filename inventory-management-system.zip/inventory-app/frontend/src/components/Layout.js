import React, { useState } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Layout() {
  const { user, logout } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { to: '/', label: 'Home' },
    { to: '/about', label: 'About' },
    { to: '/services', label: 'Our Services' },
    { to: '/our-products', label: 'Our Products' },
    { to: '/contact', label: 'Contact' },
  ];

  return (
    <div style={{ fontFamily: "'Syne', sans-serif", minHeight: '100vh' }}>
      <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet" />
      <style>{`
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #0a0a0f; color: #e8e8f0; }
        .nav { position: fixed; top: 0; width: 100%; z-index: 100; background: rgba(10,10,15,0.9); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(255,255,255,0.06); }
        .nav-inner { max-width: 1280px; margin: 0 auto; padding: 0 2rem; height: 70px; display: flex; align-items: center; justify-content: space-between; }
        .logo { font-size: 1.4rem; font-weight: 800; color: #fff; text-decoration: none; letter-spacing: -0.03em; }
        .logo span { color: #6c63ff; }
        .nav-links { display: flex; gap: 2rem; list-style: none; align-items: center; }
        .nav-links a { color: #aaa; text-decoration: none; font-size: 0.9rem; font-weight: 500; transition: color 0.2s; font-family: 'DM Sans', sans-serif; }
        .nav-links a:hover, .nav-links a.active { color: #fff; }
        .nav-cta { background: #6c63ff; color: #fff !important; padding: 0.5rem 1.2rem; border-radius: 8px; font-weight: 600 !important; }
        .nav-cta:hover { background: #5a52e0; }
        .main { padding-top: 70px; }
        .hamburger { display: none; background: none; border: none; cursor: pointer; color: #fff; }
        @media (max-width: 768px) {
          .nav-links { display: none; }
          .hamburger { display: block; }
        }
        .loading-screen { display: flex; align-items: center; justify-content: center; height: 100vh; background: #0a0a0f; }
        .spinner { width: 40px; height: 40px; border: 3px solid rgba(108,99,255,0.3); border-top-color: #6c63ff; border-radius: 50%; animation: spin 0.8s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>

      <nav className="nav">
        <div className="nav-inner">
          <Link to="/" className="logo">Stock<span>Sync</span></Link>
          <ul className="nav-links">
            {navLinks.map(link => (
              <li key={link.to}>
                <Link to={link.to} className={location.pathname === link.to ? 'active' : ''}>
                  {link.label}
                </Link>
              </li>
            ))}
            {user ? (
              <>
                <li><Link to="/dashboard" className="nav-cta">Dashboard</Link></li>
                <li><button onClick={logout} style={{ background: 'none', border: '1px solid #444', color: '#aaa', padding: '0.4rem 1rem', borderRadius: '8px', cursor: 'pointer', fontFamily: 'DM Sans', fontSize: '0.9rem' }}>Logout</button></li>
              </>
            ) : (
              <li><Link to="/login" className="nav-cta">Login</Link></li>
            )}
          </ul>
        </div>
      </nav>

      <main className="main">
        <Outlet />
      </main>

      <footer style={{ background: '#050508', borderTop: '1px solid rgba(255,255,255,0.06)', padding: '3rem 2rem', textAlign: 'center', fontFamily: 'DM Sans', color: '#666', fontSize: '0.9rem' }}>
        <div style={{ marginBottom: '1rem', fontFamily: 'Syne', fontWeight: 700, fontSize: '1.2rem', color: '#fff' }}>
          Stock<span style={{ color: '#6c63ff' }}>Sync</span>
        </div>
        <p>© {new Date().getFullYear()} StockSync Inventory Management. All rights reserved.</p>
      </footer>
    </div>
  );
}
