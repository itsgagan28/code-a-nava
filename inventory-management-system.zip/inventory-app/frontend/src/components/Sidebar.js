import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const navItems = [
  { to: '/dashboard', icon: '⬡', label: 'Dashboard' },
  { to: '/inventory', icon: '📦', label: 'Inventory' },
  { to: '/sales', icon: '💰', label: 'Sales' },
  { to: '/purchases', icon: '🛒', label: 'Purchases' },
  { to: '/suppliers', icon: '🚚', label: 'Suppliers' },
];

export default function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <aside style={{
      width: 240, flexShrink: 0, background: '#0d0d14', borderRight: '1px solid rgba(255,255,255,0.06)',
      display: 'flex', flexDirection: 'column', height: '100vh', position: 'sticky', top: 0
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap');
        .sb-logo{padding:1.5rem 1.5rem 1rem;font-family:'Syne';font-size:1.3rem;font-weight:800;color:#fff;border-bottom:1px solid rgba(255,255,255,0.06)}
        .sb-logo span{color:#6c63ff}
        .sb-nav{flex:1;padding:1rem 0.75rem;overflow-y:auto}
        .sb-link{display:flex;align-items:center;gap:0.75rem;padding:0.75rem 1rem;border-radius:10px;text-decoration:none;color:#666;font-family:'DM Sans';font-size:0.9rem;font-weight:500;transition:all 0.2s;margin-bottom:0.2rem}
        .sb-link:hover{background:rgba(255,255,255,0.05);color:#ccc}
        .sb-link.active{background:rgba(108,99,255,0.15);color:#fff;border:1px solid rgba(108,99,255,0.25)}
        .sb-icon{font-size:1rem;width:20px;text-align:center}
        .sb-user{padding:1rem 1.5rem;border-top:1px solid rgba(255,255,255,0.06)}
        .sb-username{font-family:'Syne';font-weight:700;color:#fff;font-size:0.9rem}
        .sb-role{font-size:0.75rem;color:#555;font-family:'DM Sans';text-transform:capitalize;margin-bottom:0.75rem}
        .sb-logout{background:none;border:1px solid rgba(255,255,255,0.1);color:#666;padding:0.5rem 1rem;border-radius:8px;cursor:pointer;font-family:'DM Sans';font-size:0.85rem;width:100%;transition:all 0.2s}
        .sb-logout:hover{background:rgba(255,59,48,0.1);border-color:rgba(255,59,48,0.3);color:#ff3b30}
        .sb-section{font-size:0.7rem;color:#444;text-transform:uppercase;letter-spacing:0.1em;font-family:'DM Sans';padding:0.75rem 1rem 0.3rem;font-weight:600}
      `}</style>
      <div className="sb-logo">Stock<span>Sync</span></div>
      <nav className="sb-nav">
        <div className="sb-section">Menu</div>
        {navItems.map(item => (
          <Link key={item.to} to={item.to} className={`sb-link ${location.pathname === item.to ? 'active' : ''}`}>
            <span className="sb-icon">{item.icon}</span>
            {item.label}
          </Link>
        ))}
      </nav>
      <div className="sb-user">
        <div className="sb-username">{user?.name}</div>
        <div className="sb-role">{user?.role}</div>
        <button className="sb-logout" onClick={handleLogout}>Logout</button>
      </div>
    </aside>
  );
}
