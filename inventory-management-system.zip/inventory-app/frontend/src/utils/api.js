import axios from 'axios';

const API = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:5000/api',
});

API.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

API.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

export const authAPI = {
  login: (data) => API.post('/auth/login', data),
  register: (data) => API.post('/auth/register', data),
  me: () => API.get('/auth/me'),
};

export const productsAPI = {
  getAll: (params) => API.get('/products', { params }),
  getOne: (id) => API.get(`/products/${id}`),
  create: (data) => API.post('/products', data),
  update: (id, data) => API.put(`/products/${id}`, data),
  delete: (id) => API.delete(`/products/${id}`),
  getCategories: () => API.get('/products/meta/categories'),
};

export const suppliersAPI = {
  getAll: () => API.get('/suppliers'),
  create: (data) => API.post('/suppliers', data),
  update: (id, data) => API.put(`/suppliers/${id}`, data),
  delete: (id) => API.delete(`/suppliers/${id}`),
};

export const salesAPI = {
  getAll: (params) => API.get('/sales', { params }),
  getOne: (id) => API.get(`/sales/${id}`),
  create: (data) => API.post('/sales', data),
  updateStatus: (id, status) => API.put(`/sales/${id}/status`, { status }),
};

export const purchasesAPI = {
  getAll: () => API.get('/purchases'),
  create: (data) => API.post('/purchases', data),
  updateStatus: (id, status) => API.put(`/purchases/${id}/status`, { status }),
};

export const dashboardAPI = {
  getStats: () => API.get('/dashboard/stats'),
};

export default API;
