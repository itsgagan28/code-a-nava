import React, { useState, useEffect } from 'react';
import { purchasesAPI, productsAPI, suppliersAPI } from '../utils/api';
import Sidebar from '../components/Sidebar';
import toast from 'react-hot-toast';

export default function Purchases() {
  const [purchases, setPurchases] = useState([]);
  const [products, setProducts] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ supplier: '', paymentMethod: 'transfer', status: 'received', items: [{ product: '', quantity: 1, costPrice: 0 }], notes: '' });

  const load = async () => {
    try {
      const [p, prod, sup] = await Promise.all([purchasesAPI.getAll(), productsAPI.getAll(), suppliersAPI.getAll()]);
      setPurchases(p.data); setProducts(prod.data); setSuppliers(sup.data);
    } catch (e) { toast.error('Failed to load') }
    finally { setLoading(false) }
  };

  useEffect(() => { load(); }, []);

  const addItem = () => setForm(f => ({ ...f, items: [...f.items, { product: '', quantity: 1, costPrice: 0 }] }));
  const removeItem = (i) => setForm(f => ({ ...f, items: f.items.filter((_, idx) => idx !== i) }));

  const updateItem = (i, field, val) => {
    const items = [...form.items];
    items[i] = { ...items[i], [field]: val };
    if (field === 'product') {
      const prod = products.find(p => p._id === val);
      if (prod) items[i].costPrice = prod.costPrice;
    }
    setForm(f => ({ ...f, items }));
  };

  const calcTotal = () => form.items.reduce((s, item) => s + (item.quantity * item.costPrice || 0), 0);

  const handleSubmit = async () => {
    try {
      const items = form.items.map(it => ({ product: it.product, quantity: Number(it.quantity), costPrice: Number(it.costPrice), total: it.quantity * it.costPrice }));
      const subtotal = items.reduce((s, it) => s + it.total, 0);
      await purchasesAPI.create({ ...form, items, subtotal, total: subtotal });
      toast.success('Purchase order created!');
      setShowModal(false);
      setForm({ supplier: '', paymentMethod: 'transfer', status: 'received', items: [{ product: '', quantity: 1, costPrice: 0 }], notes: '' });
      load();
    } catch (e) { toast.error(e.response?.data?.message || 'Error') }
  };

  const statusColor = (s) => ({ received: '#48c78e', pending: '#f59e0b', cancelled: '#ff6b6b' }[s] || '#666');

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#0a0a0f' }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap');
        .p-table{width:100%;border-collapse:collapse}
        .p-table th{text-align:left;padding:0.75rem 1rem;font-size:0.75rem;color:#555;font-family:'DM Sans';text-transform:uppercase;letter-spacing:0.05em;border-bottom:1px solid rgba(255,255,255,0.06)}
        .p-table td{padding:0.9rem 1rem;border-bottom:1px solid rgba(255,255,255,0.04);color:#ccc;font-family:'DM Sans';font-size:0.9rem}
        .p-table tr:hover td{background:rgba(255,255,255,0.02)}
        .badge{padding:0.2rem 0.7rem;border-radius:20px;font-size:0.75rem;font-weight:600}
        .modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.8);display:flex;align-items:center;justify-content:center;z-index:1000;padding:1rem}
        .modal{background:#111118;border:1px solid rgba(255,255,255,0.1);border-radius:20px;padding:2rem;width:100%;max-width:600px;max-height:90vh;overflow-y:auto}
        .m-label{display:block;color:#888;font-size:0.8rem;margin-bottom:0.4rem;font-weight:500;font-family:'DM Sans'}
        .m-input{width:100%;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:0.7rem 0.9rem;color:#fff;font-family:'DM Sans';font-size:0.9rem;outline:none;box-sizing:border-box}
        .m-input:focus{border-color:#6c63ff}
        .item-row{display:grid;grid-template-columns:3fr 1fr 1fr auto;gap:0.5rem;margin-bottom:0.5rem;align-items:center}
        .add-btn{background:#6c63ff;color:#fff;border:none;padding:0.7rem 1.5rem;border-radius:10px;font-family:'DM Sans';font-weight:600;cursor:pointer;margin-left:auto;font-size:0.9rem}
      `}</style>
      <Sidebar />
      <div style={{ flex: 1, padding: '2rem', overflowY: 'auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '2rem' }}>
          <div>
            <h1 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '1.8rem', color: '#fff', letterSpacing: '-0.03em', marginBottom: '0.3rem' }}>Purchases</h1>
            <p style={{ color: '#555', fontSize: '0.9rem' }}>{purchases.length} purchase orders</p>
          </div>
          <button className="add-btn" onClick={() => setShowModal(true)}>+ New Purchase</button>
        </div>

        <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 16, overflow: 'hidden' }}>
          {loading ? <div style={{ textAlign: 'center', padding: '4rem', color: '#444' }}>Loading...</div>
          : purchases.length === 0 ? <div style={{ textAlign: 'center', padding: '4rem', color: '#444' }}>No purchase orders yet.</div>
          : (
            <table className="p-table">
              <thead><tr><th>PO Number</th><th>Supplier</th><th>Items</th><th>Total Cost</th><th>Payment</th><th>Status</th><th>Date</th></tr></thead>
              <tbody>
                {purchases.map(p => (
                  <tr key={p._id}>
                    <td style={{ color: '#6c63ff', fontFamily: 'monospace', fontWeight: 600 }}>{p.purchaseNumber}</td>
                    <td style={{ color: '#fff' }}>{p.supplier?.name || '—'}</td>
                    <td style={{ color: '#888' }}>{p.items.length} item{p.items.length !== 1 ? 's' : ''}</td>
                    <td style={{ color: '#f59e0b', fontFamily: 'Syne', fontWeight: 700 }}>${p.total.toFixed(2)}</td>
                    <td style={{ textTransform: 'capitalize', color: '#888' }}>{p.paymentMethod}</td>
                    <td><span className="badge" style={{ background: `${statusColor(p.status)}20`, color: statusColor(p.status) }}>{p.status}</span></td>
                    <td style={{ color: '#555' }}>{new Date(p.createdAt).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal">
            <div style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '1.3rem', color: '#fff', marginBottom: '1.5rem' }}>New Purchase Order</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
              <div>
                <label className="m-label">Supplier *</label>
                <select className="m-input" value={form.supplier} onChange={e => setForm({ ...form, supplier: e.target.value })}>
                  <option value="">Select supplier</option>
                  {suppliers.map(s => <option key={s._id} value={s._id}>{s.name}</option>)}
                </select>
              </div>
              <div>
                <label className="m-label">Status</label>
                <select className="m-input" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                  <option value="received">Received</option><option value="pending">Pending</option>
                </select>
              </div>
            </div>

            <div style={{ marginBottom: '1.5rem' }}>
              <label className="m-label">Payment Method</label>
              <select className="m-input" value={form.paymentMethod} onChange={e => setForm({ ...form, paymentMethod: e.target.value })}>
                <option value="transfer">Transfer</option><option value="cash">Cash</option><option value="card">Card</option>
              </select>
            </div>

            <div style={{ marginBottom: '1rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                <span style={{ fontFamily: 'Syne', fontWeight: 700, color: '#fff', fontSize: '0.95rem' }}>Items</span>
                <button onClick={addItem} style={{ background: 'rgba(108,99,255,0.15)', border: '1px solid rgba(108,99,255,0.3)', color: '#9d97ff', padding: '0.3rem 0.8rem', borderRadius: 6, cursor: 'pointer', fontSize: '0.8rem' }}>+ Add Item</button>
              </div>
              {form.items.map((item, i) => (
                <div className="item-row" key={i}>
                  <select className="m-input" value={item.product} onChange={e => updateItem(i, 'product', e.target.value)}>
                    <option value="">Select product</option>
                    {products.map(p => <option key={p._id} value={p._id}>{p.name}</option>)}
                  </select>
                  <input className="m-input" type="number" min="1" value={item.quantity} onChange={e => updateItem(i, 'quantity', Number(e.target.value))} placeholder="Qty" />
                  <input className="m-input" type="number" value={item.costPrice} onChange={e => updateItem(i, 'costPrice', Number(e.target.value))} placeholder="Cost" />
                  <button onClick={() => removeItem(i)} style={{ background: 'none', border: 'none', color: '#ff6b6b', cursor: 'pointer', fontSize: '1.2rem' }}>×</button>
                </div>
              ))}
            </div>

            <div style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.2)', borderRadius: 10, padding: '1rem', marginBottom: '1.5rem', display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: '#888' }}>Total Cost</span>
              <span style={{ fontFamily: 'Syne', fontWeight: 800, color: '#f59e0b', fontSize: '1.2rem' }}>${calcTotal().toFixed(2)}</span>
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end' }}>
              <button onClick={() => setShowModal(false)} style={{ padding: '0.7rem 1.5rem', borderRadius: 10, border: '1px solid rgba(255,255,255,0.1)', background: 'rgba(255,255,255,0.05)', color: '#aaa', cursor: 'pointer', fontFamily: 'DM Sans' }}>Cancel</button>
              <button onClick={handleSubmit} style={{ padding: '0.7rem 1.5rem', borderRadius: 10, border: 'none', background: '#6c63ff', color: '#fff', cursor: 'pointer', fontFamily: 'DM Sans', fontWeight: 600 }}>Create Order</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
