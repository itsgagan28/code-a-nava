import React from 'react';
import { Link } from 'react-router-dom';

const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');
  .hero { min-height: calc(100vh - 70px); display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden; padding: 4rem 2rem; }
  .hero-bg { position: absolute; inset: 0; background: radial-gradient(ellipse 80% 60% at 50% 0%, rgba(108,99,255,0.15) 0%, transparent 60%), radial-gradient(ellipse 40% 40% at 80% 80%, rgba(99,179,255,0.08) 0%, transparent 50%); }
  .hero-grid { position: absolute; inset: 0; background-image: linear-gradient(rgba(108,99,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(108,99,255,0.05) 1px, transparent 1px); background-size: 60px 60px; }
  .hero-content { position: relative; text-align: center; max-width: 800px; }
  .hero-badge { display: inline-block; background: rgba(108,99,255,0.15); border: 1px solid rgba(108,99,255,0.3); color: #9d97ff; padding: 0.4rem 1.2rem; border-radius: 100px; font-size: 0.85rem; font-family: 'DM Sans'; margin-bottom: 2rem; }
  .hero-title { font-size: clamp(3rem, 7vw, 6rem); font-weight: 800; line-height: 1.0; letter-spacing: -0.04em; color: #fff; margin-bottom: 1.5rem; }
  .hero-title .accent { color: #6c63ff; }
  .hero-subtitle { font-family: 'DM Sans'; font-size: 1.2rem; color: #888; line-height: 1.7; max-width: 560px; margin: 0 auto 3rem; font-weight: 300; }
  .hero-buttons { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }
  .btn-primary { background: #6c63ff; color: #fff; padding: 0.9rem 2.2rem; border-radius: 12px; text-decoration: none; font-weight: 600; font-size: 1rem; transition: all 0.2s; display: inline-block; }
  .btn-primary:hover { background: #5a52e0; transform: translateY(-2px); box-shadow: 0 8px 30px rgba(108,99,255,0.4); }
  .btn-secondary { background: rgba(255,255,255,0.05); color: #ccc; padding: 0.9rem 2.2rem; border-radius: 12px; text-decoration: none; font-weight: 500; font-size: 1rem; border: 1px solid rgba(255,255,255,0.1); transition: all 0.2s; display: inline-block; }
  .btn-secondary:hover { background: rgba(255,255,255,0.1); color: #fff; }
  .stats-bar { background: rgba(255,255,255,0.03); border-top: 1px solid rgba(255,255,255,0.06); border-bottom: 1px solid rgba(255,255,255,0.06); }
  .stats-inner { max-width: 1100px; margin: 0 auto; padding: 3rem 2rem; display: grid; grid-template-columns: repeat(4, 1fr); gap: 2rem; text-align: center; }
  .stat-num { font-size: 2.5rem; font-weight: 800; color: #6c63ff; letter-spacing: -0.03em; }
  .stat-label { font-family: 'DM Sans'; color: #666; font-size: 0.9rem; margin-top: 0.3rem; }
  .features { max-width: 1100px; margin: 0 auto; padding: 6rem 2rem; }
  .section-label { font-family: 'DM Sans'; color: #6c63ff; font-size: 0.85rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 1rem; }
  .section-title { font-size: 2.5rem; font-weight: 800; letter-spacing: -0.03em; color: #fff; margin-bottom: 1rem; }
  .section-subtitle { font-family: 'DM Sans'; color: #666; font-size: 1.05rem; max-width: 500px; }
  .features-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; margin-top: 4rem; }
  .feature-card { background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.07); border-radius: 16px; padding: 2rem; transition: all 0.3s; }
  .feature-card:hover { background: rgba(108,99,255,0.08); border-color: rgba(108,99,255,0.3); transform: translateY(-4px); }
  .feature-icon { width: 48px; height: 48px; background: rgba(108,99,255,0.15); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; margin-bottom: 1.2rem; }
  .feature-title { font-size: 1.1rem; font-weight: 700; color: #fff; margin-bottom: 0.6rem; }
  .feature-desc { font-family: 'DM Sans'; color: #777; font-size: 0.9rem; line-height: 1.6; }
  @media (max-width: 768px) { .stats-inner { grid-template-columns: repeat(2, 1fr); } .features-grid { grid-template-columns: 1fr; } }
`;

const features = [
  { icon: '📦', title: 'Real-time Inventory', desc: 'Track stock levels in real-time with instant alerts when items fall below minimum thresholds.' },
  { icon: '📊', title: 'Analytics Dashboard', desc: 'Visualize revenue trends, top-selling products, and business performance at a glance.' },
  { icon: '🛒', title: 'Sales Management', desc: 'Record, track and manage all customer sales with invoice generation and payment tracking.' },
  { icon: '🚚', title: 'Purchase Orders', desc: 'Manage supplier purchases, track delivery status, and automatically update stock on receipt.' },
  { icon: '⚠️', title: 'Low Stock Alerts', desc: 'Get instant notifications when products fall below minimum stock levels to avoid stockouts.' },
  { icon: '📋', title: 'Reports & Export', desc: 'Generate detailed reports on sales, purchases, and inventory for informed decision-making.' },
];

export default function Home() {
  return (
    <>
      <style>{styles}</style>
      <section className="hero">
        <div className="hero-bg" />
        <div className="hero-grid" />
        <div className="hero-content">
          <div className="hero-badge">🚀 Full-Stack Inventory Solution</div>
          <h1 className="hero-title">
            Manage Stock<br />
            <span className="accent">Smarter.</span>
          </h1>
          <p className="hero-subtitle">
            A powerful inventory management platform for modern businesses. Track products, manage suppliers, monitor sales—all in one place.
          </p>
          <div className="hero-buttons">
            <Link to="/login" className="btn-primary">Get Started Free</Link>
            <Link to="/about" className="btn-secondary">Learn More</Link>
          </div>
        </div>
      </section>

      <div className="stats-bar">
        <div className="stats-inner">
          {[['10K+', 'Products Managed'], ['500+', 'Businesses'], ['99.9%', 'Uptime'], ['24/7', 'Support']].map(([num, label]) => (
            <div key={label}>
              <div className="stat-num">{num}</div>
              <div className="stat-label">{label}</div>
            </div>
          ))}
        </div>
      </div>

      <section className="features">
        <div className="section-label">Features</div>
        <h2 className="section-title">Everything you need to run your inventory</h2>
        <p className="section-subtitle">Built for shop owners who need a reliable, easy-to-use system to manage their entire business.</p>
        <div className="features-grid">
          {features.map(f => (
            <div className="feature-card" key={f.title}>
              <div className="feature-icon">{f.icon}</div>
              <div className="feature-title">{f.title}</div>
              <div className="feature-desc">{f.desc}</div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
