import React, { useState, useEffect } from 'react';
import { productsAPI, suppliersAPI } from '../utils/api';
import Sidebar from '../components/Sidebar';
import toast from 'react-hot-toast';

const emptyProduct = { name: '', sku: '', category: '', description: '', price: '', costPrice: '', stock: '', minStockLevel: 10, supplier: '', unit: 'pcs' };

export default function Inventory() {
  const [products, setProducts] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [form, setForm] = useState(emptyProduct);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  const load = async () => {
    try {
      const params = {};
      if (search) params.search = search;
      if (filter === 'low') params.lowStock = true;
      const [prods, sups] = await Promise.all([productsAPI.getAll(params), suppliersAPI.getAll()]);
      setProducts(prods.data);
      setSuppliers(sups.data);
    } catch (e) { toast.error('Failed to load') }
    finally { setLoading(false) }
  };

  useEffect(() => { load(); }, [search, filter]);

  const openAdd = () => { setForm(emptyProduct); setEditProduct(null); setShowModal(true); };
  const openEdit = (p) => { setForm({ ...p, supplier: p.supplier?._id || p.supplier || '' }); setEditProduct(p._id); setShowModal(true); };

  const handleSave = async () => {
    try {
      if (editProduct) await productsAPI.update(editProduct, form);
      else await productsAPI.create(form);
      toast.success(editProduct ? 'Product updated' : 'Product created');
      setShowModal(false);
      load();
    } catch (e) { toast.error(e.response?.data?.message || 'Error saving') }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this product?')) return;
    try { await productsAPI.delete(id); toast.success('Deleted'); load(); }
    catch (e) { toast.error('Failed to delete') }
  };

  const statusColor = (p) => {
    if (p.stock === 0) return '#ff6b6b';
    if (p.stock <= p.minStockLevel) return '#f59e0b';
    return '#48c78e';
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#0a0a0f' }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap');
        .inv-table{width:100%;border-collapse:collapse}
        .inv-table th{text-align:left;padding:0.75rem 1rem;font-size:0.75rem;color:#555;font-family:'DM Sans';text-transform:uppercase;letter-spacing:0.05em;border-bottom:1px solid rgba(255,255,255,0.06)}
        .inv-table td{padding:0.9rem 1rem;border-bottom:1px solid rgba(255,255,255,0.04);color:#ccc;font-family:'DM Sans';font-size:0.9rem}
        .inv-table tr:hover td{background:rgba(255,255,255,0.02)}
        .badge{padding:0.2rem 0.7rem;border-radius:20px;font-size:0.75rem;font-weight:600}
        .modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.8);display:flex;align-items:center;justify-content:center;z-index:1000;padding:1rem}
        .modal{background:#111118;border:1px solid rgba(255,255,255,0.1);border-radius:20px;padding:2rem;width:100%;max-width:560px;max-height:90vh;overflow-y:auto}
        .m-title{font-family:'Syne';font-weight:800;font-size:1.3rem;color:#fff;margin-bottom:1.5rem}
        .m-grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
        .m-field{margin-bottom:1rem}
        .m-label{display:block;color:#888;font-size:0.8rem;margin-bottom:0.4rem;font-weight:500;font-family:'DM Sans'}
        .m-input{width:100%;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:0.7rem 0.9rem;color:#fff;font-family:'DM Sans';font-size:0.9rem;outline:none;box-sizing:border-box;transition:border 0.2s}
        .m-input:focus{border-color:#6c63ff}
        .m-input::placeholder{color:#555}
        .m-btn{padding:0.7rem 1.5rem;border-radius:10px;border:none;cursor:pointer;font-family:'DM Sans';font-size:0.9rem;font-weight:600;transition:all 0.2s}
        .btn-prim{background:#6c63ff;color:#fff}.btn-prim:hover{background:#5a52e0}
        .btn-ghost{background:rgba(255,255,255,0.06);color:#aaa;border:1px solid rgba(255,255,255,0.1)}.btn-ghost:hover{background:rgba(255,255,255,0.1)}
        .action-btn{background:none;border:none;cursor:pointer;padding:0.3rem 0.6rem;border-radius:6px;font-size:0.8rem;transition:all 0.2s}
        .top-bar{display:flex;gap:1rem;align-items:center;flex-wrap:wrap}
        .search-inp{background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:0.7rem 1rem;color:#fff;font-family:'DM Sans';font-size:0.9rem;outline:none;min-width:240px}
        .search-inp:focus{border-color:#6c63ff}
        .filter-tabs{display:flex;gap:0.5rem}
        .f-tab{padding:0.5rem 1rem;border-radius:8px;border:1px solid rgba(255,255,255,0.1);background:none;color:#666;cursor:pointer;font-family:'DM Sans';font-size:0.85rem;transition:all 0.2s}
        .f-tab.active{background:rgba(108,99,255,0.15);border-color:rgba(108,99,255,0.3);color:#9d97ff}
        .add-btn{background:#6c63ff;color:#fff;border:none;padding:0.7rem 1.5rem;border-radius:10px;font-family:'DM Sans';font-weight:600;cursor:pointer;margin-left:auto;font-size:0.9rem}
        .add-btn:hover{background:#5a52e0}
      `}</style>
      <Sidebar />
      <div style={{ flex: 1, padding: '2rem', overflowY: 'auto' }}>
        <div style={{ marginBottom: '2rem' }}>
          <h1 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '1.8rem', color: '#fff', letterSpacing: '-0.03em', marginBottom: '0.3rem' }}>Inventory</h1>
          <p style={{ color: '#555', fontSize: '0.9rem' }}>{products.length} products total</p>
        </div>

        <div className="top-bar" style={{ marginBottom: '1.5rem' }}>
          <input className="search-inp" placeholder="🔍  Search products..." value={search} onChange={e => setSearch(e.target.value)} />
          <div className="filter-tabs">
            {[['all', 'All'], ['low', '⚠️ Low Stock']].map(([val, label]) => (
              <button key={val} className={`f-tab ${filter === val ? 'active' : ''}`} onClick={() => setFilter(val)}>{label}</button>
            ))}
          </div>
          <button className="add-btn" onClick={openAdd}>+ Add Product</button>
        </div>

        <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 16, overflow: 'hidden' }}>
          {loading ? (
            <div style={{ textAlign: 'center', padding: '4rem', color: '#444' }}>Loading...</div>
          ) : products.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '4rem', color: '#444' }}>No products found. Add your first product.</div>
          ) : (
            <table className="inv-table">
              <thead><tr><th>Product</th><th>SKU</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th>Supplier</th><th>Actions</th></tr></thead>
              <tbody>
                {products.map(p => (
                  <tr key={p._id}>
                    <td><div style={{ color: '#fff', fontWeight: 600 }}>{p.name}</div><div style={{ color: '#555', fontSize: '0.75rem' }}>{p.unit}</div></td>
                    <td style={{ color: '#6c63ff', fontFamily: 'monospace' }}>{p.sku}</td>
                    <td>{p.category}</td>
                    <td style={{ color: '#48c78e', fontFamily: 'Syne', fontWeight: 700 }}>${p.price}</td>
                    <td style={{ fontWeight: 600 }}>{p.stock}</td>
                    <td>
                      <span className="badge" style={{ background: `${statusColor(p)}20`, color: statusColor(p) }}>
                        {p.stock === 0 ? 'Out of Stock' : p.stock <= p.minStockLevel ? 'Low Stock' : 'In Stock'}
                      </span>
                    </td>
                    <td style={{ color: '#666' }}>{p.supplier?.name || '—'}</td>
                    <td>
                      <button className="action-btn" style={{ color: '#6c63ff' }} onClick={() => openEdit(p)}>Edit</button>
                      <button className="action-btn" style={{ color: '#ff6b6b' }} onClick={() => handleDelete(p._id)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal">
            <div className="m-title">{editProduct ? 'Edit Product' : 'Add New Product'}</div>
            <div className="m-grid">
              {[['name', 'Product Name', 'text'], ['sku', 'SKU', 'text'], ['category', 'Category', 'text'], ['unit', 'Unit', 'text'], ['price', 'Selling Price', 'number'], ['costPrice', 'Cost Price', 'number'], ['stock', 'Current Stock', 'number'], ['minStockLevel', 'Min Stock Level', 'number']].map(([key, label, type]) => (
                <div className="m-field" key={key}>
                  <label className="m-label">{label}</label>
                  <input className="m-input" type={type} value={form[key]} onChange={e => setForm({ ...form, [key]: e.target.value })} placeholder={label} />
                </div>
              ))}
            </div>
            <div className="m-field">
              <label className="m-label">Supplier</label>
              <select className="m-input" value={form.supplier} onChange={e => setForm({ ...form, supplier: e.target.value })}>
                <option value="">Select supplier</option>
                {suppliers.map(s => <option key={s._id} value={s._id}>{s.name}</option>)}
              </select>
            </div>
            <div className="m-field">
              <label className="m-label">Description</label>
              <textarea className="m-input" rows={2} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Optional description" style={{ resize: 'none' }} />
            </div>
            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '0.5rem' }}>
              <button className="m-btn btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="m-btn btn-prim" onClick={handleSave}>Save Product</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
