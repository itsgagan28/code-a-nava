import React, { useState, useEffect } from 'react';
import { suppliersAPI } from '../utils/api';
import Sidebar from '../components/Sidebar';
import toast from 'react-hot-toast';

const emptySupplier = { name: '', email: '', phone: '', address: '', company: '', contactPerson: '' };

export default function Suppliers() {
  const [suppliers, setSuppliers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState(emptySupplier);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      const res = await suppliersAPI.getAll();
      setSuppliers(res.data);
    } catch (e) { toast.error('Failed to load') }
    finally { setLoading(false) }
  };

  useEffect(() => { load(); }, []);

  const openAdd = () => { setForm(emptySupplier); setEditId(null); setShowModal(true); };
  const openEdit = (s) => { setForm(s); setEditId(s._id); setShowModal(true); };

  const handleSave = async () => {
    try {
      if (editId) await suppliersAPI.update(editId, form);
      else await suppliersAPI.create(form);
      toast.success(editId ? 'Supplier updated' : 'Supplier added');
      setShowModal(false);
      load();
    } catch (e) { toast.error('Error saving') }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Remove this supplier?')) return;
    try { await suppliersAPI.delete(id); toast.success('Removed'); load(); }
    catch (e) { toast.error('Failed') }
  };

  const initials = (name) => name?.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2) || '?';
  const colors = ['#6c63ff', '#48c78e', '#f59e0b', '#ff6b6b', '#63b3ff', '#ed64a6'];
  const color = (name) => colors[(name?.charCodeAt(0) || 0) % colors.length];

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#0a0a0f' }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap');
        .sup-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.5rem}
        .sup-card{background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:16px;padding:1.5rem;transition:all 0.2s}
        .sup-card:hover{background:rgba(255,255,255,0.05);border-color:rgba(255,255,255,0.12)}
        .sup-avatar{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-family:'Syne';font-weight:800;font-size:1rem;color:#fff;margin-bottom:1rem}
        .sup-name{font-family:'Syne';font-weight:700;color:#fff;font-size:1rem;margin-bottom:0.2rem}
        .sup-company{color:#555;font-size:0.8rem;margin-bottom:1rem}
        .sup-info{display:flex;flex-direction:column;gap:0.4rem;margin-bottom:1rem}
        .sup-info-row{display:flex;gap:0.5rem;color:#666;font-size:0.8rem;align-items:center}
        .sup-actions{display:flex;gap:0.5rem}
        .s-btn{flex:1;border-radius:8px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.04);color:#888;cursor:pointer;padding:0.5rem;font-size:0.8rem;font-family:'DM Sans';transition:all 0.2s}
        .s-btn:hover{background:rgba(255,255,255,0.08);color:#ccc}
        .s-btn.del:hover{background:rgba(255,107,107,0.1);border-color:rgba(255,107,107,0.3);color:#ff6b6b}
        .modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.8);display:flex;align-items:center;justify-content:center;z-index:1000;padding:1rem}
        .modal{background:#111118;border:1px solid rgba(255,255,255,0.1);border-radius:20px;padding:2rem;width:100%;max-width:480px}
        .m-label{display:block;color:#888;font-size:0.8rem;margin-bottom:0.4rem;font-family:'DM Sans'}
        .m-input{width:100%;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:0.7rem 0.9rem;color:#fff;font-family:'DM Sans';font-size:0.9rem;outline:none;box-sizing:border-box;margin-bottom:1rem}
        .m-input:focus{border-color:#6c63ff}
        .add-btn{background:#6c63ff;color:#fff;border:none;padding:0.7rem 1.5rem;border-radius:10px;font-family:'DM Sans';font-weight:600;cursor:pointer;font-size:0.9rem}
        @media(max-width:768px){.sup-grid{grid-template-columns:1fr}}
      `}</style>
      <Sidebar />
      <div style={{ flex: 1, padding: '2rem', overflowY: 'auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '2rem' }}>
          <div>
            <h1 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '1.8rem', color: '#fff', letterSpacing: '-0.03em', marginBottom: '0.3rem' }}>Suppliers</h1>
            <p style={{ color: '#555', fontSize: '0.9rem' }}>{suppliers.length} active suppliers</p>
          </div>
          <button className="add-btn" onClick={openAdd}>+ Add Supplier</button>
        </div>

        {loading ? <div style={{ textAlign: 'center', padding: '4rem', color: '#444' }}>Loading...</div>
        : suppliers.length === 0 ? <div style={{ textAlign: 'center', padding: '4rem', color: '#444' }}>No suppliers yet. Add your first supplier!</div>
        : (
          <div className="sup-grid">
            {suppliers.map(s => (
              <div className="sup-card" key={s._id}>
                <div className="sup-avatar" style={{ background: `${color(s.name)}20`, color: color(s.name) }}>{initials(s.name)}</div>
                <div className="sup-name">{s.name}</div>
                <div className="sup-company">{s.company || 'Independent'}</div>
                <div className="sup-info">
                  {s.email && <div className="sup-info-row"><span>📧</span><span>{s.email}</span></div>}
                  {s.phone && <div className="sup-info-row"><span>📞</span><span>{s.phone}</span></div>}
                  {s.contactPerson && <div className="sup-info-row"><span>👤</span><span>{s.contactPerson}</span></div>}
                  {s.address && <div className="sup-info-row"><span>📍</span><span>{s.address}</span></div>}
                </div>
                <div className="sup-actions">
                  <button className="s-btn" onClick={() => openEdit(s)}>Edit</button>
                  <button className="s-btn del" onClick={() => handleDelete(s._id)}>Remove</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal">
            <div style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '1.3rem', color: '#fff', marginBottom: '1.5rem' }}>{editId ? 'Edit Supplier' : 'Add Supplier'}</div>
            {[['name', 'Name *'], ['email', 'Email *'], ['phone', 'Phone'], ['company', 'Company'], ['contactPerson', 'Contact Person'], ['address', 'Address']].map(([key, label]) => (
              <div key={key}>
                <label className="m-label">{label}</label>
                <input className="m-input" value={form[key] || ''} onChange={e => setForm({ ...form, [key]: e.target.value })} placeholder={label} />
              </div>
            ))}
            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end' }}>
              <button onClick={() => setShowModal(false)} style={{ padding: '0.7rem 1.5rem', borderRadius: 10, border: '1px solid rgba(255,255,255,0.1)', background: 'rgba(255,255,255,0.05)', color: '#aaa', cursor: 'pointer', fontFamily: 'DM Sans' }}>Cancel</button>
              <button onClick={handleSave} style={{ padding: '0.7rem 1.5rem', borderRadius: 10, border: 'none', background: '#6c63ff', color: '#fff', cursor: 'pointer', fontFamily: 'DM Sans', fontWeight: 600 }}>Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
