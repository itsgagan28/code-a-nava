import React, { useState, useEffect } from 'react';
import { dashboardAPI } from '../utils/api';
import Sidebar from '../components/Sidebar';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const StatCard = ({ icon, title, value, subtitle, accent }) => (
  <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 16, padding: '1.5rem' }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
      <div style={{ fontSize: '1.5rem' }}>{icon}</div>
      {subtitle && <span style={{ fontSize: '0.75rem', color: accent === 'green' ? '#48c78e' : accent === 'red' ? '#ff6b6b' : '#6c63ff', background: accent === 'green' ? 'rgba(72,199,142,0.1)' : accent === 'red' ? 'rgba(255,107,107,0.1)' : 'rgba(108,99,255,0.1)', padding: '0.2rem 0.6rem', borderRadius: 20 }}>{subtitle}</span>}
    </div>
    <div style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '2rem', color: '#fff', letterSpacing: '-0.03em' }}>{value}</div>
    <div style={{ color: '#555', fontSize: '0.85rem', fontFamily: 'DM Sans', marginTop: '0.3rem' }}>{title}</div>
  </div>
);

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dashboardAPI.getStats()
      .then(res => setStats(res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const fmt = (n) => n >= 1000 ? `$${(n / 1000).toFixed(1)}k` : `$${n?.toFixed(2) || '0.00'}`;

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#0a0a0f', fontFamily: "'DM Sans', sans-serif" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap');`}</style>
      <Sidebar />
      <div style={{ flex: 1, padding: '2rem', overflowY: 'auto' }}>
        <div style={{ marginBottom: '2rem' }}>
          <h1 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '1.8rem', color: '#fff', letterSpacing: '-0.03em' }}>Dashboard</h1>
          <p style={{ color: '#555', fontFamily: 'DM Sans', marginTop: '0.3rem' }}>Welcome back. Here's what's happening.</p>
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '4rem', color: '#444' }}>Loading analytics...</div>
        ) : (
          <>
            {/* Stats Grid */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1rem', marginBottom: '2rem' }}>
              <StatCard icon="📦" title="Total Products" value={stats?.totalProducts || 0} />
              <StatCard icon="💰" title="Monthly Revenue" value={fmt(stats?.currentRevenue)} subtitle={`${stats?.revenueGrowth}%`} accent={stats?.revenueGrowth > 0 ? 'green' : 'red'} />
              <StatCard icon="⚠️" title="Low Stock Items" value={stats?.lowStockItems || 0} subtitle="Needs attention" accent="red" />
              <StatCard icon="🛒" title="Monthly Orders" value={stats?.totalOrders || 0} />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1.5rem', marginBottom: '2rem' }}>
              {/* Revenue Chart */}
              <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 16, padding: '1.5rem' }}>
                <h3 style={{ fontFamily: 'Syne', fontWeight: 700, color: '#fff', marginBottom: '1.5rem', fontSize: '1rem' }}>Revenue (Last 7 Days)</h3>
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={stats?.salesChart || []}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis dataKey="date" tick={{ fill: '#555', fontSize: 11 }} tickLine={false} axisLine={false} />
                    <YAxis tick={{ fill: '#555', fontSize: 11 }} tickLine={false} axisLine={false} tickFormatter={v => `$${v}`} />
                    <Tooltip contentStyle={{ background: '#1a1a2e', border: '1px solid rgba(108,99,255,0.3)', borderRadius: 8, color: '#fff' }} formatter={v => [`$${v}`, 'Revenue']} />
                    <Line type="monotone" dataKey="revenue" stroke="#6c63ff" strokeWidth={2.5} dot={{ fill: '#6c63ff', r: 4 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Top Products */}
              <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 16, padding: '1.5rem' }}>
                <h3 style={{ fontFamily: 'Syne', fontWeight: 700, color: '#fff', marginBottom: '1.5rem', fontSize: '1rem' }}>Top Products</h3>
                {stats?.topProducts?.length > 0 ? stats.topProducts.map((p, i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.6rem 0', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                    <div>
                      <div style={{ color: '#ccc', fontSize: '0.85rem' }}>{p.name}</div>
                      <div style={{ color: '#555', fontSize: '0.75rem' }}>{p.qty} units sold</div>
                    </div>
                    <div style={{ color: '#6c63ff', fontFamily: 'Syne', fontWeight: 700, fontSize: '0.95rem' }}>{fmt(p.revenue)}</div>
                  </div>
                )) : <div style={{ color: '#444', fontSize: '0.9rem', textAlign: 'center', padding: '2rem 0' }}>No sales data yet</div>}
              </div>
            </div>

            {/* Inventory alerts + recent sales */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.5fr', gap: '1.5rem' }}>
              <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 16, padding: '1.5rem' }}>
                <h3 style={{ fontFamily: 'Syne', fontWeight: 700, color: '#fff', marginBottom: '1.2rem', fontSize: '1rem' }}>Inventory Summary</h3>
                {[
                  ['Total Products', stats?.totalProducts, '#fff'],
                  ['Low Stock', stats?.lowStockItems, '#f59e0b'],
                  ['Out of Stock', stats?.outOfStockItems, '#ff6b6b'],
                  ['Inventory Value', fmt(stats?.totalInventoryValue), '#48c78e'],
                  ['Total Suppliers', stats?.totalSuppliers, '#6c63ff'],
                ].map(([label, val, color]) => (
                  <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.6rem 0', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                    <span style={{ color: '#666', fontSize: '0.85rem' }}>{label}</span>
                    <span style={{ color, fontWeight: 600, fontFamily: 'Syne', fontSize: '0.9rem' }}>{val}</span>
                  </div>
                ))}
              </div>

              <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 16, padding: '1.5rem' }}>
                <h3 style={{ fontFamily: 'Syne', fontWeight: 700, color: '#fff', marginBottom: '1.2rem', fontSize: '1rem' }}>Recent Sales</h3>
                {stats?.recentSales?.length > 0 ? stats.recentSales.map((sale, i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.7rem 0', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                    <div>
                      <div style={{ color: '#ccc', fontSize: '0.85rem', fontWeight: 600 }}>{sale.invoiceNumber}</div>
                      <div style={{ color: '#555', fontSize: '0.75rem' }}>{sale.customer}</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ color: '#48c78e', fontFamily: 'Syne', fontWeight: 700 }}>{fmt(sale.total)}</div>
                      <div style={{ color: '#555', fontSize: '0.75rem' }}>{new Date(sale.createdAt).toLocaleDateString()}</div>
                    </div>
                  </div>
                )) : <div style={{ color: '#444', fontSize: '0.9rem', textAlign: 'center', padding: '2rem 0' }}>No recent sales</div>}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
