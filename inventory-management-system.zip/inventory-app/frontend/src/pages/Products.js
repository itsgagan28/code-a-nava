import React from 'react';
import { Link } from 'react-router-dom';

const sampleProducts = [
  { name: 'Smart LED Bulb Pack', category: 'Electronics', price: '$24.99', stock: 150, icon: '💡' },
  { name: 'Ergonomic Office Chair', category: 'Furniture', price: '$349.00', stock: 23, icon: '🪑' },
  { name: 'Wireless Headphones', category: 'Electronics', price: '$89.99', stock: 67, icon: '🎧' },
  { name: 'Stainless Water Bottle', category: 'Lifestyle', price: '$18.50', stock: 200, icon: '🍶' },
  { name: 'Organic Coffee Beans 1kg', category: 'Food & Beverage', price: '$32.00', stock: 85, icon: '☕' },
  { name: 'Yoga Mat Premium', category: 'Sports', price: '$45.00', stock: 42, icon: '🧘' },
];

export default function Products() {
  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', padding: '6rem 2rem', fontFamily: "'DM Sans', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap');
        .p-badge{display:inline-block;background:rgba(108,99,255,0.15);border:1px solid rgba(108,99,255,0.3);color:#9d97ff;padding:0.4rem 1.2rem;border-radius:100px;font-size:0.85rem;margin-bottom:1.5rem}
        .p-title{font-family:'Syne',sans-serif;font-size:clamp(2.5rem,5vw,4rem);font-weight:800;color:#fff;letter-spacing:-0.03em;margin-bottom:1rem}
        .p-sub{color:#777;font-size:1.05rem;line-height:1.7;max-width:500px;margin-bottom:4rem}
        .p-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.5rem;margin-bottom:4rem}
        .p-card{background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:20px;padding:2rem;transition:all 0.3s}
        .p-card:hover{background:rgba(255,255,255,0.05);transform:translateY(-4px);border-color:rgba(255,255,255,0.12)}
        .p-emoji{font-size:3rem;margin-bottom:1rem}
        .p-cat{font-size:0.8rem;color:#6c63ff;font-weight:600;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:0.5rem}
        .p-name{font-family:'Syne';font-weight:700;color:#fff;font-size:1.1rem;margin-bottom:1rem}
        .p-bottom{display:flex;justify-content:space-between;align-items:center}
        .p-price{font-size:1.3rem;font-weight:700;color:#6c63ff;font-family:'Syne'}
        .p-stock{color:#666;font-size:0.85rem}
        .cta-box{background:linear-gradient(135deg,rgba(108,99,255,0.15),rgba(99,179,255,0.08));border:1px solid rgba(108,99,255,0.2);border-radius:20px;padding:3rem;text-align:center}
        .cta-title{font-family:'Syne';font-size:2rem;font-weight:800;color:#fff;margin-bottom:1rem}
        .cta-sub{color:#777;margin-bottom:2rem;font-size:1rem}
        .cta-btn{background:#6c63ff;color:#fff;padding:0.9rem 2rem;border-radius:12px;text-decoration:none;font-weight:600;display:inline-block;transition:all 0.2s}
        .cta-btn:hover{background:#5a52e0;transform:translateY(-2px)}
        @media(max-width:768px){.p-grid{grid-template-columns:1fr}}
      `}</style>
      <span className="p-badge">Our Products</span>
      <h1 className="p-title">Products we help you manage</h1>
      <p className="p-sub">From electronics to groceries, StockSync handles inventory for every business type. Here's a sample of what our customers track.</p>

      <div className="p-grid">
        {sampleProducts.map(p => (
          <div className="p-card" key={p.name}>
            <div className="p-emoji">{p.icon}</div>
            <div className="p-cat">{p.category}</div>
            <div className="p-name">{p.name}</div>
            <div className="p-bottom">
              <div className="p-price">{p.price}</div>
              <div className="p-stock">{p.stock} units</div>
            </div>
          </div>
        ))}
      </div>

      <div className="cta-box">
        <div className="cta-title">Ready to manage your inventory?</div>
        <div className="cta-sub">Sign up and start tracking your products in minutes.</div>
        <Link to="/login" className="cta-btn">Start for Free →</Link>
      </div>
    </div>
  );
}
