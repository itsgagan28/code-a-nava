import React from 'react';

const services = [
  { icon: '📦', title: 'Inventory Management', price: 'Core', desc: 'Add, edit, and monitor all your products. Set minimum stock levels and receive automatic low-stock alerts.', features: ['Unlimited products', 'Stock tracking', 'Category management', 'SKU system', 'Barcode support'] },
  { icon: '💰', title: 'Sales Management', price: 'Core', desc: 'Record customer sales, generate invoices, and track payment statuses in real-time.', features: ['Invoice generation', 'Multi-payment methods', 'Customer records', 'Sales history', 'Revenue reports'] },
  { icon: '🚚', title: 'Purchase Management', price: 'Core', desc: 'Create purchase orders, track deliveries from suppliers, and auto-update inventory on receipt.', features: ['Purchase orders', 'Supplier management', 'Auto stock update', 'Delivery tracking', 'Cost analytics'] },
  { icon: '📊', title: 'Analytics & Reports', price: 'Pro', desc: 'Detailed insights into sales trends, best-selling products, and business performance over time.', features: ['Revenue charts', 'Top products', 'Sales comparison', 'Export to PDF/CSV', 'Custom date ranges'] },
  { icon: '👥', title: 'Multi-user Access', price: 'Pro', desc: 'Manage your team with role-based access—admins see everything, staff only see what they need.', features: ['Role-based access', 'Admin panel', 'Activity logs', 'User management', 'Permissions'] },
  { icon: '☁️', title: 'Cloud & Sync', price: 'All', desc: 'Everything stored securely in the cloud. Access your inventory from any device, anywhere.', features: ['Real-time sync', 'Auto backups', 'Cross-device access', '99.9% uptime', 'Data encryption'] },
];

export default function Services() {
  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', padding: '6rem 2rem', fontFamily: "'DM Sans', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap');
        .s-badge{display:inline-block;background:rgba(108,99,255,0.15);border:1px solid rgba(108,99,255,0.3);color:#9d97ff;padding:0.4rem 1.2rem;border-radius:100px;font-size:0.85rem;margin-bottom:1.5rem}
        .s-title{font-family:'Syne',sans-serif;font-size:clamp(2.5rem,5vw,4rem);font-weight:800;color:#fff;letter-spacing:-0.03em;margin-bottom:1rem;line-height:1.1}
        .s-sub{color:#777;font-size:1.05rem;line-height:1.7;max-width:560px;margin-bottom:4rem}
        .sv-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.5rem}
        .sv-card{background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:20px;padding:2rem;transition:all 0.3s}
        .sv-card:hover{background:rgba(108,99,255,0.08);border-color:rgba(108,99,255,0.3);transform:translateY(-4px)}
        .sv-icon{font-size:2.5rem;margin-bottom:1rem}
        .sv-tag{display:inline-block;background:rgba(108,99,255,0.2);color:#9d97ff;padding:0.2rem 0.7rem;border-radius:20px;font-size:0.75rem;font-weight:600;margin-bottom:1rem}
        .sv-name{font-family:'Syne';font-weight:700;font-size:1.2rem;color:#fff;margin-bottom:0.7rem}
        .sv-desc{color:#777;font-size:0.9rem;line-height:1.6;margin-bottom:1.5rem}
        .sv-feat{list-style:none;padding:0}
        .sv-feat li{color:#aaa;font-size:0.85rem;padding:0.3rem 0;display:flex;align-items:center;gap:0.5rem}
        .sv-feat li::before{content:'✓';color:#6c63ff;font-weight:700}
        @media(max-width:900px){.sv-grid{grid-template-columns:repeat(2,1fr)}}
        @media(max-width:600px){.sv-grid{grid-template-columns:1fr}}
      `}</style>
      <span className="s-badge">Our Services</span>
      <h1 className="s-title">Powerful tools for<br />modern inventory</h1>
      <p className="s-sub">Everything a shop owner needs to manage products, track sales, handle suppliers and get actionable business insights.</p>
      <div className="sv-grid">
        {services.map(s => (
          <div className="sv-card" key={s.title}>
            <div className="sv-icon">{s.icon}</div>
            <div className="sv-tag">{s.price}</div>
            <div className="sv-name">{s.title}</div>
            <div className="sv-desc">{s.desc}</div>
            <ul className="sv-feat">
              {s.features.map(f => <li key={f}>{f}</li>)}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
