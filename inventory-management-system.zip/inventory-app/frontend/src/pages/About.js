import React from 'react';

export default function About() {
  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: '6rem 2rem', fontFamily: "'DM Sans', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap');
        .about-badge { display:inline-block; background:rgba(108,99,255,0.15); border:1px solid rgba(108,99,255,0.3); color:#9d97ff; padding:0.4rem 1.2rem; border-radius:100px; font-size:0.85rem; margin-bottom:1.5rem; }
        .about-title { font-family:'Syne',sans-serif; font-size:clamp(2.5rem,5vw,4rem); font-weight:800; color:#fff; letter-spacing:-0.03em; margin-bottom:1.5rem; line-height:1.1; }
        .about-lead { font-size:1.15rem; color:#888; line-height:1.8; margin-bottom:3rem; font-weight:300; }
        .team-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:1.5rem; margin-top:4rem; }
        .team-card { background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.07); border-radius:16px; padding:2rem; text-align:center; }
        .team-avatar { width:72px; height:72px; border-radius:50%; background:linear-gradient(135deg,#6c63ff,#63b3ff); display:flex; align-items:center; justify-content:center; font-size:1.8rem; margin:0 auto 1rem; }
        .team-name { font-family:'Syne'; font-weight:700; color:#fff; margin-bottom:0.3rem; }
        .team-role { color:#666; font-size:0.85rem; }
        .value-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:1.5rem; margin-top:2rem; }
        .value-card { background:rgba(108,99,255,0.05); border:1px solid rgba(108,99,255,0.15); border-radius:12px; padding:1.5rem; }
        .value-title { font-family:'Syne'; font-weight:700; color:#9d97ff; margin-bottom:0.5rem; }
        .value-desc { color:#777; font-size:0.9rem; line-height:1.6; }
        @media(max-width:768px){.team-grid{grid-template-columns:1fr}.value-grid{grid-template-columns:1fr}}
      `}</style>
      <span className="about-badge">About Us</span>
      <h1 className="about-title">Built for businesses<br />that mean business.</h1>
      <p className="about-lead">
        StockSync was created to solve the real challenges shop owners face every day—messy spreadsheets, lost orders, and stock surprises. We built a modern, simple, and powerful inventory management platform so you can focus on growing your business.
      </p>

      <h2 style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '1.8rem', color: '#fff', marginBottom: '1rem' }}>Our Values</h2>
      <div className="value-grid">
        {[
          ['Simplicity', 'Complex problems deserve clean solutions. Every feature is designed to be intuitive from day one.'],
          ['Reliability', 'Your business depends on accurate data. We prioritize uptime, data integrity, and performance.'],
          ['Transparency', 'Clear pricing, clear data, clear reporting. No hidden costs or confusing metrics.'],
          ['Growth', 'As your business scales, StockSync scales with you—from a single store to multiple locations.'],
        ].map(([title, desc]) => (
          <div className="value-card" key={title}>
            <div className="value-title">{title}</div>
            <div className="value-desc">{desc}</div>
          </div>
        ))}
      </div>

      <h2 style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '1.8rem', color: '#fff', margin: '4rem 0 0.5rem' }}>Meet the Team</h2>
      <div className="team-grid">
        {[['👨‍💻', 'Alex Chen', 'CEO & Founder'], ['👩‍🎨', 'Sara Kim', 'Head of Design'], ['👨‍⚙️', 'Raj Patel', 'Lead Engineer']].map(([avatar, name, role]) => (
          <div className="team-card" key={name}>
            <div className="team-avatar">{avatar}</div>
            <div className="team-name">{name}</div>
            <div className="team-role">{role}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
