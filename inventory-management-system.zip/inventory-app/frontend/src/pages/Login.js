import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function Login() {
  const [isRegister, setIsRegister] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'admin' });
  const [loading, setLoading] = useState(false);
  const { login, register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isRegister) {
        await register(form);
        toast.success('Account created!');
      } else {
        await login(form.email, form.password);
        toast.success('Welcome back!');
      }
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: '#0a0a0f', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem', fontFamily: "'DM Sans', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap');
        .login-card{background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:24px;padding:3rem;width:100%;max-width:440px}
        .login-logo{font-family:'Syne';font-size:1.5rem;font-weight:800;color:#fff;text-align:center;margin-bottom:0.5rem}
        .login-logo span{color:#6c63ff}
        .login-sub{color:#666;text-align:center;margin-bottom:2.5rem;font-size:0.95rem}
        .l-label{display:block;color:#888;font-size:0.85rem;margin-bottom:0.5rem;font-weight:500}
        .l-input{width:100%;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:0.9rem 1rem;color:#fff;font-family:'DM Sans';font-size:0.95rem;outline:none;transition:border 0.2s;box-sizing:border-box}
        .l-input:focus{border-color:#6c63ff;background:rgba(108,99,255,0.05)}
        .l-input::placeholder{color:#555}
        .l-btn{width:100%;background:#6c63ff;color:#fff;border:none;padding:1rem;border-radius:12px;font-size:1rem;font-weight:600;cursor:pointer;font-family:'Syne';transition:all 0.2s;margin-top:1rem}
        .l-btn:hover:not(:disabled){background:#5a52e0;transform:translateY(-1px)}
        .l-btn:disabled{opacity:0.6;cursor:not-allowed}
        .l-switch{text-align:center;margin-top:1.5rem;color:#666;font-size:0.9rem}
        .l-switch button{background:none;border:none;color:#6c63ff;cursor:pointer;font-family:'DM Sans';font-size:0.9rem;font-weight:600}
        .l-divider{height:1px;background:rgba(255,255,255,0.07);margin:2rem 0;position:relative}
        .field{margin-bottom:1.2rem}
        .demo-hint{background:rgba(108,99,255,0.08);border:1px solid rgba(108,99,255,0.2);border-radius:10px;padding:1rem;margin-bottom:1.5rem;font-size:0.85rem;color:#9d97ff;text-align:center}
      `}</style>

      <div className="login-card">
        <Link to="/" style={{ textDecoration: 'none' }}>
          <div className="login-logo">Stock<span>Sync</span></div>
        </Link>
        <div className="login-sub">{isRegister ? 'Create your account' : 'Sign in to your dashboard'}</div>

        {!isRegister && (
          <div className="demo-hint">
            Demo: register a new account to get started
          </div>
        )}

        <form onSubmit={handleSubmit}>
          {isRegister && (
            <div className="field">
              <label className="l-label">Full Name</label>
              <input className="l-input" placeholder="Your name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
            </div>
          )}
          <div className="field">
            <label className="l-label">Email Address</label>
            <input className="l-input" type="email" placeholder="you@example.com" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
          </div>
          <div className="field">
            <label className="l-label">Password</label>
            <input className="l-input" type="password" placeholder="••••••••" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required />
          </div>
          {isRegister && (
            <div className="field">
              <label className="l-label">Role</label>
              <select className="l-input" value={form.role} onChange={e => setForm({ ...form, role: e.target.value })}>
                <option value="admin">Admin</option>
                <option value="manager">Manager</option>
                <option value="staff">Staff</option>
              </select>
            </div>
          )}
          <button type="submit" className="l-btn" disabled={loading}>
            {loading ? 'Please wait...' : isRegister ? 'Create Account' : 'Sign In'}
          </button>
        </form>

        <div className="l-switch">
          {isRegister ? 'Already have an account? ' : "Don't have an account? "}
          <button onClick={() => setIsRegister(!isRegister)}>
            {isRegister ? 'Sign In' : 'Register'}
          </button>
        </div>
      </div>
    </div>
  );
}
