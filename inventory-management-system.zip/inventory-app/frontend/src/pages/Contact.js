import React, { useState } from 'react';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 3000);
  };

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', padding: '6rem 2rem', fontFamily: "'DM Sans', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap');
        .c-layout{display:grid;grid-template-columns:1fr 1.5fr;gap:4rem;align-items:start}
        .c-badge{display:inline-block;background:rgba(108,99,255,0.15);border:1px solid rgba(108,99,255,0.3);color:#9d97ff;padding:0.4rem 1.2rem;border-radius:100px;font-size:0.85rem;margin-bottom:1.5rem}
        .c-title{font-family:'Syne',sans-serif;font-size:clamp(2rem,4vw,3rem);font-weight:800;color:#fff;letter-spacing:-0.03em;margin-bottom:1rem;line-height:1.1}
        .c-sub{color:#777;line-height:1.8;margin-bottom:3rem;font-size:0.95rem}
        .c-info-item{display:flex;align-items:flex-start;gap:1rem;margin-bottom:1.5rem}
        .c-icon{width:40px;height:40px;background:rgba(108,99,255,0.15);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0}
        .c-info-label{font-size:0.8rem;color:#555;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:0.2rem}
        .c-info-val{color:#ccc;font-size:0.95rem}
        .c-form{background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:20px;padding:2.5rem}
        .c-field{margin-bottom:1.5rem}
        .c-label{display:block;color:#888;font-size:0.85rem;margin-bottom:0.5rem;font-weight:500}
        .c-input{width:100%;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:0.8rem 1rem;color:#fff;font-family:'DM Sans';font-size:0.95rem;outline:none;transition:border 0.2s}
        .c-input:focus{border-color:#6c63ff}
        .c-input::placeholder{color:#555}
        .c-textarea{resize:vertical;min-height:120px}
        .c-submit{width:100%;background:#6c63ff;color:#fff;border:none;padding:1rem;border-radius:12px;font-size:1rem;font-weight:600;cursor:pointer;font-family:'DM Sans';transition:all 0.2s}
        .c-submit:hover{background:#5a52e0;transform:translateY(-1px)}
        .success{background:rgba(72,199,142,0.15);border:1px solid rgba(72,199,142,0.3);color:#48c78e;padding:1rem;border-radius:10px;text-align:center;margin-bottom:1rem}
        @media(max-width:768px){.c-layout{grid-template-columns:1fr}}
      `}</style>
      <div className="c-layout">
        <div>
          <span className="c-badge">Contact</span>
          <h1 className="c-title">Let's talk about your inventory needs.</h1>
          <p className="c-sub">Whether you need help getting started, have a question about a feature, or want to discuss a custom solution—we're here.</p>
          {[['📧', 'Email', 'hello@stocksync.io'], ['📞', 'Phone', '+1 (555) 012-3456'], ['📍', 'Location', 'San Francisco, CA'], ['⏰', 'Hours', 'Mon–Fri, 9am–6pm PST']].map(([icon, label, val]) => (
            <div className="c-info-item" key={label}>
              <div className="c-icon">{icon}</div>
              <div><div className="c-info-label">{label}</div><div className="c-info-val">{val}</div></div>
            </div>
          ))}
        </div>
        <div className="c-form">
          {sent && <div className="success">✅ Message sent! We'll be in touch soon.</div>}
          <form onSubmit={handleSubmit}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="c-field">
                <label className="c-label">Name</label>
                <input className="c-input" placeholder="Your name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
              </div>
              <div className="c-field">
                <label className="c-label">Email</label>
                <input className="c-input" type="email" placeholder="your@email.com" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
              </div>
            </div>
            <div className="c-field">
              <label className="c-label">Subject</label>
              <input className="c-input" placeholder="How can we help?" value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })} />
            </div>
            <div className="c-field">
              <label className="c-label">Message</label>
              <textarea className="c-input c-textarea" placeholder="Tell us more..." value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} required />
            </div>
            <button type="submit" className="c-submit">Send Message →</button>
          </form>
        </div>
      </div>
    </div>
  );
}
