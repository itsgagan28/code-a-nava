# StockSync — Inventory Management System

A full-stack web application to manage products, stock levels, suppliers, and sales records with an admin dashboard.

---

## 🏗️ Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, React Router v6, Recharts, Axios |
| Backend | Node.js, Express.js |
| Database | MongoDB (Mongoose) |
| Auth | JWT (JSON Web Tokens) |
| Frontend Hosting | **Netlify** |
| Backend Hosting | **Vercel** |

---

## 📁 Project Structure

```
inventory-app/
├── frontend/               # React app → deploy to Netlify
│   ├── public/
│   ├── src/
│   │   ├── components/     # Sidebar, Layout
│   │   ├── context/        # AuthContext (JWT management)
│   │   ├── pages/          # Home, About, Services, Products, Contact, Login, Dashboard, Inventory, Sales, Purchases, Suppliers
│   │   └── utils/          # Axios API instance + all endpoints
│   ├── .env.example
│   └── netlify.toml        # SPA redirect rules
│
└── backend/                # Express API → deploy to Vercel
    ├── src/
    │   ├── models/         # User, Product, Supplier, Sale, Purchase
    │   ├── routes/         # auth, products, suppliers, sales, purchases, dashboard
    │   └── middleware/     # JWT auth middleware
    ├── .env.example
    └── vercel.json         # Vercel serverless config
```

---

## 🚀 Local Development

### Prerequisites
- Node.js 18+
- MongoDB (local or [MongoDB Atlas](https://cloud.mongodb.com))

### 1. Backend Setup

```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your MongoDB URI and JWT secret
npm run dev     # runs on http://localhost:5000
```

### 2. Frontend Setup

```bash
cd frontend
npm install
cp .env.example .env
# Set REACT_APP_API_URL=http://localhost:5000/api
npm start       # runs on http://localhost:3000
```

---

## ☁️ Deployment

### Backend → Vercel

1. Push `backend/` folder to GitHub
2. Go to [vercel.com](https://vercel.com) → New Project → import repo
3. Set **Root Directory** to `backend`
4. Add Environment Variables:
   - `MONGODB_URI` — your MongoDB Atlas connection string
   - `JWT_SECRET` — any long random string
   - `FRONTEND_URL` — your Netlify URL (e.g. `https://stocksync.netlify.app`)
5. Deploy → copy the Vercel URL

### Frontend → Netlify

1. Push `frontend/` folder to GitHub
2. Go to [netlify.com](https://netlify.com) → New Site → import repo
3. Set **Base Directory** to `frontend`, **Build Command** to `npm run build`, **Publish Directory** to `frontend/build`
4. Add Environment Variable:
   - `REACT_APP_API_URL` — your Vercel backend URL + `/api` (e.g. `https://your-api.vercel.app/api`)
5. Deploy

---

## 🗂️ Pages & Features

### Public Pages (Marketing Site)
| Page | Route | Description |
|---|---|---|
| Home | `/` | Hero section, features, stats |
| About | `/about` | Company values, team |
| Services | `/services` | Feature breakdown |
| Our Products | `/our-products` | Sample product showcase |
| Contact | `/contact` | Contact form |
| Login | `/login` | Auth — login & register |

### Dashboard (Protected, requires login)
| Page | Route | Description |
|---|---|---|
| Dashboard | `/dashboard` | Analytics, revenue chart, top products, recent sales |
| Inventory | `/inventory` | CRUD products, low-stock filter, search |
| Sales | `/sales` | Record sales, auto stock deduction, invoice numbers |
| Purchases | `/purchases` | Purchase orders, auto stock update on receive |
| Suppliers | `/suppliers` | Manage suppliers with contact info |

---

## 📊 API Endpoints

### Auth
- `POST /api/auth/register` — Create account
- `POST /api/auth/login` — Login, get JWT
- `GET /api/auth/me` — Get current user

### Products
- `GET /api/products` — List (supports `?search=`, `?lowStock=true`)
- `POST /api/products` — Create
- `PUT /api/products/:id` — Update
- `DELETE /api/products/:id` — Delete

### Sales
- `GET /api/sales` — List all sales
- `POST /api/sales` — Record sale (auto-deducts stock)

### Purchases
- `GET /api/purchases` — List purchase orders
- `POST /api/purchases` — Create PO (auto-updates stock if received)

### Dashboard
- `GET /api/dashboard/stats` — Aggregated stats, charts, top products

---

## 🔐 Roles

| Role | Access |
|---|---|
| admin | Full access |
| manager | Full access |
| staff | Inventory & sales |

---

## 🧩 Key Features

- ✅ JWT authentication with protected routes
- ✅ Real-time low-stock alerts
- ✅ Revenue chart (last 7 days)
- ✅ Auto stock deduction on sales
- ✅ Auto stock addition on purchase receipts
- ✅ Invoice & PO number generation
- ✅ Supplier management
- ✅ Role-based access control
- ✅ Responsive dashboard UI
