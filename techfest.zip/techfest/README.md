# ⚡ TechFest 2025 — Event Management System

A full-stack event management platform for a college technical festival, featuring student registration, event exploration, schedule viewing, and an admin panel — with email confirmations via Nodemailer.

---

## 🗂️ Project Structure

```
techfest/
├── frontend/               ← React + Vite (deploy to Netlify)
│   ├── src/
│   │   ├── App.jsx         ← Complete SPA (all pages + components)
│   │   └── main.jsx        ← Entry point
│   ├── index.html
│   ├── vite.config.js
│   ├── netlify.toml
│   └── .env.example
│
└── backend/                ← Express + MongoDB (deploy to Vercel)
    ├── src/
    │   ├── index.js        ← Server entry point
    │   ├── models/
    │   │   ├── User.js
    │   │   ├── Event.js
    │   │   └── Registration.js
    │   ├── routes/
    │   │   ├── auth.js
    │   │   ├── events.js
    │   │   ├── registrations.js
    │   │   └── users.js
    │   ├── controllers/
    │   │   └── mailer.js   ← Nodemailer email service
    │   └── middleware/
    │       └── auth.js     ← JWT + role guards
    ├── package.json
    ├── vercel.json
    └── .env.example
```

---

## 🖥️ Pages & Components

| Page | Route | Access |
|------|-------|--------|
| Home | `/` | Public |
| About | `/about` | Public |
| Events | `/events` | Public |
| Schedule | `/schedule` | Public |
| Contact | `/contact` | Public |
| Login | `/login` | Public |
| Register | `/register` | Public |
| Student Dashboard | `/student-dashboard` | Student |
| Admin Dashboard | `/admin-dashboard` | Admin |

---

## 🔌 API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new user |
| GET | `/api/auth/verify-email?token=` | Verify email |
| POST | `/api/auth/login` | Login → returns JWT |
| GET | `/api/auth/me` | Get current user |
| POST | `/api/auth/forgot-password` | Send reset email |
| POST | `/api/auth/reset-password` | Reset password |

### Events
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/events` | List all events |
| GET | `/api/events/:id` | Get single event |
| POST | `/api/events` | Create event (admin) |
| PUT | `/api/events/:id` | Update event (admin) |
| DELETE | `/api/events/:id` | Delete event (admin) |

### Registrations
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/registrations` | Register for event |
| GET | `/api/registrations/mine` | My registrations |
| GET | `/api/registrations/event/:id` | Event registrations (admin) |
| GET | `/api/registrations` | All registrations (admin) |
| DELETE | `/api/registrations/:id` | Cancel registration |

### Users
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/users` | List all users (admin) |
| GET | `/api/users/:id` | Get user profile |
| PUT | `/api/users/:id` | Update profile |
| DELETE | `/api/users/:id` | Delete user (admin) |

---

## 📧 Email Notifications (Nodemailer)

Three email types are sent automatically:

1. **Email Verification** — on registration
2. **Registration Confirmation** — on event registration (with confirmation code)
3. **Password Reset** — on forgot password request

Configure Gmail SMTP in `.env`:
```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@gmail.com
SMTP_PASS=your_16char_app_password
```

> Enable **App Passwords** in Google Account → Security → 2-Step Verification → App Passwords

---

## 🚀 Local Development

### Backend
```bash
cd backend
npm install
cp .env.example .env    # Fill in your values
npm run dev             # Runs on http://localhost:5000
```

### Frontend
```bash
cd frontend
npm install
cp .env.example .env    # Set VITE_API_URL
npm run dev             # Runs on http://localhost:3000
```

---

## ☁️ Deployment

### Backend → Vercel

1. Push `backend/` to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → **New Project** → import repo
3. Set **Root Directory** to `backend`
4. Add **Environment Variables** from `.env.example`:
   - `MONGO_URI`, `JWT_SECRET`, `SMTP_*`, `FRONTEND_URL`
5. Deploy → note your URL (e.g. `https://techfest-backend.vercel.app`)

### Frontend → Netlify

1. Push `frontend/` to a GitHub repo
2. Go to [netlify.com](https://netlify.com) → **New site from Git**
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Add environment variable:
   - `VITE_API_URL=https://techfest-backend.vercel.app/api`
6. Deploy!

---

## 🗃️ Database (MongoDB Atlas)

1. Create free cluster at [cloud.mongodb.com](https://cloud.mongodb.com)
2. Create DB user + allow all IPs (`0.0.0.0/0`) for Vercel
3. Get connection string → paste in `MONGO_URI`

---

## 🔐 Security Features

- Passwords hashed with **bcryptjs** (12 salt rounds)
- **JWT** authentication (7-day expiry)
- Role-based access: `student` | `admin`
- Email verification required before login
- Duplicate registration prevention (MongoDB unique index)
- Capacity enforcement with auto-status update

---

## 🎨 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite |
| Styling | Pure CSS-in-JS (no UI library) |
| Fonts | Orbitron, Rajdhani, Share Tech Mono |
| Backend | Node.js, Express.js |
| Database | MongoDB + Mongoose |
| Auth | JWT + bcryptjs |
| Email | Nodemailer (Gmail SMTP) |
| Frontend Host | Netlify |
| Backend Host | Vercel |

---

## 🎯 Demo Credentials (frontend)

| Role | Email | Password |
|------|-------|----------|
| Student | arjun@student.edu | pass |
| Admin | admin@techfest.edu | admin |
