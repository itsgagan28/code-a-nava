import { useState, useContext, createContext, useEffect, useRef } from "react";

/* ═══════════════════════════════════════════════════════════
   GLOBAL STYLES
═══════════════════════════════════════════════════════════ */
const GlobalStyles = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700;900&family=Rajdhani:wght@300;400;500;600;700&family=Share+Tech+Mono&display=swap');

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --bg: #040812;
      --bg2: #070f1f;
      --surface: #0b1628;
      --surface2: #0f1e35;
      --cyan: #00f5ff;
      --cyan2: #00c4cc;
      --orange: #ff6b2b;
      --orange2: #ff9a5c;
      --gold: #ffd700;
      --text: #e8f4fd;
      --text2: #7a9bb5;
      --border: rgba(0,245,255,0.15);
      --glow-cyan: 0 0 20px rgba(0,245,255,0.4);
      --glow-orange: 0 0 20px rgba(255,107,43,0.4);
    }

    html { scroll-behavior: smooth; }

    body {
      font-family: 'Rajdhani', sans-serif;
      background: var(--bg);
      color: var(--text);
      overflow-x: hidden;
      cursor: default;
    }

    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: var(--bg); }
    ::-webkit-scrollbar-thumb { background: var(--cyan2); border-radius: 3px; }

    .orbitron { font-family: 'Orbitron', sans-serif; }
    .mono { font-family: 'Share Tech Mono', monospace; }

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(30px); }
      to { opacity: 1; transform: translateY(0); }
    }
    @keyframes fadeIn {
      from { opacity: 0; } to { opacity: 1; }
    }
    @keyframes pulse-cyan {
      0%, 100% { box-shadow: 0 0 10px rgba(0,245,255,0.3); }
      50% { box-shadow: 0 0 30px rgba(0,245,255,0.7); }
    }
    @keyframes scan {
      0% { transform: translateY(-100%); }
      100% { transform: translateY(100vh); }
    }
    @keyframes gridMove {
      0% { background-position: 0 0; }
      100% { background-position: 40px 40px; }
    }
    @keyframes flicker {
      0%,100% { opacity:1; } 92% { opacity:1; } 93% { opacity:0.4; } 95% { opacity:1; } 97% { opacity:0.6; } 99% { opacity:1; }
    }
    @keyframes rotateSlow {
      from { transform: rotate(0deg); } to { transform: rotate(360deg); }
    }
    @keyframes blink {
      0%,100% { opacity:1; } 50% { opacity:0; }
    }
    @keyframes slideInLeft {
      from { opacity:0; transform: translateX(-40px); }
      to { opacity:1; transform: translateX(0); }
    }
    @keyframes countUp {
      from { opacity:0; transform: scale(0.5); }
      to { opacity:1; transform: scale(1); }
    }

    .animate-fadeUp { animation: fadeUp 0.6s ease forwards; }
    .animate-fadeIn { animation: fadeIn 0.4s ease forwards; }

    input, textarea, select {
      font-family: 'Rajdhani', sans-serif;
      background: var(--surface2);
      border: 1px solid var(--border);
      color: var(--text);
      padding: 10px 14px;
      border-radius: 6px;
      font-size: 15px;
      width: 100%;
      outline: none;
      transition: border-color 0.2s, box-shadow 0.2s;
    }
    input:focus, textarea:focus, select:focus {
      border-color: var(--cyan);
      box-shadow: 0 0 12px rgba(0,245,255,0.2);
    }
    input::placeholder, textarea::placeholder { color: var(--text2); }

    button { cursor: pointer; font-family: 'Rajdhani', sans-serif; font-weight: 600; }

    .btn-primary {
      background: linear-gradient(135deg, var(--cyan), var(--cyan2));
      color: var(--bg);
      border: none;
      padding: 11px 28px;
      border-radius: 6px;
      font-size: 15px;
      letter-spacing: 1px;
      text-transform: uppercase;
      transition: all 0.2s;
    }
    .btn-primary:hover {
      box-shadow: var(--glow-cyan);
      transform: translateY(-1px);
    }

    .btn-outline {
      background: transparent;
      color: var(--cyan);
      border: 1px solid var(--cyan);
      padding: 10px 26px;
      border-radius: 6px;
      font-size: 15px;
      letter-spacing: 1px;
      text-transform: uppercase;
      transition: all 0.2s;
    }
    .btn-outline:hover {
      background: rgba(0,245,255,0.08);
      box-shadow: var(--glow-cyan);
    }

    .btn-orange {
      background: linear-gradient(135deg, var(--orange), var(--orange2));
      color: #fff;
      border: none;
      padding: 11px 28px;
      border-radius: 6px;
      font-size: 15px;
      letter-spacing: 1px;
      text-transform: uppercase;
      transition: all 0.2s;
    }
    .btn-orange:hover {
      box-shadow: var(--glow-orange);
      transform: translateY(-1px);
    }

    .card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 24px;
      transition: border-color 0.2s, box-shadow 0.2s;
    }
    .card:hover {
      border-color: rgba(0,245,255,0.35);
      box-shadow: 0 4px 30px rgba(0,245,255,0.08);
    }

    .tag {
      display: inline-block;
      padding: 3px 10px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }
    .tag-cyan { background: rgba(0,245,255,0.12); color: var(--cyan); border: 1px solid rgba(0,245,255,0.3); }
    .tag-orange { background: rgba(255,107,43,0.12); color: var(--orange); border: 1px solid rgba(255,107,43,0.3); }
    .tag-gold { background: rgba(255,215,0,0.12); color: var(--gold); border: 1px solid rgba(255,215,0,0.3); }
    .tag-green { background: rgba(0,255,136,0.12); color: #00ff88; border: 1px solid rgba(0,255,136,0.3); }

    .section-title {
      font-family: 'Orbitron', sans-serif;
      font-size: 28px;
      font-weight: 700;
      letter-spacing: 2px;
      background: linear-gradient(135deg, var(--cyan), var(--text));
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .grid-bg {
      background-image: 
        linear-gradient(rgba(0,245,255,0.04) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0,245,255,0.04) 1px, transparent 1px);
      background-size: 40px 40px;
      animation: gridMove 8s linear infinite;
    }

    .nav-link {
      color: var(--text2);
      text-decoration: none;
      font-size: 14px;
      font-weight: 600;
      letter-spacing: 1.5px;
      text-transform: uppercase;
      cursor: pointer;
      transition: color 0.2s;
      padding: 6px 0;
      position: relative;
    }
    .nav-link:hover, .nav-link.active { color: var(--cyan); }
    .nav-link.active::after {
      content: '';
      position: absolute;
      bottom: 0; left: 0; right: 0;
      height: 2px;
      background: var(--cyan);
      box-shadow: var(--glow-cyan);
    }

    .modal-overlay {
      position: fixed; inset: 0;
      background: rgba(4,8,18,0.85);
      backdrop-filter: blur(6px);
      z-index: 1000;
      display: flex; align-items: center; justify-content: center;
      animation: fadeIn 0.2s ease;
      padding: 20px;
    }

    .modal-box {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 32px;
      width: 100%;
      max-width: 520px;
      max-height: 90vh;
      overflow-y: auto;
      animation: fadeUp 0.3s ease;
    }

    table { width: 100%; border-collapse: collapse; }
    th { font-family: 'Orbitron', sans-serif; font-size: 11px; letter-spacing: 1.5px; color: var(--text2); text-transform: uppercase; padding: 12px 16px; border-bottom: 1px solid var(--border); text-align: left; }
    td { padding: 14px 16px; border-bottom: 1px solid rgba(255,255,255,0.04); font-size: 15px; }
    tr:hover td { background: rgba(0,245,255,0.03); }

    .stat-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 20px 24px;
      position: relative;
      overflow: hidden;
    }
    .stat-card::before {
      content: '';
      position: absolute;
      top: 0; left: 0; right: 0;
      height: 2px;
    }
    .stat-card.cyan::before { background: linear-gradient(90deg, transparent, var(--cyan), transparent); }
    .stat-card.orange::before { background: linear-gradient(90deg, transparent, var(--orange), transparent); }
    .stat-card.gold::before { background: linear-gradient(90deg, transparent, var(--gold), transparent); }
    .stat-card.green::before { background: linear-gradient(90deg, transparent, #00ff88, transparent); }

    .divider {
      height: 1px;
      background: linear-gradient(90deg, transparent, var(--border), transparent);
      margin: 24px 0;
    }

    .alert {
      padding: 12px 16px;
      border-radius: 8px;
      font-size: 14px;
      margin-bottom: 16px;
    }
    .alert-success { background: rgba(0,255,136,0.08); border: 1px solid rgba(0,255,136,0.3); color: #00ff88; }
    .alert-error { background: rgba(255,50,50,0.08); border: 1px solid rgba(255,50,50,0.3); color: #ff6b6b; }
    .alert-info { background: rgba(0,245,255,0.08); border: 1px solid rgba(0,245,255,0.3); color: var(--cyan); }
  `}</style>
);

/* ═══════════════════════════════════════════════════════════
   DATA STORE
═══════════════════════════════════════════════════════════ */
const AuthCtx = createContext(null);
const useAuth = () => useContext(AuthCtx);

const EVENTS_DATA = [
  { id: 1, title: "AI Hackathon", category: "Hackathon", date: "2025-04-12", time: "09:00 AM", venue: "Main Auditorium", capacity: 200, registered: 147, prize: "₹50,000", duration: "24 Hours", desc: "Build AI-powered solutions in 24 hours. Form teams of 2-4. Mentors available.", image: "🤖", tags: ["AI", "ML", "Python"], status: "open" },
  { id: 2, title: "Web Dev Blitz", category: "Competition", date: "2025-04-13", time: "10:00 AM", venue: "CS Lab Block A", capacity: 100, registered: 88, prize: "₹20,000", duration: "6 Hours", desc: "Speed web development contest. Build a full-stack app from scratch. Solo or pairs.", image: "💻", tags: ["React", "Node", "CSS"], status: "open" },
  { id: 3, title: "Robo Wars", category: "Robotics", date: "2025-04-14", time: "11:00 AM", venue: "Engineering Grounds", capacity: 60, registered: 60, prize: "₹30,000", duration: "All Day", desc: "Design, build & battle your robot. Weight limit 15kg. Autonomous & manual modes.", image: "🤖", tags: ["Robotics", "Electronics", "Arduino"], status: "full" },
  { id: 4, title: "Cybersecurity CTF", category: "CTF", date: "2025-04-12", time: "02:00 PM", venue: "Network Lab", capacity: 80, registered: 55, prize: "₹15,000", duration: "8 Hours", desc: "Capture The Flag competition across web, crypto, forensics & binary exploitation.", image: "🔐", tags: ["Security", "Linux", "Networking"], status: "open" },
  { id: 5, title: "Data Science Bowl", category: "Competition", date: "2025-04-15", time: "09:00 AM", venue: "Seminar Hall", capacity: 120, registered: 73, prize: "₹25,000", duration: "5 Hours", desc: "Analyze real-world datasets and present insights. Tools allowed: Python, R, Excel.", image: "📊", tags: ["Data", "Analytics", "Visualization"], status: "open" },
  { id: 6, title: "Tech Talk: Future of Quantum", category: "Talk", date: "2025-04-13", time: "03:00 PM", venue: "Conference Room 1", capacity: 150, registered: 102, prize: "Certificate", duration: "2 Hours", desc: "Expert talk on Quantum Computing applications. Q&A session included.", image: "⚛️", tags: ["Quantum", "Research", "Physics"], status: "open" },
  { id: 7, title: "App Mania", category: "Hackathon", date: "2025-04-14", time: "08:00 AM", venue: "Innovation Hub", capacity: 90, registered: 45, prize: "₹18,000", duration: "12 Hours", desc: "Build a mobile app that solves a real campus problem. Android, iOS or Flutter.", image: "📱", tags: ["Mobile", "Flutter", "UX"], status: "open" },
  { id: 8, title: "Paper Presentation", category: "Academic", date: "2025-04-15", time: "01:00 PM", venue: "Seminar Hall B", capacity: 80, registered: 38, prize: "₹10,000", duration: "3 Hours", desc: "Present your research paper to a panel of faculty judges. Any CS/IT domain.", image: "📄", tags: ["Research", "Paper", "Presentation"], status: "open" },
];

const SCHEDULE_DATA = [
  { day: "Day 1 - Apr 12", items: [
    { time: "08:00", event: "Registration & Inauguration", venue: "Main Auditorium", type: "keynote" },
    { time: "09:00", event: "AI Hackathon Kickoff", venue: "Main Auditorium", type: "hackathon" },
    { time: "10:30", event: "Workshop: Intro to GenAI", venue: "Lab 1", type: "workshop" },
    { time: "02:00", event: "Cybersecurity CTF Begins", venue: "Network Lab", type: "competition" },
    { time: "04:00", event: "Tech Quiz Prelims", venue: "Seminar Hall", type: "competition" },
    { time: "06:00", event: "Cultural Evening", venue: "Open Air Stage", type: "cultural" },
  ]},
  { day: "Day 2 - Apr 13", items: [
    { time: "09:00", event: "AI Hackathon Continues", venue: "Main Auditorium", type: "hackathon" },
    { time: "10:00", event: "Web Dev Blitz Starts", venue: "CS Lab Block A", type: "competition" },
    { time: "12:00", event: "Guest Lecture: Industry 5.0", venue: "Conference Room 2", type: "talk" },
    { time: "03:00", event: "Tech Talk: Quantum Computing", venue: "Conference Room 1", type: "talk" },
    { time: "05:00", event: "Web Dev Blitz Results", venue: "CS Lab Block A", type: "competition" },
    { time: "07:00", event: "DJ Night & Networking", venue: "Campus Plaza", type: "cultural" },
  ]},
  { day: "Day 3 - Apr 14", items: [
    { time: "08:00", event: "App Mania Kickoff", venue: "Innovation Hub", type: "hackathon" },
    { time: "09:00", event: "AI Hackathon Submission", venue: "Main Auditorium", type: "hackathon" },
    { time: "10:00", event: "Robo Wars Qualifiers", venue: "Engineering Grounds", type: "competition" },
    { time: "02:00", event: "AI Hackathon Judging", venue: "Main Auditorium", type: "hackathon" },
    { time: "03:00", event: "Robo Wars Finals", venue: "Engineering Grounds", type: "competition" },
    { time: "06:00", event: "App Mania Demo Day", venue: "Innovation Hub", type: "hackathon" },
  ]},
  { day: "Day 4 - Apr 15", items: [
    { time: "09:00", event: "Data Science Bowl", venue: "Seminar Hall", type: "competition" },
    { time: "11:00", event: "App Mania Judging", venue: "Innovation Hub", type: "hackathon" },
    { time: "01:00", event: "Paper Presentation", venue: "Seminar Hall B", type: "talk" },
    { time: "04:00", event: "Awards Ceremony", venue: "Main Auditorium", type: "keynote" },
    { time: "05:30", event: "Closing Ceremony & Valediction", venue: "Main Auditorium", type: "keynote" },
  ]},
];

const MOCK_USERS = [
  { id: 1, name: "Arjun Sharma", email: "arjun@student.edu", password: "pass", role: "student", college: "BITS Pilani", dept: "CS", year: 3, phone: "9876543210", verified: true },
  { id: 2, name: "Admin TechFest", email: "admin@techfest.edu", password: "admin", role: "admin", verified: true },
];

/* ═══════════════════════════════════════════════════════════
   NAVBAR
═══════════════════════════════════════════════════════════ */
function Navbar({ page, setPage, user, setUser }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const navItems = ["home", "about", "events", "schedule", "contact"];

  return (
    <nav style={{
      position: "fixed", top: 0, left: 0, right: 0, zIndex: 900,
      background: "rgba(4,8,18,0.92)",
      backdropFilter: "blur(12px)",
      borderBottom: "1px solid rgba(0,245,255,0.1)",
      padding: "0 32px",
      height: 64,
      display: "flex", alignItems: "center", justifyContent: "space-between",
    }}>
      {/* Logo */}
      <div style={{ display:"flex", alignItems:"center", gap:12, cursor:"pointer" }} onClick={()=>setPage("home")}>
        <div style={{
          width:36, height:36, borderRadius:8,
          background: "linear-gradient(135deg, var(--cyan), var(--orange))",
          display:"flex", alignItems:"center", justifyContent:"center",
          fontSize:18
        }}>⚡</div>
        <div>
          <div className="orbitron" style={{ fontSize:16, fontWeight:900, color:"var(--cyan)", letterSpacing:2, lineHeight:1 }}>TECHFEST</div>
          <div className="mono" style={{ fontSize:10, color:"var(--text2)", letterSpacing:3 }}>2025</div>
        </div>
      </div>

      {/* Desktop Nav */}
      <div style={{ display:"flex", gap:32, alignItems:"center" }}>
        {navItems.map(n => (
          <span key={n} className={`nav-link ${page===n?"active":""}`} onClick={()=>setPage(n)}>
            {n}
          </span>
        ))}
      </div>

      {/* Auth */}
      <div style={{ display:"flex", gap:12, alignItems:"center" }}>
        {user ? (
          <>
            <button className="btn-outline" style={{ padding:"7px 16px", fontSize:13 }}
              onClick={()=>setPage(user.role==="admin"?"admin-dashboard":"student-dashboard")}>
              {user.role==="admin"?"⚙ Admin":"📋 Dashboard"}
            </button>
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              <div style={{
                width:32, height:32, borderRadius:"50%",
                background:"linear-gradient(135deg,var(--cyan),var(--orange))",
                display:"flex", alignItems:"center", justifyContent:"center",
                fontSize:13, fontWeight:700, color:"var(--bg)"
              }}>{user.name[0]}</div>
              <button style={{ background:"none", border:"none", color:"var(--text2)", fontSize:13, cursor:"pointer" }}
                onClick={()=>{ setUser(null); setPage("home"); }}>Logout</button>
            </div>
          </>
        ) : (
          <>
            <button className="btn-outline" style={{ padding:"7px 18px", fontSize:13 }} onClick={()=>setPage("login")}>Login</button>
            <button className="btn-primary" style={{ padding:"7px 18px", fontSize:13 }} onClick={()=>setPage("register")}>Register</button>
          </>
        )}
      </div>
    </nav>
  );
}

/* ═══════════════════════════════════════════════════════════
   HOME PAGE
═══════════════════════════════════════════════════════════ */
function HomePage({ setPage }) {
  const [count, setCount] = useState({ events: 0, teams: 0, prize: 0, colleges: 0 });

  useEffect(() => {
    const targets = { events: 28, teams: 500, prize: 300, colleges: 80 };
    const duration = 1800;
    const steps = 60;
    const interval = duration / steps;
    let step = 0;
    const timer = setInterval(() => {
      step++;
      const progress = step / steps;
      const ease = 1 - Math.pow(1 - progress, 3);
      setCount({
        events: Math.round(targets.events * ease),
        teams: Math.round(targets.teams * ease),
        prize: Math.round(targets.prize * ease),
        colleges: Math.round(targets.colleges * ease),
      });
      if (step >= steps) clearInterval(timer);
    }, interval);
    return () => clearInterval(timer);
  }, []);

  const featuredEvents = EVENTS_DATA.slice(0, 4);

  return (
    <div>
      {/* HERO */}
      <section style={{
        minHeight: "100vh",
        display: "flex", flexDirection:"column", alignItems:"center", justifyContent:"center",
        position: "relative",
        overflow: "hidden",
        paddingTop: 64,
      }} className="grid-bg">
        {/* Glow orbs */}
        <div style={{ position:"absolute", top:"20%", left:"10%", width:300, height:300, borderRadius:"50%", background:"radial-gradient(circle, rgba(0,245,255,0.08) 0%, transparent 70%)", pointerEvents:"none" }}/>
        <div style={{ position:"absolute", bottom:"20%", right:"10%", width:400, height:400, borderRadius:"50%", background:"radial-gradient(circle, rgba(255,107,43,0.08) 0%, transparent 70%)", pointerEvents:"none" }}/>

        {/* Scan line */}
        <div style={{
          position:"absolute", left:0, right:0, height:2,
          background:"linear-gradient(90deg, transparent, rgba(0,245,255,0.3), transparent)",
          animation:"scan 4s linear infinite",
          pointerEvents:"none"
        }}/>

        <div style={{ textAlign:"center", padding:"0 24px", zIndex:1, animation:"fadeUp 0.8s ease forwards" }}>
          <div className="tag tag-cyan" style={{ marginBottom:24, fontSize:13 }}>
            ⚡ APRIL 12–15, 2025 &nbsp;•&nbsp; 4 DAYS OF TECH
          </div>

          <h1 className="orbitron" style={{
            fontSize: "clamp(48px, 10vw, 100px)",
            fontWeight: 900,
            lineHeight: 0.95,
            letterSpacing: "-2px",
            marginBottom: 8,
          }}>
            <span style={{ background:"linear-gradient(135deg, var(--cyan) 0%, #fff 50%, var(--orange) 100%)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", backgroundClip:"text", animation:"flicker 8s infinite" }}>
              TECH
            </span>
            <br/>
            <span style={{ color:"var(--text)", WebkitTextFillColor:"var(--text)" }}>
              FEST
            </span>
          </h1>

          <div className="mono" style={{ fontSize:18, color:"var(--cyan)", letterSpacing:4, marginBottom:12 }}>
            2 0 2 5
          </div>

          <p style={{ fontSize:18, color:"var(--text2)", maxWidth:560, margin:"0 auto 40px", lineHeight:1.6 }}>
            The ultimate college technical extravaganza. 28+ events, ₹3L+ prizes, 500+ teams, 80+ colleges.
          </p>

          <div style={{ display:"flex", gap:16, justifyContent:"center", flexWrap:"wrap" }}>
            <button className="btn-primary" style={{ fontSize:16, padding:"14px 36px" }} onClick={()=>setPage("events")}>
              Explore Events →
            </button>
            <button className="btn-outline" style={{ fontSize:16, padding:"14px 36px" }} onClick={()=>setPage("schedule")}>
              View Schedule
            </button>
          </div>
        </div>

        {/* Countdown */}
        <div style={{ marginTop:64, display:"flex", gap:0, zIndex:1 }}>
          {[["12","DAYS"],["08","HRS"],["34","MIN"],["22","SEC"]].map(([n,l],i)=>(
            <div key={i} style={{ textAlign:"center", padding:"0 24px", borderRight: i<3 ? "1px solid var(--border)":undefined }}>
              <div className="orbitron" style={{ fontSize:40, fontWeight:900, color:"var(--cyan)", lineHeight:1 }}>{n}</div>
              <div style={{ fontSize:11, color:"var(--text2)", letterSpacing:3, marginTop:4 }}>{l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* STATS */}
      <section style={{ padding:"80px 48px", borderTop:"1px solid var(--border)" }}>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:24, maxWidth:900, margin:"0 auto" }}>
          {[
            { val:`${count.events}+`, label:"Events", color:"cyan", icon:"🎯" },
            { val:`${count.teams}+`, label:"Teams", color:"orange", icon:"👥" },
            { val:`₹${count.prize}K+`, label:"Total Prize", color:"gold", icon:"🏆" },
            { val:`${count.colleges}+`, label:"Colleges", color:"green", icon:"🎓" },
          ].map((s,i)=>(
            <div key={i} className={`stat-card ${s.color}`} style={{ textAlign:"center" }}>
              <div style={{ fontSize:32, marginBottom:8 }}>{s.icon}</div>
              <div className="orbitron" style={{ fontSize:32, fontWeight:900, color:`var(--${s.color==="green"?"text":s.color})`, marginBottom:4 }}>{s.val}</div>
              <div style={{ color:"var(--text2)", fontSize:14, letterSpacing:1.5, textTransform:"uppercase" }}>{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURED EVENTS */}
      <section style={{ padding:"0 48px 80px", maxWidth:1200, margin:"0 auto" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:40 }}>
          <h2 className="section-title">Featured Events</h2>
          <button className="btn-outline" style={{ fontSize:13 }} onClick={()=>setPage("events")}>View All →</button>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:24 }}>
          {featuredEvents.map(ev => <EventCard key={ev.id} event={ev} setPage={setPage}/>)}
        </div>
      </section>

      {/* WHY ATTEND */}
      <section style={{ padding:"80px 48px", borderTop:"1px solid var(--border)", background:"var(--bg2)" }}>
        <div style={{ maxWidth:1000, margin:"0 auto", textAlign:"center" }}>
          <h2 className="section-title" style={{ marginBottom:16 }}>Why TechFest 2025?</h2>
          <p style={{ color:"var(--text2)", marginBottom:56, fontSize:16 }}>Four days of learning, competing, and connecting with the best minds in tech</p>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:24, textAlign:"left" }}>
            {[
              { icon:"🎖️", title:"Massive Prizes", desc:"Over ₹3 Lakhs in cash prizes across 28+ competitive events spanning every tech domain." },
              { icon:"🧠", title:"Expert Mentors", desc:"Get guidance from industry veterans at Google, Microsoft, ISRO, and leading startups." },
              { icon:"🔗", title:"Network", desc:"Connect with 500+ teams and 2000+ tech enthusiasts from 80+ colleges nationwide." },
              { icon:"🛠️", title:"Hands-on Workshops", desc:"Learn cutting-edge skills through 10+ workshops on AI, blockchain, robotics, and more." },
              { icon:"💼", title:"Placement Opportunities", desc:"Top performers get noticed by 15+ recruiting companies present at the event." },
              { icon:"🎪", title:"Fun & Culture", desc:"DJ nights, cultural shows, food fest, and gaming zones alongside all the tech action." },
            ].map((f,i)=>(
              <div key={i} className="card">
                <div style={{ fontSize:32, marginBottom:12 }}>{f.icon}</div>
                <div className="orbitron" style={{ fontSize:15, fontWeight:700, color:"var(--cyan)", marginBottom:8 }}>{f.title}</div>
                <p style={{ color:"var(--text2)", fontSize:14, lineHeight:1.6 }}>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   EVENT CARD (reusable)
═══════════════════════════════════════════════════════════ */
function EventCard({ event: ev, setPage, onRegister, userRegistrations = [] }) {
  const isRegistered = userRegistrations.includes(ev.id);
  const spotsLeft = ev.capacity - ev.registered;
  const fillPct = (ev.registered / ev.capacity) * 100;

  return (
    <div className="card" style={{ cursor:"pointer", transition:"transform 0.2s, box-shadow 0.2s" }}
      onMouseEnter={e=>{ e.currentTarget.style.transform="translateY(-4px)"; e.currentTarget.style.boxShadow="0 12px 40px rgba(0,245,255,0.1)"; }}
      onMouseLeave={e=>{ e.currentTarget.style.transform=""; e.currentTarget.style.boxShadow=""; }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:16 }}>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <div style={{ fontSize:36, lineHeight:1 }}>{ev.image}</div>
          <div>
            <h3 style={{ fontSize:17, fontWeight:700, color:"var(--text)", marginBottom:4 }}>{ev.title}</h3>
            <span className={`tag ${ev.category==="Hackathon"?"tag-cyan":ev.category==="CTF"?"tag-orange":"tag-gold"}`}>
              {ev.category}
            </span>
          </div>
        </div>
        <span className={`tag ${ev.status==="full"?"tag-orange":"tag-green"}`}>
          {ev.status==="full"?"FULL":"OPEN"}
        </span>
      </div>

      <p style={{ color:"var(--text2)", fontSize:14, lineHeight:1.5, marginBottom:16 }}>{ev.desc.slice(0,100)}...</p>

      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:16 }}>
        {[
          ["📅", ev.date],["⏰", ev.time],
          ["📍", ev.venue],["⏱️", ev.duration],
        ].map(([icon,val],i)=>(
          <div key={i} style={{ display:"flex", alignItems:"center", gap:6 }}>
            <span style={{ fontSize:13 }}>{icon}</span>
            <span style={{ fontSize:13, color:"var(--text2)" }}>{val}</span>
          </div>
        ))}
      </div>

      {/* Fill bar */}
      <div style={{ marginBottom:14 }}>
        <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6 }}>
          <span style={{ fontSize:12, color:"var(--text2)" }}>{ev.registered}/{ev.capacity} registered</span>
          <span style={{ fontSize:12, color: spotsLeft<20?"var(--orange)":"var(--cyan)" }}>
            {spotsLeft} spots left
          </span>
        </div>
        <div style={{ height:4, background:"rgba(255,255,255,0.08)", borderRadius:2, overflow:"hidden" }}>
          <div style={{
            height:"100%", width:`${fillPct}%`, borderRadius:2,
            background: fillPct>80 ? "linear-gradient(90deg,var(--orange),var(--orange2))" : "linear-gradient(90deg,var(--cyan),var(--cyan2))",
            transition:"width 1s ease"
          }}/>
        </div>
      </div>

      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <div>
          <span className="tag tag-gold">🏆 {ev.prize}</span>
        </div>
        {onRegister && (
          <button
            className={isRegistered ? "btn-outline" : "btn-primary"}
            style={{ padding:"7px 18px", fontSize:13 }}
            disabled={ev.status==="full" && !isRegistered}
            onClick={(e)=>{ e.stopPropagation(); onRegister(ev); }}
          >
            {isRegistered ? "✓ Registered" : ev.status==="full" ? "Full" : "Register"}
          </button>
        )}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   EVENTS PAGE
═══════════════════════════════════════════════════════════ */
function EventsPage({ setPage, user, userRegistrations, onRegister }) {
  const [filter, setFilter] = useState("All");
  const [search, setSearch] = useState("");
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [showSuccess, setShowSuccess] = useState(false);

  const categories = ["All", "Hackathon", "Competition", "CTF", "Talk", "Academic", "Robotics"];
  const filtered = EVENTS_DATA.filter(ev =>
    (filter==="All" || ev.category===filter) &&
    (ev.title.toLowerCase().includes(search.toLowerCase()) || ev.tags.some(t=>t.toLowerCase().includes(search.toLowerCase())))
  );

  const handleRegister = (ev) => {
    if (!user) { setPage("login"); return; }
    onRegister(ev.id);
    setShowSuccess(true);
    setTimeout(()=>setShowSuccess(false), 3000);
    setSelectedEvent(null);
  };

  return (
    <div style={{ paddingTop:64, minHeight:"100vh" }}>
      {/* Header */}
      <div style={{
        padding:"64px 48px 40px",
        background:"var(--bg2)",
        borderBottom:"1px solid var(--border)",
        position:"relative", overflow:"hidden"
      }} className="grid-bg">
        <div style={{ maxWidth:1100, margin:"0 auto", position:"relative", zIndex:1 }}>
          <h1 className="section-title" style={{ fontSize:40, marginBottom:12 }}>All Events</h1>
          <p style={{ color:"var(--text2)", fontSize:16, marginBottom:32 }}>Explore and register for {EVENTS_DATA.length} exciting events</p>
          {showSuccess && <div className="alert alert-success">✓ Successfully registered! Check your email for confirmation.</div>}

          <div style={{ display:"flex", gap:16, flexWrap:"wrap", alignItems:"center" }}>
            <input
              placeholder="Search events or tags..."
              value={search} onChange={e=>setSearch(e.target.value)}
              style={{ width:280, padding:"10px 14px" }}
            />
            <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
              {categories.map(c=>(
                <button key={c}
                  onClick={()=>setFilter(c)}
                  style={{
                    padding:"8px 16px", borderRadius:20, fontSize:13, border:"1px solid",
                    background: filter===c ? "var(--cyan)" : "transparent",
                    color: filter===c ? "var(--bg)" : "var(--text2)",
                    borderColor: filter===c ? "var(--cyan)" : "var(--border)",
                    transition:"all 0.2s", cursor:"pointer"
                  }}
                >{c}</button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div style={{ padding:"40px 48px", maxWidth:1200, margin:"0 auto" }}>
        <div style={{ marginBottom:20, color:"var(--text2)", fontSize:14 }}>
          Showing {filtered.length} event{filtered.length!==1?"s":""}
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:24 }}>
          {filtered.map(ev=>(
            <div key={ev.id} onClick={()=>setSelectedEvent(ev)}>
              <EventCard
                event={ev}
                setPage={setPage}
                userRegistrations={userRegistrations}
                onRegister={(ev)=>{ setSelectedEvent(ev); }}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Event Detail Modal */}
      {selectedEvent && (
        <div className="modal-overlay" onClick={()=>setSelectedEvent(null)}>
          <div className="modal-box" onClick={e=>e.stopPropagation()} style={{ maxWidth:600 }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:20 }}>
              <div style={{ display:"flex", gap:14, alignItems:"center" }}>
                <span style={{ fontSize:48 }}>{selectedEvent.image}</span>
                <div>
                  <h2 className="orbitron" style={{ fontSize:20, color:"var(--cyan)", marginBottom:6 }}>{selectedEvent.title}</h2>
                  <div style={{ display:"flex", gap:8 }}>
                    <span className="tag tag-cyan">{selectedEvent.category}</span>
                    <span className={`tag ${selectedEvent.status==="full"?"tag-orange":"tag-green"}`}>{selectedEvent.status.toUpperCase()}</span>
                  </div>
                </div>
              </div>
              <button onClick={()=>setSelectedEvent(null)} style={{ background:"none", border:"none", color:"var(--text2)", fontSize:20 }}>✕</button>
            </div>

            <p style={{ color:"var(--text2)", lineHeight:1.7, marginBottom:20, fontSize:15 }}>{selectedEvent.desc}</p>

            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:20 }}>
              {[
                ["📅 Date", selectedEvent.date],
                ["⏰ Time", selectedEvent.time],
                ["📍 Venue", selectedEvent.venue],
                ["⏱ Duration", selectedEvent.duration],
                ["👥 Capacity", `${selectedEvent.registered}/${selectedEvent.capacity}`],
                ["🏆 Prize", selectedEvent.prize],
              ].map(([k,v])=>(
                <div key={k} style={{ background:"var(--surface2)", borderRadius:8, padding:"12px 14px" }}>
                  <div style={{ fontSize:12, color:"var(--text2)", marginBottom:4 }}>{k}</div>
                  <div style={{ fontSize:15, fontWeight:600 }}>{v}</div>
                </div>
              ))}
            </div>

            <div style={{ marginBottom:20 }}>
              <div style={{ fontSize:12, color:"var(--text2)", marginBottom:8 }}>TAGS</div>
              <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                {selectedEvent.tags.map(t=><span key={t} className="tag tag-cyan">{t}</span>)}
              </div>
            </div>

            <button
              className={userRegistrations.includes(selectedEvent.id)?"btn-outline":"btn-primary"}
              style={{ width:"100%", padding:"13px" }}
              disabled={selectedEvent.status==="full" && !userRegistrations.includes(selectedEvent.id)}
              onClick={()=>handleRegister(selectedEvent)}
            >
              {userRegistrations.includes(selectedEvent.id) ? "✓ Already Registered" :
               selectedEvent.status==="full" ? "Event Full" :
               user ? "Register Now →" : "Login to Register →"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   SCHEDULE PAGE
═══════════════════════════════════════════════════════════ */
function SchedulePage() {
  const [activeDay, setActiveDay] = useState(0);
  const typeColors = { hackathon:"var(--cyan)", competition:"var(--orange)", talk:"var(--gold)", workshop:"#00ff88", keynote:"#bf7fff", cultural:"#ff6bab" };

  return (
    <div style={{ paddingTop:64, minHeight:"100vh" }}>
      <div style={{ padding:"64px 48px 40px", background:"var(--bg2)", borderBottom:"1px solid var(--border)" }} className="grid-bg">
        <div style={{ maxWidth:900, margin:"0 auto", position:"relative", zIndex:1 }}>
          <h1 className="section-title" style={{ fontSize:40, marginBottom:12 }}>Event Schedule</h1>
          <p style={{ color:"var(--text2)", fontSize:16 }}>4 days packed with competitions, workshops & keynotes</p>
        </div>
      </div>

      <div style={{ padding:"40px 48px", maxWidth:900, margin:"0 auto" }}>
        {/* Day Tabs */}
        <div style={{ display:"flex", gap:8, marginBottom:32, flexWrap:"wrap" }}>
          {SCHEDULE_DATA.map((d,i)=>(
            <button key={i} onClick={()=>setActiveDay(i)} style={{
              padding:"10px 20px", borderRadius:8, border:"1px solid",
              background: activeDay===i ? "var(--cyan)" : "transparent",
              color: activeDay===i ? "var(--bg)" : "var(--text2)",
              borderColor: activeDay===i ? "var(--cyan)" : "var(--border)",
              transition:"all 0.2s", cursor:"pointer", fontSize:13, fontWeight:600
            }}>{d.day}</button>
          ))}
        </div>

        {/* Legend */}
        <div style={{ display:"flex", gap:16, flexWrap:"wrap", marginBottom:28 }}>
          {Object.entries(typeColors).map(([type,color])=>(
            <div key={type} style={{ display:"flex", alignItems:"center", gap:6 }}>
              <div style={{ width:10, height:10, borderRadius:2, background:color }}/>
              <span style={{ fontSize:12, color:"var(--text2)", textTransform:"capitalize" }}>{type}</span>
            </div>
          ))}
        </div>

        {/* Timeline */}
        <div style={{ position:"relative" }}>
          <div style={{ position:"absolute", left:58, top:0, bottom:0, width:1, background:"var(--border)" }}/>
          {SCHEDULE_DATA[activeDay].items.map((item,i)=>(
            <div key={i} style={{ display:"flex", gap:20, marginBottom:16, animation:`slideInLeft 0.3s ease ${i*0.05}s both` }}>
              <div className="mono" style={{ width:48, textAlign:"right", color:"var(--text2)", fontSize:13, paddingTop:14, flexShrink:0 }}>
                {item.time}
              </div>
              <div style={{
                width:16, height:16, borderRadius:"50%", flexShrink:0, marginTop:14,
                background: typeColors[item.type] || "var(--text2)",
                boxShadow: `0 0 8px ${typeColors[item.type] || "var(--text2)"}60`,
                zIndex:1, position:"relative"
              }}/>
              <div className="card" style={{ flex:1, padding:"14px 18px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <div>
                  <div style={{ fontWeight:700, fontSize:15, marginBottom:4 }}>{item.event}</div>
                  <div style={{ fontSize:13, color:"var(--text2)" }}>📍 {item.venue}</div>
                </div>
                <span className="tag" style={{
                  background: `${typeColors[item.type]}18`,
                  color: typeColors[item.type],
                  border: `1px solid ${typeColors[item.type]}40`,
                  textTransform:"capitalize", flexShrink:0
                }}>{item.type}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   ABOUT PAGE
═══════════════════════════════════════════════════════════ */
function AboutPage({ setPage }) {
  return (
    <div style={{ paddingTop:64, minHeight:"100vh" }}>
      <div style={{ padding:"80px 48px", background:"var(--bg2)", borderBottom:"1px solid var(--border)" }} className="grid-bg">
        <div style={{ maxWidth:800, margin:"0 auto", textAlign:"center", position:"relative", zIndex:1 }}>
          <h1 className="section-title" style={{ fontSize:48, marginBottom:20 }}>About TechFest</h1>
          <p style={{ color:"var(--text2)", fontSize:17, lineHeight:1.8 }}>
            TechFest 2025 is the annual flagship technical festival of NIT TechCampus — 
            a 4-day extravaganza celebrating innovation, creativity, and technical excellence.
            Since 2010, TechFest has grown to become one of India's most prestigious college tech fests,
            attracting thousands of students from across the country.
          </p>
        </div>
      </div>

      <div style={{ padding:"80px 48px", maxWidth:1000, margin:"0 auto" }}>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:40, marginBottom:80 }}>
          <div>
            <h2 className="orbitron" style={{ fontSize:22, color:"var(--cyan)", marginBottom:20 }}>Our Mission</h2>
            <p style={{ color:"var(--text2)", lineHeight:1.8, marginBottom:16 }}>
              To create a platform where students can showcase their technical skills, 
              collaborate with peers, and gain exposure to industry-level problems.
            </p>
            <p style={{ color:"var(--text2)", lineHeight:1.8 }}>
              TechFest bridges the gap between academics and industry by bringing together 
              students, faculty, mentors, and companies under one roof.
            </p>
          </div>
          <div>
            <h2 className="orbitron" style={{ fontSize:22, color:"var(--orange)", marginBottom:20 }}>The History</h2>
            <p style={{ color:"var(--text2)", lineHeight:1.8, marginBottom:16 }}>
              Started in 2010 with just 5 events and 200 participants, TechFest has 
              grown exponentially over 15 years.
            </p>
            <p style={{ color:"var(--text2)", lineHeight:1.8 }}>
              Today, we host 28+ events, attract 2000+ participants from 80+ colleges,
              and distribute over ₹3 Lakhs in prizes each year.
            </p>
          </div>
        </div>

        <h2 className="section-title" style={{ marginBottom:32, textAlign:"center" }}>Meet The Team</h2>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:20 }}>
          {[
            { name:"Rahul Verma", role:"Fest Director", dept:"CS Final Year" },
            { name:"Priya Nair", role:"Technical Head", dept:"ECE Final Year" },
            { name:"Kiran Mehta", role:"Events Coordinator", dept:"IT 3rd Year" },
            { name:"Ananya Das", role:"PR & Outreach", dept:"CS 3rd Year" },
          ].map((m,i)=>(
            <div key={i} className="card" style={{ textAlign:"center" }}>
              <div style={{
                width:64, height:64, borderRadius:"50%",
                background:`linear-gradient(135deg, var(--cyan) ${i*25}%, var(--orange))`,
                margin:"0 auto 12px",
                display:"flex", alignItems:"center", justifyContent:"center",
                fontSize:24, fontWeight:700, color:"var(--bg)"
              }}>{m.name[0]}</div>
              <div style={{ fontWeight:700, marginBottom:4 }}>{m.name}</div>
              <div style={{ color:"var(--cyan)", fontSize:13, marginBottom:4 }}>{m.role}</div>
              <div style={{ color:"var(--text2)", fontSize:12 }}>{m.dept}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   CONTACT PAGE
═══════════════════════════════════════════════════════════ */
function ContactPage() {
  const [form, setForm] = useState({ name:"", email:"", subject:"", message:"" });
  const [sent, setSent] = useState(false);

  const handleSubmit = () => {
    if (!form.name || !form.email || !form.message) return;
    setSent(true);
    setForm({ name:"", email:"", subject:"", message:"" });
    setTimeout(()=>setSent(false), 5000);
  };

  return (
    <div style={{ paddingTop:64, minHeight:"100vh" }}>
      <div style={{ padding:"64px 48px 40px", background:"var(--bg2)", borderBottom:"1px solid var(--border)" }} className="grid-bg">
        <div style={{ maxWidth:600, margin:"0 auto", position:"relative", zIndex:1 }}>
          <h1 className="section-title" style={{ fontSize:40, marginBottom:12 }}>Contact Us</h1>
          <p style={{ color:"var(--text2)", fontSize:16 }}>Have questions? We'd love to hear from you.</p>
        </div>
      </div>

      <div style={{ padding:"60px 48px", maxWidth:1000, margin:"0 auto", display:"grid", gridTemplateColumns:"1fr 1fr", gap:48 }}>
        <div>
          <h2 className="orbitron" style={{ fontSize:20, color:"var(--cyan)", marginBottom:28 }}>Get In Touch</h2>
          {sent && <div className="alert alert-success">✓ Message sent! We'll respond within 24 hours.</div>}
          <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
            <input placeholder="Your Name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} />
            <input placeholder="Email Address" type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} />
            <input placeholder="Subject" value={form.subject} onChange={e=>setForm({...form,subject:e.target.value})} />
            <textarea placeholder="Your message..." rows={5} value={form.message} onChange={e=>setForm({...form,message:e.target.value})} style={{ resize:"vertical" }} />
            <button className="btn-primary" onClick={handleSubmit}>Send Message →</button>
          </div>
        </div>

        <div>
          <h2 className="orbitron" style={{ fontSize:20, color:"var(--orange)", marginBottom:28 }}>Reach Us</h2>
          <div style={{ display:"flex", flexDirection:"column", gap:20 }}>
            {[
              { icon:"📍", label:"Venue", val:"NIT TechCampus, Main Campus Road, City - 560001" },
              { icon:"📧", label:"Email", val:"techfest2025@nittechcampus.edu" },
              { icon:"📞", label:"Phone", val:"+91 98765 43210 (Rahul, Fest Director)" },
              { icon:"🌐", label:"Website", val:"www.techfest2025.edu.in" },
              { icon:"📱", label:"Social", val:"@TechFest2025 on Instagram, Twitter, LinkedIn" },
            ].map((c,i)=>(
              <div key={i} style={{ display:"flex", gap:16, alignItems:"flex-start" }}>
                <div style={{
                  width:40, height:40, borderRadius:8, flexShrink:0,
                  background:"var(--surface2)", border:"1px solid var(--border)",
                  display:"flex", alignItems:"center", justifyContent:"center", fontSize:18
                }}>{c.icon}</div>
                <div>
                  <div style={{ fontSize:12, color:"var(--text2)", marginBottom:2, textTransform:"uppercase", letterSpacing:1 }}>{c.label}</div>
                  <div style={{ fontSize:14, color:"var(--text)" }}>{c.val}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="card" style={{ marginTop:32 }}>
            <div className="orbitron" style={{ fontSize:14, color:"var(--cyan)", marginBottom:12 }}>IMPORTANT DATES</div>
            {[
              ["Registration Opens", "Mar 1, 2025"],
              ["Registration Closes", "Apr 10, 2025"],
              ["TechFest Begins", "Apr 12, 2025"],
              ["TechFest Ends", "Apr 15, 2025"],
            ].map(([k,v])=>(
              <div key={k} style={{ display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:"1px solid var(--border)" }}>
                <span style={{ color:"var(--text2)", fontSize:14 }}>{k}</span>
                <span style={{ color:"var(--cyan)", fontSize:14, fontWeight:600 }}>{v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   LOGIN PAGE
═══════════════════════════════════════════════════════════ */
function LoginPage({ setPage, onLogin }) {
  const [form, setForm] = useState({ email:"", password:"" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = () => {
    setError(""); setLoading(true);
    setTimeout(() => {
      const user = MOCK_USERS.find(u => u.email===form.email && u.password===form.password);
      if (user) {
        onLogin(user);
        setPage(user.role==="admin"?"admin-dashboard":"student-dashboard");
      } else {
        setError("Invalid email or password. Try arjun@student.edu / pass or admin@techfest.edu / admin");
      }
      setLoading(false);
    }, 800);
  };

  return (
    <div style={{ paddingTop:64, minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center" }} className="grid-bg">
      <div style={{ width:"100%", maxWidth:440, padding:"0 24px" }}>
        <div className="card" style={{ animation:"fadeUp 0.5s ease" }}>
          <div style={{ textAlign:"center", marginBottom:32 }}>
            <div style={{ fontSize:40, marginBottom:12 }}>⚡</div>
            <h2 className="orbitron" style={{ fontSize:22, color:"var(--cyan)", marginBottom:8 }}>Welcome Back</h2>
            <p style={{ color:"var(--text2)", fontSize:14 }}>Sign in to TechFest 2025</p>
          </div>

          {error && <div className="alert alert-error">{error}</div>}

          <div style={{ display:"flex", flexDirection:"column", gap:16, marginBottom:24 }}>
            <div>
              <label style={{ fontSize:12, color:"var(--text2)", display:"block", marginBottom:6, letterSpacing:1, textTransform:"uppercase" }}>Email</label>
              <input type="email" placeholder="your@email.com" value={form.email}
                onChange={e=>setForm({...form,email:e.target.value})}
                onKeyDown={e=>e.key==="Enter"&&handleLogin()} />
            </div>
            <div>
              <label style={{ fontSize:12, color:"var(--text2)", display:"block", marginBottom:6, letterSpacing:1, textTransform:"uppercase" }}>Password</label>
              <input type="password" placeholder="••••••••" value={form.password}
                onChange={e=>setForm({...form,password:e.target.value})}
                onKeyDown={e=>e.key==="Enter"&&handleLogin()} />
            </div>
          </div>

          <button className="btn-primary" style={{ width:"100%", padding:"13px", fontSize:15 }}
            onClick={handleLogin} disabled={loading}>
            {loading ? "Signing In..." : "Sign In →"}
          </button>

          <div className="divider"/>

          <div style={{ textAlign:"center", fontSize:14, color:"var(--text2)" }}>
            Don't have an account?{" "}
            <span style={{ color:"var(--cyan)", cursor:"pointer" }} onClick={()=>setPage("register")}>Register here</span>
          </div>

          <div style={{ marginTop:20, padding:14, background:"var(--surface2)", borderRadius:8, fontSize:12, color:"var(--text2)" }}>
            <strong style={{ color:"var(--cyan)" }}>Demo Accounts:</strong><br/>
            Student: arjun@student.edu / pass<br/>
            Admin: admin@techfest.edu / admin
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   REGISTER PAGE
═══════════════════════════════════════════════════════════ */
function RegisterPage({ setPage, onLogin }) {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ name:"", email:"", phone:"", college:"", dept:"", year:"1", password:"", confirm:"", role:"student" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  const handleNext = () => {
    if (step===1) {
      if (!form.name || !form.email || !form.phone) { setError("Please fill all required fields"); return; }
      if (!form.email.includes("@")) { setError("Enter a valid email"); return; }
    }
    setError(""); setStep(s=>s+1);
  };

  const handleRegister = () => {
    if (!form.password || form.password.length < 6) { setError("Password must be at least 6 characters"); return; }
    if (form.password !== form.confirm) { setError("Passwords don't match"); return; }
    setLoading(true);
    setTimeout(() => {
      const newUser = { ...form, id: Date.now(), verified: false, avatar: form.name[0] };
      setLoading(false);
      setEmailSent(true);
      setStep(3);
    }, 1000);
  };

  if (step===3) return (
    <div style={{ paddingTop:64, minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center" }}>
      <div className="card" style={{ maxWidth:440, textAlign:"center", animation:"fadeUp 0.5s ease" }}>
        <div style={{ fontSize:64, marginBottom:16 }}>📧</div>
        <h2 className="orbitron" style={{ fontSize:20, color:"var(--cyan)", marginBottom:12 }}>Check Your Email!</h2>
        <p style={{ color:"var(--text2)", lineHeight:1.7, marginBottom:24 }}>
          A verification link has been sent to <strong style={{ color:"var(--text)" }}>{form.email}</strong>.
          Please verify your email to complete registration.
        </p>
        <div className="alert alert-info">📨 In a real deployment, Nodemailer sends a verification link via SMTP.</div>
        <button className="btn-primary" style={{ width:"100%", marginTop:8 }} onClick={()=>setPage("login")}>Go to Login →</button>
      </div>
    </div>
  );

  return (
    <div style={{ paddingTop:64, minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center", padding:"80px 24px" }} className="grid-bg">
      <div style={{ width:"100%", maxWidth:520 }}>
        <div className="card" style={{ animation:"fadeUp 0.5s ease" }}>
          <div style={{ textAlign:"center", marginBottom:28 }}>
            <h2 className="orbitron" style={{ fontSize:22, color:"var(--cyan)", marginBottom:8 }}>Create Account</h2>
            <p style={{ color:"var(--text2)", fontSize:14 }}>Step {step} of 2 — {step===1?"Personal Info":"Credentials"}</p>
            <div style={{ display:"flex", gap:4, justifyContent:"center", marginTop:12 }}>
              {[1,2].map(s=>(
                <div key={s} style={{
                  height:4, width:80, borderRadius:2,
                  background: step>=s ? "var(--cyan)" : "var(--border)",
                  transition:"background 0.3s"
                }}/>
              ))}
            </div>
          </div>

          {error && <div className="alert alert-error">{error}</div>}

          {step===1 && (
            <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
                <div>
                  <label style={{ fontSize:12, color:"var(--text2)", display:"block", marginBottom:5 }}>FULL NAME *</label>
                  <input placeholder="Arjun Sharma" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} />
                </div>
                <div>
                  <label style={{ fontSize:12, color:"var(--text2)", display:"block", marginBottom:5 }}>ROLE *</label>
                  <select value={form.role} onChange={e=>setForm({...form,role:e.target.value})}>
                    <option value="student">Student</option>
                    <option value="admin">Organizer</option>
                  </select>
                </div>
              </div>
              <div>
                <label style={{ fontSize:12, color:"var(--text2)", display:"block", marginBottom:5 }}>EMAIL *</label>
                <input type="email" placeholder="you@college.edu" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} />
              </div>
              <div>
                <label style={{ fontSize:12, color:"var(--text2)", display:"block", marginBottom:5 }}>PHONE *</label>
                <input placeholder="9876543210" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} />
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 80px", gap:12 }}>
                <div>
                  <label style={{ fontSize:12, color:"var(--text2)", display:"block", marginBottom:5 }}>COLLEGE</label>
                  <input placeholder="College name" value={form.college} onChange={e=>setForm({...form,college:e.target.value})} />
                </div>
                <div>
                  <label style={{ fontSize:12, color:"var(--text2)", display:"block", marginBottom:5 }}>DEPARTMENT</label>
                  <input placeholder="CS / IT / ECE" value={form.dept} onChange={e=>setForm({...form,dept:e.target.value})} />
                </div>
                <div>
                  <label style={{ fontSize:12, color:"var(--text2)", display:"block", marginBottom:5 }}>YEAR</label>
                  <select value={form.year} onChange={e=>setForm({...form,year:e.target.value})}>
                    {[1,2,3,4].map(y=><option key={y}>{y}</option>)}
                  </select>
                </div>
              </div>
              <button className="btn-primary" style={{ width:"100%", padding:"13px", marginTop:8 }} onClick={handleNext}>Next →</button>
            </div>
          )}

          {step===2 && (
            <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
              <div>
                <label style={{ fontSize:12, color:"var(--text2)", display:"block", marginBottom:5 }}>PASSWORD *</label>
                <input type="password" placeholder="Min 6 characters" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} />
              </div>
              <div>
                <label style={{ fontSize:12, color:"var(--text2)", display:"block", marginBottom:5 }}>CONFIRM PASSWORD *</label>
                <input type="password" placeholder="Repeat password" value={form.confirm} onChange={e=>setForm({...form,confirm:e.target.value})} />
              </div>
              <div className="alert alert-info" style={{ fontSize:12 }}>
                📧 After registration, a verification email will be sent via <strong>Nodemailer</strong> to confirm your account.
              </div>
              <div style={{ display:"flex", gap:12 }}>
                <button className="btn-outline" style={{ flex:1, padding:"13px" }} onClick={()=>setStep(1)}>← Back</button>
                <button className="btn-primary" style={{ flex:2, padding:"13px" }} onClick={handleRegister} disabled={loading}>
                  {loading?"Creating Account...":"Create Account →"}
                </button>
              </div>
            </div>
          )}

          <div className="divider"/>
          <div style={{ textAlign:"center", fontSize:14, color:"var(--text2)" }}>
            Already registered?{" "}
            <span style={{ color:"var(--cyan)", cursor:"pointer" }} onClick={()=>setPage("login")}>Sign in</span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   STUDENT DASHBOARD
═══════════════════════════════════════════════════════════ */
function StudentDashboard({ user, setPage, userRegistrations, onRegister }) {
  const [activeTab, setActiveTab] = useState("overview");
  const myEvents = EVENTS_DATA.filter(e=>userRegistrations.includes(e.id));

  return (
    <div style={{ paddingTop:64, minHeight:"100vh" }}>
      <div style={{ padding:"40px 48px 0", background:"var(--bg2)", borderBottom:"1px solid var(--border)" }}>
        <div style={{ maxWidth:1100, margin:"0 auto" }}>
          <div style={{ display:"flex", gap:20, alignItems:"center", marginBottom:32 }}>
            <div style={{
              width:64, height:64, borderRadius:"50%",
              background:"linear-gradient(135deg,var(--cyan),var(--orange))",
              display:"flex", alignItems:"center", justifyContent:"center",
              fontSize:24, fontWeight:700, color:"var(--bg)"
            }}>{user.name[0]}</div>
            <div>
              <h1 className="orbitron" style={{ fontSize:24, color:"var(--cyan)" }}>{user.name}</h1>
              <div style={{ color:"var(--text2)", fontSize:14 }}>{user.dept} · {user.college} · Year {user.year}</div>
              <span className="tag tag-green" style={{ marginTop:6 }}>✓ Verified</span>
            </div>
          </div>
          <div style={{ display:"flex", gap:4 }}>
            {["overview","my-events","explore"].map(t=>(
              <button key={t} onClick={()=>setActiveTab(t)} style={{
                padding:"10px 20px", border:"none", background:"transparent", cursor:"pointer",
                color: activeTab===t ? "var(--cyan)" : "var(--text2)",
                borderBottom: activeTab===t ? "2px solid var(--cyan)" : "2px solid transparent",
                fontSize:14, fontWeight:600, letterSpacing:1, textTransform:"capitalize",
                transition:"all 0.2s"
              }}>{t.replace("-"," ")}</button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ padding:"40px 48px", maxWidth:1100, margin:"0 auto" }}>
        {activeTab==="overview" && (
          <div style={{ animation:"fadeIn 0.3s ease" }}>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:20, marginBottom:40 }}>
              {[
                { label:"Registered Events", val:myEvents.length, color:"cyan", icon:"🎯" },
                { label:"Upcoming", val:myEvents.length, color:"orange", icon:"📅" },
                { label:"Prizes Eligible", val:`₹${myEvents.reduce((acc,e)=>acc+(parseInt(e.prize.replace(/[^0-9]/g,""))||0),0).toLocaleString()}`, color:"gold", icon:"🏆" },
                { label:"Profile Complete", val:"85%", color:"green", icon:"✅" },
              ].map((s,i)=>(
                <div key={i} className={`stat-card ${s.color}`}>
                  <div style={{ fontSize:28, marginBottom:8 }}>{s.icon}</div>
                  <div className="orbitron" style={{ fontSize:26, fontWeight:900, color:`var(--${s.color==="green"?"text":s.color})` }}>{s.val}</div>
                  <div style={{ color:"var(--text2)", fontSize:13, marginTop:4 }}>{s.label}</div>
                </div>
              ))}
            </div>

            <div style={{ display:"grid", gridTemplateColumns:"2fr 1fr", gap:24 }}>
              <div className="card">
                <h3 className="orbitron" style={{ fontSize:16, color:"var(--cyan)", marginBottom:20 }}>My Registered Events</h3>
                {myEvents.length===0 ? (
                  <div style={{ textAlign:"center", padding:"40px 0", color:"var(--text2)" }}>
                    <div style={{ fontSize:40, marginBottom:12 }}>🎯</div>
                    <div>No events registered yet.</div>
                    <button className="btn-primary" style={{ marginTop:16 }} onClick={()=>setActiveTab("explore")}>Explore Events →</button>
                  </div>
                ) : myEvents.map(ev=>(
                  <div key={ev.id} style={{
                    display:"flex", justifyContent:"space-between", alignItems:"center",
                    padding:"14px 0", borderBottom:"1px solid var(--border)"
                  }}>
                    <div style={{ display:"flex", gap:12, alignItems:"center" }}>
                      <span style={{ fontSize:24 }}>{ev.image}</span>
                      <div>
                        <div style={{ fontWeight:600 }}>{ev.title}</div>
                        <div style={{ fontSize:12, color:"var(--text2)" }}>📅 {ev.date} · 📍 {ev.venue}</div>
                      </div>
                    </div>
                    <div style={{ textAlign:"right" }}>
                      <span className="tag tag-green">Registered</span>
                      <div style={{ fontSize:12, color:"var(--gold)", marginTop:4 }}>{ev.prize}</div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="card">
                <h3 className="orbitron" style={{ fontSize:16, color:"var(--orange)", marginBottom:20 }}>Quick Info</h3>
                {[
                  ["Name", user.name],
                  ["Email", user.email],
                  ["Phone", user.phone || "Not set"],
                  ["College", user.college || "Not set"],
                  ["Department", user.dept || "Not set"],
                  ["Year", `Year ${user.year || "?"}`],
                ].map(([k,v])=>(
                  <div key={k} style={{ padding:"10px 0", borderBottom:"1px solid var(--border)" }}>
                    <div style={{ fontSize:11, color:"var(--text2)", marginBottom:2, textTransform:"uppercase", letterSpacing:1 }}>{k}</div>
                    <div style={{ fontSize:14 }}>{v}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab==="my-events" && (
          <div style={{ animation:"fadeIn 0.3s ease" }}>
            <h2 className="section-title" style={{ marginBottom:28 }}>My Registered Events</h2>
            {myEvents.length===0 ? (
              <div style={{ textAlign:"center", padding:"80px 0", color:"var(--text2)" }}>
                <div style={{ fontSize:56, marginBottom:16 }}>📋</div>
                <div style={{ fontSize:18, marginBottom:8 }}>No registrations yet</div>
                <button className="btn-primary" onClick={()=>setActiveTab("explore")}>Explore Events →</button>
              </div>
            ) : (
              <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:24 }}>
                {myEvents.map(ev=><EventCard key={ev.id} event={ev} setPage={setPage} userRegistrations={userRegistrations} />)}
              </div>
            )}
          </div>
        )}

        {activeTab==="explore" && (
          <div style={{ animation:"fadeIn 0.3s ease" }}>
            <h2 className="section-title" style={{ marginBottom:28 }}>Available Events</h2>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:24 }}>
              {EVENTS_DATA.filter(e=>!userRegistrations.includes(e.id)).map(ev=>(
                <EventCard key={ev.id} event={ev} setPage={setPage} userRegistrations={userRegistrations} onRegister={(e)=>onRegister(e.id)} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   ADMIN DASHBOARD
═══════════════════════════════════════════════════════════ */
function AdminDashboard({ user, allRegistrations }) {
  const [activeTab, setActiveTab] = useState("overview");
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [events, setEvents] = useState(EVENTS_DATA);
  const [newEvent, setNewEvent] = useState({ title:"", category:"Hackathon", date:"", time:"", venue:"", capacity:100, prize:"", duration:"", desc:"" });

  const totalRegistrations = Object.values(allRegistrations).flat().length;

  const handleAddEvent = () => {
    if (!newEvent.title || !newEvent.date) return;
    setEvents(prev=>[...prev, { ...newEvent, id:Date.now(), registered:0, image:"🎯", tags:[], status:"open" }]);
    setShowAddEvent(false);
    setNewEvent({ title:"", category:"Hackathon", date:"", time:"", venue:"", capacity:100, prize:"", duration:"", desc:"" });
  };

  return (
    <div style={{ paddingTop:64, minHeight:"100vh" }}>
      <div style={{ padding:"40px 48px 0", background:"var(--bg2)", borderBottom:"1px solid var(--border)" }}>
        <div style={{ maxWidth:1200, margin:"0 auto" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:28 }}>
            <div>
              <h1 className="orbitron" style={{ fontSize:24, color:"var(--orange)" }}>Admin Panel</h1>
              <div style={{ color:"var(--text2)", fontSize:14 }}>TechFest 2025 — Event Management</div>
            </div>
            <button className="btn-orange" onClick={()=>setShowAddEvent(true)}>+ Add Event</button>
          </div>
          <div style={{ display:"flex", gap:4 }}>
            {["overview","events","registrations","users"].map(t=>(
              <button key={t} onClick={()=>setActiveTab(t)} style={{
                padding:"10px 20px", border:"none", background:"transparent", cursor:"pointer",
                color: activeTab===t ? "var(--orange)" : "var(--text2)",
                borderBottom: activeTab===t ? "2px solid var(--orange)" : "2px solid transparent",
                fontSize:14, fontWeight:600, letterSpacing:1, textTransform:"capitalize", transition:"all 0.2s"
              }}>{t}</button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ padding:"40px 48px", maxWidth:1200, margin:"0 auto" }}>
        {activeTab==="overview" && (
          <div style={{ animation:"fadeIn 0.3s ease" }}>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:20, marginBottom:40 }}>
              {[
                { label:"Total Events", val:events.length, color:"cyan", icon:"🎯" },
                { label:"Total Registrations", val:totalRegistrations, color:"orange", icon:"👥" },
                { label:"Open Events", val:events.filter(e=>e.status==="open").length, color:"green", icon:"✅" },
                { label:"Full Events", val:events.filter(e=>e.status==="full").length, color:"gold", icon:"🔒" },
              ].map((s,i)=>(
                <div key={i} className={`stat-card ${s.color}`}>
                  <div style={{ fontSize:28, marginBottom:8 }}>{s.icon}</div>
                  <div className="orbitron" style={{ fontSize:32, fontWeight:900, color:`var(--${s.color==="green"?"text":s.color})` }}>{s.val}</div>
                  <div style={{ color:"var(--text2)", fontSize:13, marginTop:4 }}>{s.label}</div>
                </div>
              ))}
            </div>

            {/* Capacity bars */}
            <div className="card">
              <h3 className="orbitron" style={{ fontSize:16, color:"var(--orange)", marginBottom:24 }}>Event Capacity Overview</h3>
              {events.slice(0,6).map(ev=>(
                <div key={ev.id} style={{ marginBottom:18 }}>
                  <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6 }}>
                    <span style={{ fontSize:14, fontWeight:600 }}>{ev.title}</span>
                    <span style={{ fontSize:13, color:"var(--text2)" }}>{ev.registered}/{ev.capacity}</span>
                  </div>
                  <div style={{ height:6, background:"rgba(255,255,255,0.06)", borderRadius:3, overflow:"hidden" }}>
                    <div style={{
                      height:"100%",
                      width:`${(ev.registered/ev.capacity)*100}%`,
                      borderRadius:3,
                      background: (ev.registered/ev.capacity)>0.9 ? "linear-gradient(90deg,var(--orange),var(--orange2))" : "linear-gradient(90deg,var(--cyan),var(--cyan2))",
                      transition:"width 1s ease"
                    }}/>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab==="events" && (
          <div style={{ animation:"fadeIn 0.3s ease" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:24 }}>
              <h2 className="section-title">Manage Events</h2>
              <button className="btn-orange" onClick={()=>setShowAddEvent(true)}>+ Add Event</button>
            </div>
            <div className="card" style={{ padding:0, overflow:"hidden" }}>
              <table>
                <thead>
                  <tr>
                    <th>Event</th><th>Category</th><th>Date</th><th>Venue</th>
                    <th>Registrations</th><th>Prize</th><th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {events.map(ev=>(
                    <tr key={ev.id}>
                      <td><div style={{ fontWeight:600 }}>{ev.title}</div></td>
                      <td><span className="tag tag-cyan">{ev.category}</span></td>
                      <td style={{ color:"var(--text2)", fontSize:13 }}>{ev.date}</td>
                      <td style={{ color:"var(--text2)", fontSize:13 }}>{ev.venue}</td>
                      <td>
                        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                          <div style={{ flex:1, height:4, background:"rgba(255,255,255,0.06)", borderRadius:2, overflow:"hidden", width:60 }}>
                            <div style={{ height:"100%", width:`${(ev.registered/ev.capacity)*100}%`, background:"var(--cyan)", borderRadius:2 }}/>
                          </div>
                          <span style={{ fontSize:12, color:"var(--text2)" }}>{ev.registered}/{ev.capacity}</span>
                        </div>
                      </td>
                      <td><span className="tag tag-gold">{ev.prize}</span></td>
                      <td><span className={`tag ${ev.status==="full"?"tag-orange":"tag-green"}`}>{ev.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab==="registrations" && (
          <div style={{ animation:"fadeIn 0.3s ease" }}>
            <h2 className="section-title" style={{ marginBottom:24 }}>Registration Overview</h2>
            <div className="card" style={{ padding:0, overflow:"hidden" }}>
              <table>
                <thead>
                  <tr><th>Event</th><th>Category</th><th>Registered</th><th>Capacity</th><th>Fill Rate</th><th>Status</th></tr>
                </thead>
                <tbody>
                  {events.map(ev=>(
                    <tr key={ev.id}>
                      <td><strong>{ev.title}</strong></td>
                      <td><span className="tag tag-cyan">{ev.category}</span></td>
                      <td style={{ color:"var(--cyan)", fontWeight:700 }}>{ev.registered}</td>
                      <td style={{ color:"var(--text2)" }}>{ev.capacity}</td>
                      <td>
                        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                          <div style={{ width:80, height:4, background:"rgba(255,255,255,0.06)", borderRadius:2, overflow:"hidden" }}>
                            <div style={{ height:"100%", width:`${(ev.registered/ev.capacity)*100}%`, background: (ev.registered/ev.capacity)>.8?"var(--orange)":"var(--cyan)", borderRadius:2 }}/>
                          </div>
                          <span style={{ fontSize:12 }}>{Math.round((ev.registered/ev.capacity)*100)}%</span>
                        </div>
                      </td>
                      <td><span className={`tag ${ev.status==="full"?"tag-orange":"tag-green"}`}>{ev.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab==="users" && (
          <div style={{ animation:"fadeIn 0.3s ease" }}>
            <h2 className="section-title" style={{ marginBottom:24 }}>Registered Users</h2>
            <div className="card" style={{ padding:0, overflow:"hidden" }}>
              <table>
                <thead>
                  <tr><th>Name</th><th>Email</th><th>Role</th><th>College</th><th>Status</th></tr>
                </thead>
                <tbody>
                  {MOCK_USERS.map(u=>(
                    <tr key={u.id}>
                      <td>
                        <div style={{ display:"flex", gap:10, alignItems:"center" }}>
                          <div style={{ width:32, height:32, borderRadius:"50%", background:"linear-gradient(135deg,var(--cyan),var(--orange))", display:"flex", alignItems:"center", justifyContent:"center", fontSize:13, fontWeight:700, color:"var(--bg)" }}>{u.name[0]}</div>
                          <span style={{ fontWeight:600 }}>{u.name}</span>
                        </div>
                      </td>
                      <td style={{ color:"var(--text2)", fontSize:13 }}>{u.email}</td>
                      <td><span className={`tag ${u.role==="admin"?"tag-orange":"tag-cyan"}`}>{u.role}</span></td>
                      <td style={{ color:"var(--text2)", fontSize:13 }}>{u.college || "—"}</td>
                      <td><span className={`tag ${u.verified?"tag-green":"tag-orange"}`}>{u.verified?"Verified":"Pending"}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Add Event Modal */}
      {showAddEvent && (
        <div className="modal-overlay" onClick={()=>setShowAddEvent(false)}>
          <div className="modal-box" onClick={e=>e.stopPropagation()} style={{ maxWidth:560 }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:24 }}>
              <h3 className="orbitron" style={{ fontSize:18, color:"var(--orange)" }}>Add New Event</h3>
              <button onClick={()=>setShowAddEvent(false)} style={{ background:"none", border:"none", color:"var(--text2)", fontSize:20 }}>✕</button>
            </div>
            <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
              <input placeholder="Event Title" value={newEvent.title} onChange={e=>setNewEvent({...newEvent,title:e.target.value})} />
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
                <select value={newEvent.category} onChange={e=>setNewEvent({...newEvent,category:e.target.value})}>
                  {["Hackathon","Competition","CTF","Talk","Academic","Robotics"].map(c=><option key={c}>{c}</option>)}
                </select>
                <input placeholder="Duration (e.g. 6 Hours)" value={newEvent.duration} onChange={e=>setNewEvent({...newEvent,duration:e.target.value})} />
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
                <input type="date" value={newEvent.date} onChange={e=>setNewEvent({...newEvent,date:e.target.value})} />
                <input type="time" value={newEvent.time} onChange={e=>setNewEvent({...newEvent,time:e.target.value})} />
              </div>
              <input placeholder="Venue" value={newEvent.venue} onChange={e=>setNewEvent({...newEvent,venue:e.target.value})} />
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
                <input type="number" placeholder="Capacity" value={newEvent.capacity} onChange={e=>setNewEvent({...newEvent,capacity:+e.target.value})} />
                <input placeholder="Prize (e.g. ₹10,000)" value={newEvent.prize} onChange={e=>setNewEvent({...newEvent,prize:e.target.value})} />
              </div>
              <textarea placeholder="Event description..." rows={3} value={newEvent.desc} onChange={e=>setNewEvent({...newEvent,desc:e.target.value})} style={{ resize:"none" }} />
              <div style={{ display:"flex", gap:12 }}>
                <button className="btn-outline" style={{ flex:1 }} onClick={()=>setShowAddEvent(false)}>Cancel</button>
                <button className="btn-orange" style={{ flex:2 }} onClick={handleAddEvent}>Add Event</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   FOOTER
═══════════════════════════════════════════════════════════ */
function Footer({ setPage }) {
  return (
    <footer style={{ background:"var(--bg2)", borderTop:"1px solid var(--border)", padding:"48px 48px 32px" }}>
      <div style={{ maxWidth:1200, margin:"0 auto" }}>
        <div style={{ display:"grid", gridTemplateColumns:"2fr 1fr 1fr 1fr", gap:40, marginBottom:40 }}>
          <div>
            <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:16 }}>
              <div style={{ width:32, height:32, borderRadius:6, background:"linear-gradient(135deg,var(--cyan),var(--orange))", display:"flex", alignItems:"center", justifyContent:"center" }}>⚡</div>
              <span className="orbitron" style={{ fontSize:16, color:"var(--cyan)", fontWeight:900 }}>TECHFEST 2025</span>
            </div>
            <p style={{ color:"var(--text2)", fontSize:14, lineHeight:1.7, marginBottom:16 }}>
              The annual flagship technical festival of NIT TechCampus. 4 days of innovation, competition, and celebration.
            </p>
            <div style={{ display:"flex", gap:12 }}>
              {["📷","🐦","💼","▶️"].map((icon,i)=>(
                <div key={i} style={{ width:36, height:36, borderRadius:8, border:"1px solid var(--border)", display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer", fontSize:16, transition:"border-color 0.2s" }}
                  onMouseEnter={e=>e.currentTarget.style.borderColor="var(--cyan)"}
                  onMouseLeave={e=>e.currentTarget.style.borderColor="var(--border)"}
                >{icon}</div>
              ))}
            </div>
          </div>
          {[
            { title:"Pages", items:[["home","Home"],["events","Events"],["schedule","Schedule"],["about","About"],["contact","Contact"]] },
            { title:"Events", items:[["events","Hackathons"],["events","Competitions"],["events","CTF"],["events","Workshops"],["events","Talks"]] },
            { title:"Info", items:[["contact","Contact Us"],["about","Our Team"],["contact","Sponsors"],["register","Register"],["login","Login"]] },
          ].map((col,i)=>(
            <div key={i}>
              <div className="orbitron" style={{ fontSize:13, color:"var(--text)", marginBottom:16, letterSpacing:1 }}>{col.title}</div>
              <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
                {col.items.map(([page,label])=>(
                  <span key={label} style={{ color:"var(--text2)", fontSize:14, cursor:"pointer", transition:"color 0.2s" }}
                    onClick={()=>setPage(page)}
                    onMouseEnter={e=>e.currentTarget.style.color="var(--cyan)"}
                    onMouseLeave={e=>e.currentTarget.style.color="var(--text2)"}
                  >{label}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div className="divider" style={{ margin:"0 0 24px" }}/>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <span style={{ color:"var(--text2)", fontSize:13 }}>© 2025 TechFest NIT TechCampus. All rights reserved.</span>
          <div style={{ display:"flex", gap:8 }}>
            <span className="tag tag-cyan">Backend: Vercel</span>
            <span className="tag tag-orange">Frontend: Netlify</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ═══════════════════════════════════════════════════════════
   ROOT APP
═══════════════════════════════════════════════════════════ */
export default function App() {
  const [page, setPage] = useState("home");
  const [user, setUser] = useState(null);
  const [userRegistrations, setUserRegistrations] = useState([]);
  const [allRegistrations, setAllRegistrations] = useState({});

  const handleRegister = (eventId) => {
    if (!user) return;
    setUserRegistrations(prev => prev.includes(eventId) ? prev : [...prev, eventId]);
    setAllRegistrations(prev => ({
      ...prev,
      [user.id]: [...(prev[user.id]||[]), eventId]
    }));
  };

  const noFooter = ["login","register","student-dashboard","admin-dashboard"];

  return (
    <AuthCtx.Provider value={{ user, setUser }}>
      <GlobalStyles/>
      <Navbar page={page} setPage={setPage} user={user} setUser={(u)=>{ setUser(u); setUserRegistrations([]); }}/>
      <main>
        {page==="home" && <HomePage setPage={setPage}/>}
        {page==="events" && <EventsPage setPage={setPage} user={user} userRegistrations={userRegistrations} onRegister={handleRegister}/>}
        {page==="schedule" && <SchedulePage/>}
        {page==="about" && <AboutPage setPage={setPage}/>}
        {page==="contact" && <ContactPage/>}
        {page==="login" && <LoginPage setPage={setPage} onLogin={setUser}/>}
        {page==="register" && <RegisterPage setPage={setPage} onLogin={setUser}/>}
        {page==="student-dashboard" && user?.role==="student" && <StudentDashboard user={user} setPage={setPage} userRegistrations={userRegistrations} onRegister={handleRegister}/>}
        {page==="admin-dashboard" && user?.role==="admin" && <AdminDashboard user={user} allRegistrations={allRegistrations}/>}
      </main>
      {!noFooter.includes(page) && <Footer setPage={setPage}/>}
    </AuthCtx.Provider>
  );
}
