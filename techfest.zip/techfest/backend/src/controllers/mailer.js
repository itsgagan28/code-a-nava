const nodemailer = require('nodemailer');

// Configure transporter (use SMTP env vars in production)
const transporter = nodemailer.createTransport({
  host:   process.env.SMTP_HOST   || 'smtp.gmail.com',
  port:   parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER || 'your@gmail.com',
    pass: process.env.SMTP_PASS || 'your_app_password',
  },
});

const FROM = `"TechFest 2025" <${process.env.SMTP_USER || 'noreply@techfest.edu'}>`;

/* ── Email templates ──────────────────────────────────────── */

// 1. Email verification link
const sendVerificationEmail = async (to, name, token) => {
  const verifyUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/verify-email?token=${token}`;
  await transporter.sendMail({
    from: FROM,
    to,
    subject: '⚡ Verify Your TechFest 2025 Account',
    html: `
      <div style="font-family:sans-serif;max-width:520px;margin:auto;background:#040812;color:#e8f4fd;padding:32px;border-radius:12px">
        <h1 style="color:#00f5ff;font-size:28px;margin-bottom:8px">⚡ TechFest 2025</h1>
        <p style="font-size:16px;color:#7a9bb5">Welcome, <strong style="color:#e8f4fd">${name}</strong>!</p>
        <p style="line-height:1.7;color:#7a9bb5">Please verify your email to complete your registration and start exploring 28+ events.</p>
        <a href="${verifyUrl}" style="display:inline-block;margin-top:20px;padding:14px 28px;background:#00f5ff;color:#040812;text-decoration:none;border-radius:8px;font-weight:700;letter-spacing:1px">
          VERIFY EMAIL →
        </a>
        <p style="margin-top:24px;font-size:12px;color:#7a9bb5">Link expires in 24 hours. If you did not register, ignore this email.</p>
      </div>
    `,
  });
};

// 2. Registration confirmation
const sendRegistrationConfirmation = async (to, userName, eventTitle, venue, date, confirmCode) => {
  await transporter.sendMail({
    from: FROM,
    to,
    subject: `✅ Registration Confirmed: ${eventTitle} — TechFest 2025`,
    html: `
      <div style="font-family:sans-serif;max-width:520px;margin:auto;background:#040812;color:#e8f4fd;padding:32px;border-radius:12px">
        <h1 style="color:#00f5ff">⚡ TechFest 2025</h1>
        <h2 style="color:#ff6b2b">Registration Confirmed!</h2>
        <p>Hi <strong>${userName}</strong>, you're officially registered for:</p>
        <div style="background:#0b1628;border:1px solid rgba(0,245,255,0.2);border-radius:10px;padding:20px;margin:20px 0">
          <h3 style="color:#00f5ff;margin:0 0 12px">${eventTitle}</h3>
          <p style="color:#7a9bb5;margin:4px 0">📅 ${date}</p>
          <p style="color:#7a9bb5;margin:4px 0">📍 ${venue}</p>
          <p style="margin-top:16px">Confirmation Code: <strong style="color:#ffd700;font-size:20px">${confirmCode}</strong></p>
        </div>
        <p style="color:#7a9bb5;font-size:13px">Keep this code handy. Present it at the event entrance. Good luck! 🏆</p>
      </div>
    `,
  });
};

// 3. Password reset
const sendPasswordReset = async (to, name, token) => {
  const resetUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/reset-password?token=${token}`;
  await transporter.sendMail({
    from: FROM,
    to,
    subject: '🔑 Reset Your TechFest 2025 Password',
    html: `
      <div style="font-family:sans-serif;max-width:520px;margin:auto;background:#040812;color:#e8f4fd;padding:32px;border-radius:12px">
        <h1 style="color:#00f5ff">⚡ TechFest 2025</h1>
        <p>Hi <strong>${name}</strong>, we received a request to reset your password.</p>
        <a href="${resetUrl}" style="display:inline-block;margin:20px 0;padding:14px 28px;background:#ff6b2b;color:#fff;text-decoration:none;border-radius:8px;font-weight:700">
          RESET PASSWORD →
        </a>
        <p style="font-size:12px;color:#7a9bb5">This link expires in 1 hour. If you didn't request this, ignore this email.</p>
      </div>
    `,
  });
};

module.exports = { sendVerificationEmail, sendRegistrationConfirmation, sendPasswordReset };
