const mongoose = require('mongoose');

const registrationSchema = new mongoose.Schema({
  user:        { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  event:       { type: mongoose.Schema.Types.ObjectId, ref: 'Event', required: true },
  teamName:    { type: String, default: '' },
  teamSize:    { type: Number, default: 1 },
  members:     [{ name: String, email: String, college: String }],
  paymentStatus: { type: String, enum: ['free','paid','pending'], default: 'free' },
  confirmationCode: { type: String, unique: true },
}, { timestamps: true });

// Prevent duplicate registrations
registrationSchema.index({ user: 1, event: 1 }, { unique: true });

// Generate confirmation code before save
registrationSchema.pre('save', function (next) {
  if (!this.confirmationCode) {
    this.confirmationCode = 'TF25-' + Math.random().toString(36).substring(2,8).toUpperCase();
  }
  next();
});

module.exports = mongoose.model('Registration', registrationSchema);
