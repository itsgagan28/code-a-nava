const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name:         { type: String, required: true, trim: true },
  email:        { type: String, required: true, unique: true, lowercase: true },
  password:     { type: String, required: true, minlength: 6 },
  phone:        { type: String, default: '' },
  college:      { type: String, default: '' },
  department:   { type: String, default: '' },
  year:         { type: Number, default: 1, min: 1, max: 5 },
  role:         { type: String, enum: ['student', 'admin'], default: 'student' },
  isVerified:   { type: Boolean, default: false },
  verifyToken:  { type: String, default: null },
  registeredEvents: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Event' }],
}, { timestamps: true });

// Hash password before saving
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

// Compare password method
userSchema.methods.comparePassword = async function (plain) {
  return bcrypt.compare(plain, this.password);
};

// Strip password from JSON output
userSchema.methods.toJSON = function () {
  const obj = this.toObject();
  delete obj.password;
  delete obj.verifyToken;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
