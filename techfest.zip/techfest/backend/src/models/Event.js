const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  title:       { type: String, required: true, trim: true },
  category:    { type: String, enum: ['Hackathon','Competition','CTF','Talk','Academic','Robotics','Workshop'], required: true },
  description: { type: String, required: true },
  date:        { type: Date, required: true },
  time:        { type: String, required: true },       // e.g. "09:00 AM"
  venue:       { type: String, required: true },
  capacity:    { type: Number, required: true, min: 1 },
  prize:       { type: String, default: 'Certificate' },
  duration:    { type: String, default: '' },          // e.g. "6 Hours"
  tags:        [{ type: String }],
  image:       { type: String, default: '🎯' },
  status:      { type: String, enum: ['open','full','cancelled'], default: 'open' },
  createdBy:   { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  registrations: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Registration' }],
}, { timestamps: true });

// Virtual: registered count
eventSchema.virtual('registeredCount').get(function () {
  return this.registrations?.length ?? 0;
});

// Auto-update status when full
eventSchema.methods.checkCapacity = async function () {
  const count = await mongoose.model('Registration').countDocuments({ event: this._id });
  if (count >= this.capacity && this.status === 'open') {
    this.status = 'full';
    await this.save();
  }
};

module.exports = mongoose.model('Event', eventSchema);
