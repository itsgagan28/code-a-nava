const router  = require('express').Router();
const jwt     = require('jsonwebtoken');
const crypto  = require('crypto');
const User    = require('../models/User');
const { sendVerificationEmail, sendPasswordReset } = require('../controllers/mailer');
const { protect } = require('../middleware/auth');

const signToken = (id) => jwt.sign({ id }, process.env.JWT_SECRET || 'techfest_secret_2025', { expiresIn: '7d' });

/* POST /api/auth/register */
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, phone, college, department, year, role } = req.body;

    if (await User.findOne({ email }))
      return res.status(400).json({ error: 'Email already registered' });

    const verifyToken = crypto.randomBytes(32).toString('hex');
    const user = await User.create({ name, email, password, phone, college, department, year, role: role || 'student', verifyToken });

    // Send verification email (non-blocking)
    sendVerificationEmail(email, name, verifyToken).catch(console.error);

    res.status(201).json({
      message: 'Registered! Please check your email to verify your account.',
      userId: user._id,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* GET /api/auth/verify-email?token=... */
router.get('/verify-email', async (req, res) => {
  try {
    const user = await User.findOne({ verifyToken: req.query.token });
    if (!user) return res.status(400).json({ error: 'Invalid or expired verification link' });

    user.isVerified  = true;
    user.verifyToken = null;
    await user.save();

    res.json({ message: 'Email verified! You can now log in.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* POST /api/auth/login */
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user || !(await user.comparePassword(password)))
      return res.status(401).json({ error: 'Invalid email or password' });

    if (!user.isVerified)
      return res.status(403).json({ error: 'Please verify your email before logging in' });

    res.json({ token: signToken(user._id), user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* GET /api/auth/me */
router.get('/me', protect, (req, res) => res.json(req.user));

/* POST /api/auth/forgot-password */
router.post('/forgot-password', async (req, res) => {
  try {
    const user = await User.findOne({ email: req.body.email });
    if (!user) return res.json({ message: 'If that email exists, a reset link was sent.' });

    const token = crypto.randomBytes(32).toString('hex');
    user.verifyToken = token;
    await user.save();

    await sendPasswordReset(user.email, user.name, token);
    res.json({ message: 'Password reset email sent.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* POST /api/auth/reset-password */
router.post('/reset-password', async (req, res) => {
  try {
    const { token, password } = req.body;
    const user = await User.findOne({ verifyToken: token });
    if (!user) return res.status(400).json({ error: 'Invalid or expired reset link' });

    user.password    = password;
    user.verifyToken = null;
    await user.save();

    res.json({ message: 'Password reset successfully. You can now log in.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
