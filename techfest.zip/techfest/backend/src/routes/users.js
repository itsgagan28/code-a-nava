const router = require('express').Router();
const User   = require('../models/User');
const { protect, adminOnly } = require('../middleware/auth');

/* GET /api/users — admin: list all users */
router.get('/', protect, adminOnly, async (req, res) => {
  try {
    const users = await User.find().select('-password').sort({ createdAt: -1 });
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* GET /api/users/:id */
router.get('/:id', protect, async (req, res) => {
  try {
    if (String(req.user._id) !== req.params.id && req.user.role !== 'admin')
      return res.status(403).json({ error: 'Forbidden' });

    const user = await User.findById(req.params.id).select('-password').populate('registeredEvents', 'title category date');
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* PUT /api/users/:id — update profile */
router.put('/:id', protect, async (req, res) => {
  try {
    if (String(req.user._id) !== req.params.id && req.user.role !== 'admin')
      return res.status(403).json({ error: 'Forbidden' });

    const allowed = ['name', 'phone', 'college', 'department', 'year'];
    const updates = {};
    allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });

    const user = await User.findByIdAndUpdate(req.params.id, updates, { new: true }).select('-password');
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* DELETE /api/users/:id — admin only */
router.delete('/:id', protect, adminOnly, async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.json({ message: 'User deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
