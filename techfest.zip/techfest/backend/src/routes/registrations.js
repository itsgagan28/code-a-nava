const router       = require('express').Router();
const Registration = require('../models/Registration');
const Event        = require('../models/Event');
const User         = require('../models/User');
const { protect, adminOnly, verifiedOnly } = require('../middleware/auth');
const { sendRegistrationConfirmation }     = require('../controllers/mailer');

/* POST /api/registrations — student registers for event */
router.post('/', protect, verifiedOnly, async (req, res) => {
  try {
    const { eventId, teamName, teamSize, members } = req.body;

    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    if (event.status === 'full') return res.status(400).json({ error: 'Event is full' });
    if (event.status === 'cancelled') return res.status(400).json({ error: 'Event is cancelled' });

    // Check duplicate
    const exists = await Registration.findOne({ user: req.user._id, event: eventId });
    if (exists) return res.status(400).json({ error: 'Already registered for this event' });

    // Create registration
    const reg = await Registration.create({
      user: req.user._id,
      event: eventId,
      teamName: teamName || '',
      teamSize: teamSize || 1,
      members:  members  || [],
    });

    // Update event and user references
    await Event.findByIdAndUpdate(eventId, { $push: { registrations: reg._id } });
    await User.findByIdAndUpdate(req.user._id, { $push: { registeredEvents: eventId } });

    // Check if now full
    await event.checkCapacity();

    // Send confirmation email (non-blocking)
    sendRegistrationConfirmation(
      req.user.email,
      req.user.name,
      event.title,
      event.venue,
      new Date(event.date).toLocaleDateString('en-IN', { weekday:'long', day:'numeric', month:'long' }),
      reg.confirmationCode
    ).catch(console.error);

    res.status(201).json({ message: 'Registration successful!', confirmationCode: reg.confirmationCode, registration: reg });
  } catch (err) {
    if (err.code === 11000) return res.status(400).json({ error: 'Already registered for this event' });
    res.status(500).json({ error: err.message });
  }
});

/* GET /api/registrations/mine — student's registrations */
router.get('/mine', protect, async (req, res) => {
  try {
    const regs = await Registration.find({ user: req.user._id }).populate('event');
    res.json(regs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* GET /api/registrations/event/:eventId — admin: all registrations for event */
router.get('/event/:eventId', protect, adminOnly, async (req, res) => {
  try {
    const regs = await Registration.find({ event: req.params.eventId }).populate('user', 'name email college department');
    res.json(regs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* GET /api/registrations — admin: all registrations */
router.get('/', protect, adminOnly, async (req, res) => {
  try {
    const regs = await Registration.find().populate('user', 'name email').populate('event', 'title category');
    res.json(regs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* DELETE /api/registrations/:id — cancel registration */
router.delete('/:id', protect, async (req, res) => {
  try {
    const reg = await Registration.findById(req.params.id);
    if (!reg) return res.status(404).json({ error: 'Registration not found' });
    if (String(reg.user) !== String(req.user._id) && req.user.role !== 'admin')
      return res.status(403).json({ error: 'Forbidden' });

    await Event.findByIdAndUpdate(reg.event, { $pull: { registrations: reg._id }, status: 'open' });
    await User.findByIdAndUpdate(reg.user, { $pull: { registeredEvents: reg.event } });
    await reg.deleteOne();

    res.json({ message: 'Registration cancelled' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
