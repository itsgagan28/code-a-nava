# 🚀 JobBoard Application

A full-stack Job Board platform where employers can post jobs and candidates can search, save, and apply with resume uploads.

---

## 📁 Project Structure

```
jobboard/
├── backend/        → Node.js + Express API (deploy on Vercel)
└── frontend/       → React app (deploy on Netlify)
```

---

## ⚙️ Tech Stack

**Backend:** Node.js, Express, MongoDB (Mongoose), JWT Auth, Cloudinary (file uploads), Vercel  
**Frontend:** React 18, React Router v6, Axios, React Hot Toast, Netlify

---

## 🛠️ Setup Instructions

### 1. Backend Setup

```bash
cd backend
npm install
cp .env.example .env
# Fill in your .env values (see below)
npm run dev
```

**Environment Variables (backend/.env):**
```
PORT=5000
MONGO_URI=mongodb+srv://<user>:<pass>@cluster.mongodb.net/jobboard
JWT_SECRET=your_jwt_secret_here
JWT_EXPIRE=7d
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
FRONTEND_URL=http://localhost:3000
```

> Get MongoDB URI from [MongoDB Atlas](https://cloud.mongodb.com)  
> Get Cloudinary credentials from [cloudinary.com](https://cloudinary.com)

---

### 2. Frontend Setup

```bash
cd frontend
npm install
cp .env.example .env
# Set REACT_APP_API_URL to your backend URL
npm start
```

**Environment Variables (frontend/.env):**
```
REACT_APP_API_URL=http://localhost:5000/api
```

---

## 🚀 Deployment

### Deploy Backend → Vercel

1. Push `backend/` to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → Import Project
3. Set root directory to `backend`
4. Add all environment variables in Vercel dashboard
5. Deploy! Your API URL will be `https://your-project.vercel.app`

### Deploy Frontend → Netlify

1. Push `frontend/` to a GitHub repo
2. Go to [netlify.com](https://netlify.com) → New site from Git
3. Build command: `npm run build`
4. Publish directory: `build`
5. Add environment variable: `REACT_APP_API_URL=https://your-backend.vercel.app/api`
6. Deploy!

> The `netlify.toml` file handles SPA routing automatically.

---

## ✨ Features

### For Candidates
- Register / Login with JWT auth
- Browse and search/filter jobs
- Save jobs for later
- Apply with cover letter + resume upload
- Track application status (pending, reviewing, shortlisted, rejected, hired)
- Update profile, skills, bio
- Upload resume to Cloudinary

### For Employers
- Register / Login
- Post, edit, delete job listings
- Set job type, category, salary, skills, deadlines
- View all applicants for each job
- Update applicant status and add notes
- Upload company logo

### General
- Full text search on jobs
- Filter by category, job type, experience level, location
- Pagination
- Rate limiting on API
- Mobile responsive design

---

## 📡 API Endpoints

| Method | Route | Auth | Description |
|--------|-------|------|-------------|
| POST | `/api/auth/register` | No | Register user |
| POST | `/api/auth/login` | No | Login |
| GET | `/api/auth/me` | Yes | Get current user |
| GET | `/api/jobs` | No | List jobs (with filters) |
| GET | `/api/jobs/:id` | No | Get job detail |
| POST | `/api/jobs` | Employer | Create job |
| PUT | `/api/jobs/:id` | Employer | Update job |
| DELETE | `/api/jobs/:id` | Employer | Delete job |
| GET | `/api/jobs/employer/my-jobs` | Employer | My job listings |
| POST | `/api/applications` | Candidate | Apply for job |
| GET | `/api/applications/my-applications` | Candidate | My applications |
| GET | `/api/applications/job/:jobId` | Employer | Job's applicants |
| PUT | `/api/applications/:id/status` | Employer | Update app status |
| DELETE | `/api/applications/:id` | Candidate | Withdraw application |
| PUT | `/api/users/profile` | Yes | Update profile |
| POST | `/api/users/upload-resume` | Candidate | Upload resume |
| POST | `/api/users/upload-logo` | Employer | Upload company logo |
| POST | `/api/users/save-job/:jobId` | Candidate | Toggle save job |
