const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { protect } = require('../middleware/auth');
const { uploadResume, uploadLogo } = require('../config/cloudinary');

// @PUT /api/users/profile
router.put('/profile', protect, async (req, res) => {
  try {
    const allowedFields = ['name', 'bio', 'location', 'skills', 'companyName', 'companyDescription', 'companyWebsite'];
    const updates = {};
    allowedFields.forEach(field => {
      if (req.body[field] !== undefined) updates[field] = req.body[field];
    });
    const user = await User.findByIdAndUpdate(req.user._id, updates, { new: true, runValidators: true });
    res.json({ success: true, user });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

// @POST /api/users/upload-resume
router.post('/upload-resume', protect, uploadResume.single('resume'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });
    const resume = { url: req.file.path, publicId: req.file.filename, originalName: req.file.originalname };
    const user = await User.findByIdAndUpdate(req.user._id, { resume }, { new: true });
    res.json({ success: true, resume: user.resume });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

// @POST /api/users/upload-logo
router.post('/upload-logo', protect, uploadLogo.single('logo'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });
    const companyLogo = { url: req.file.path, publicId: req.file.filename };
    const user = await User.findByIdAndUpdate(req.user._id, { companyLogo }, { new: true });
    res.json({ success: true, companyLogo: user.companyLogo });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

// @POST /api/users/save-job/:jobId
router.post('/save-job/:jobId', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    const jobId = req.params.jobId;
    const isSaved = user.savedJobs.includes(jobId);
    if (isSaved) {
      user.savedJobs = user.savedJobs.filter(id => id.toString() !== jobId);
    } else {
      user.savedJobs.push(jobId);
    }
    await user.save();
    res.json({ success: true, saved: !isSaved, savedJobs: user.savedJobs });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

module.exports = router;
