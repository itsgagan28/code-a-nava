const express = require('express');
const router = express.Router();
const Application = require('../models/Application');
const Job = require('../models/Job');
const { protect, authorize } = require('../middleware/auth');
const { uploadResume } = require('../config/cloudinary');

// @POST /api/applications — candidate applies
router.post('/', protect, authorize('candidate'), uploadResume.single('resume'), async (req, res) => {
  try {
    const { jobId, coverLetter } = req.body;
    const job = await Job.findById(jobId);
    if (!job || !job.isActive) {
      return res.status(404).json({ success: false, message: 'Job not found or inactive' });
    }
    const existing = await Application.findOne({ job: jobId, candidate: req.user._id });
    if (existing) {
      return res.status(400).json({ success: false, message: 'You already applied for this job' });
    }

    let resumeData = req.user.resume;
    if (req.file) {
      resumeData = { url: req.file.path, publicId: req.file.filename, originalName: req.file.originalname };
    }

    const application = await Application.create({
      job: jobId,
      candidate: req.user._id,
      employer: job.employer,
      coverLetter,
      resume: resumeData
    });

    job.applicationsCount += 1;
    await job.save();

    res.status(201).json({ success: true, application });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ success: false, message: 'You already applied for this job' });
    }
    res.status(400).json({ success: false, message: error.message });
  }
});

// @GET /api/applications/my-applications — candidate's own
router.get('/my-applications', protect, authorize('candidate'), async (req, res) => {
  try {
    const applications = await Application.find({ candidate: req.user._id })
      .populate('job', 'title companyName location jobType isActive')
      .sort({ appliedAt: -1 });
    res.json({ success: true, applications });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @GET /api/applications/job/:jobId — employer sees applicants
router.get('/job/:jobId', protect, authorize('employer'), async (req, res) => {
  try {
    const job = await Job.findById(req.params.jobId);
    if (!job || job.employer.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }
    const applications = await Application.find({ job: req.params.jobId })
      .populate('candidate', 'name email skills bio location resume')
      .sort({ appliedAt: -1 });
    res.json({ success: true, applications });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @PUT /api/applications/:id/status — employer updates status
router.put('/:id/status', protect, authorize('employer'), async (req, res) => {
  try {
    const { status, employerNotes } = req.body;
    const application = await Application.findById(req.params.id);
    if (!application) return res.status(404).json({ success: false, message: 'Application not found' });
    if (application.employer.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }
    application.status = status;
    if (employerNotes) application.employerNotes = employerNotes;
    await application.save();
    res.json({ success: true, application });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

// @DELETE /api/applications/:id — candidate withdraws
router.delete('/:id', protect, authorize('candidate'), async (req, res) => {
  try {
    const application = await Application.findById(req.params.id);
    if (!application) return res.status(404).json({ success: false, message: 'Application not found' });
    if (application.candidate.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }
    await application.deleteOne();
    await Job.findByIdAndUpdate(application.job, { $inc: { applicationsCount: -1 } });
    res.json({ success: true, message: 'Application withdrawn' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
