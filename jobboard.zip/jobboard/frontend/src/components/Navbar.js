import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Navbar.css';

export default function Navbar() {
  const { user, logoutUser } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    logoutUser();
    navigate('/');
    setMenuOpen(false);
  };

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        <Link to="/" className="navbar-logo">
          <span className="logo-icon">⬡</span>
          <span>JobBoard</span>
        </Link>

        <div className={`navbar-links ${menuOpen ? 'open' : ''}`}>
          <Link to="/jobs" className={isActive('/jobs') ? 'active' : ''} onClick={() => setMenuOpen(false)}>Browse Jobs</Link>
          {user && (
            <>
              <Link to="/dashboard" className={isActive('/dashboard') ? 'active' : ''} onClick={() => setMenuOpen(false)}>Dashboard</Link>
              {user.role === 'candidate' && (
                <>
                  <Link to="/my-applications" className={isActive('/my-applications') ? 'active' : ''} onClick={() => setMenuOpen(false)}>Applications</Link>
                  <Link to="/saved-jobs" className={isActive('/saved-jobs') ? 'active' : ''} onClick={() => setMenuOpen(false)}>Saved</Link>
                </>
              )}
              {user.role === 'employer' && (
                <Link to="/post-job" className={isActive('/post-job') ? 'active' : ''} onClick={() => setMenuOpen(false)}>Post Job</Link>
              )}
            </>
          )}
        </div>

        <div className="navbar-actions">
          {user ? (
            <div className="navbar-user">
              <Link to="/profile" className="user-chip" onClick={() => setMenuOpen(false)}>
                <span className="user-avatar">{user.name.charAt(0).toUpperCase()}</span>
                <span className="user-name">{user.name.split(' ')[0]}</span>
              </Link>
              <button className="btn-secondary btn-sm" onClick={handleLogout}>Logout</button>
            </div>
          ) : (
            <div className="auth-buttons">
              <Link to="/login"><button className="btn-secondary btn-sm">Sign In</button></Link>
              <Link to="/register"><button className="btn-primary btn-sm">Get Started</button></Link>
            </div>
          )}
          <button className="hamburger" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? '✕' : '☰'}
          </button>
        </div>
      </div>
    </nav>
  );
}
