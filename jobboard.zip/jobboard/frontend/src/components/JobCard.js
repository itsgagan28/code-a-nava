import React from 'react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import './JobCard.css';

const typeColors = {
  'full-time': 'badge-green',
  'part-time': 'badge-blue',
  'contract': 'badge-yellow',
  'internship': 'badge-accent',
  'remote': 'badge-accent',
};

export default function JobCard({ job, saved, onSave }) {
  const timeAgo = formatDistanceToNow(new Date(job.createdAt), { addSuffix: true });

  return (
    <div className="job-card card">
      <div className="job-card-header">
        <div className="company-logo-placeholder">
          {job.companyName?.charAt(0).toUpperCase() || 'C'}
        </div>
        <div className="job-header-info">
          <div className="company-name">{job.companyName}</div>
          <div className="job-meta">{job.location} · {timeAgo}</div>
        </div>
        {onSave && (
          <button className={`save-btn ${saved ? 'saved' : ''}`} onClick={() => onSave(job._id)}>
            {saved ? '♥' : '♡'}
          </button>
        )}
      </div>

      <Link to={`/jobs/${job._id}`} className="job-title-link">
        <h3 className="job-title">{job.title}</h3>
      </Link>

      <div className="job-tags">
        <span className={`badge ${typeColors[job.jobType] || 'badge-gray'}`}>{job.jobType}</span>
        <span className="badge badge-gray">{job.category}</span>
        <span className="badge badge-gray">{job.experienceLevel}</span>
      </div>

      {job.salary?.min && (
        <div className="salary-info">
          💰 ${job.salary.min.toLocaleString()}
          {job.salary.max ? ` – $${job.salary.max.toLocaleString()}` : '+'}
          <span> / {job.salary.period}</span>
        </div>
      )}

      <div className="job-card-footer">
        <span className="applicants-count">👥 {job.applicationsCount} applicants</span>
        <Link to={`/jobs/${job._id}`}>
          <button className="btn-primary">View Job</button>
        </Link>
      </div>
    </div>
  );
}
