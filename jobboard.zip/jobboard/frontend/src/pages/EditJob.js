import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getJob, updateJob, deleteJob } from '../utils/api';
import toast from 'react-hot-toast';

const CATEGORIES = ['technology', 'marketing', 'design', 'finance', 'healthcare', 'education', 'sales', 'operations', 'hr', 'other'];
const JOB_TYPES = ['full-time', 'part-time', 'contract', 'internship', 'remote'];
const EXP_LEVELS = ['entry', 'mid', 'senior', 'lead', 'executive'];

export default function EditJob() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState(null);

  useEffect(() => {
    getJob(id).then(res => {
      const j = res.data.job;
      setForm({
        title: j.title, description: j.description, requirements: j.requirements || '',
        location: j.location, jobType: j.jobType, category: j.category,
        experienceLevel: j.experienceLevel, isActive: j.isActive,
        salaryMin: j.salary?.min || '', salaryMax: j.salary?.max || '',
        salaryPeriod: j.salary?.period || 'yearly',
        skills: j.skills?.join(', ') || '',
        applicationDeadline: j.applicationDeadline ? j.applicationDeadline.split('T')[0] : ''
      });
    }).catch(() => navigate('/dashboard'));
  }, [id]);

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = { ...form, skills: form.skills ? form.skills.split(',').map(s => s.trim()).filter(Boolean) : [],
        salary: form.salaryMin ? { min: +form.salaryMin, max: form.salaryMax ? +form.salaryMax : undefined, period: form.salaryPeriod } : undefined };
      await updateJob(id, data);
      toast.success('Job updated!');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    }
    setLoading(false);
  };

  const handleDelete = async () => {
    if (!window.confirm('Delete this job and all its applications?')) return;
    try {
      await deleteJob(id);
      toast.success('Job deleted');
      navigate('/dashboard');
    } catch {
      toast.error('Delete failed');
    }
  };

  if (!form) return <div className="page-container" style={{ textAlign: 'center', paddingTop: 80 }}>Loading...</div>;

  return (
    <div className="page-container">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <h1 className="section-title" style={{ margin: 0 }}>Edit Job</h1>
        <button className="btn-danger" onClick={handleDelete}>Delete Job</button>
      </div>
      <div className="card" style={{ maxWidth: 780 }}>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Job Title *</label>
            <input name="title" value={form.title} onChange={handleChange} required />
          </div>
          <div className="form-row">
            <div className="form-group"><label>Category</label><select name="category" value={form.category} onChange={handleChange}>{CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}</select></div>
            <div className="form-group"><label>Job Type</label><select name="jobType" value={form.jobType} onChange={handleChange}>{JOB_TYPES.map(t => <option key={t} value={t}>{t}</option>)}</select></div>
          </div>
          <div className="form-row">
            <div className="form-group"><label>Location</label><input name="location" value={form.location} onChange={handleChange} required /></div>
            <div className="form-group"><label>Experience</label><select name="experienceLevel" value={form.experienceLevel} onChange={handleChange}>{EXP_LEVELS.map(l => <option key={l} value={l}>{l}</option>)}</select></div>
          </div>
          <div className="form-group"><label>Description</label><textarea name="description" rows={6} value={form.description} onChange={handleChange} required /></div>
          <div className="form-group"><label>Requirements</label><textarea name="requirements" rows={4} value={form.requirements} onChange={handleChange} /></div>
          <div className="form-group"><label>Skills (comma separated)</label><input name="skills" value={form.skills} onChange={handleChange} /></div>
          <div className="form-group" style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <input type="checkbox" name="isActive" checked={form.isActive} onChange={handleChange} style={{ width: 'auto' }} />
            <label style={{ margin: 0 }}>Job is Active</label>
          </div>
          <button type="submit" className="btn-primary" style={{ width: '100%', padding: 14 }} disabled={loading}>
            {loading ? 'Saving...' : 'Save Changes'}
          </button>
        </form>
      </div>
    </div>
  );
}
