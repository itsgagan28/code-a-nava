import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { register } from '../utils/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import './Auth.css';

export default function Register() {
  const { loginUser } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'candidate', companyName: '' });
  const [loading, setLoading] = useState(false);

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await register(form);
      loginUser(res.data.token, res.data.user);
      toast.success('Account created! Welcome 🎉');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Registration failed');
    }
    setLoading(false);
  };

  return (
    <div className="auth-page">
      <div className="auth-card card">
        <div className="auth-logo">⬡ JobBoard</div>
        <h1 className="auth-title">Create Account</h1>
        <p className="auth-subtitle">Join thousands of professionals</p>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>I am a...</label>
            <div className="role-toggle">
              <button type="button" className={`role-btn ${form.role === 'candidate' ? 'active' : ''}`} onClick={() => setForm({ ...form, role: 'candidate' })}>🎯 Job Seeker</button>
              <button type="button" className={`role-btn ${form.role === 'employer' ? 'active' : ''}`} onClick={() => setForm({ ...form, role: 'employer' })}>🏢 Employer</button>
            </div>
          </div>
          <div className="form-group">
            <label>Full Name</label>
            <input type="text" name="name" placeholder="John Doe" value={form.name} onChange={handleChange} required />
          </div>
          {form.role === 'employer' && (
            <div className="form-group">
              <label>Company Name</label>
              <input type="text" name="companyName" placeholder="Acme Corp" value={form.companyName} onChange={handleChange} required />
            </div>
          )}
          <div className="form-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="you@example.com" value={form.email} onChange={handleChange} required />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Min. 6 characters" value={form.password} onChange={handleChange} required minLength={6} />
          </div>
          <button type="submit" className="btn-primary auth-btn" disabled={loading}>
            {loading ? 'Creating account...' : 'Create Account'}
          </button>
        </form>

        <p className="auth-footer">
          Already have an account? <Link to="/login">Sign in</Link>
        </p>
      </div>
    </div>
  );
}
