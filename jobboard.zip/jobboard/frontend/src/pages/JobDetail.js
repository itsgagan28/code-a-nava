import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getJob, applyForJob, saveJob } from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { formatDistanceToNow } from 'date-fns';
import toast from 'react-hot-toast';
import './JobDetail.css';

export default function JobDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showApplyForm, setShowApplyForm] = useState(false);
  const [coverLetter, setCoverLetter] = useState('');
  const [resume, setResume] = useState(null);
  const [applying, setApplying] = useState(false);
  const [applied, setApplied] = useState(false);

  useEffect(() => {
    getJob(id).then(res => { setJob(res.data.job); setLoading(false); }).catch(() => { toast.error('Job not found'); navigate('/jobs'); });
  }, [id]);

  const handleApply = async (e) => {
    e.preventDefault();
    if (!user) return navigate('/login');
    setApplying(true);
    try {
      const formData = new FormData();
      formData.append('jobId', id);
      formData.append('coverLetter', coverLetter);
      if (resume) formData.append('resume', resume);
      await applyForJob(formData);
      setApplied(true);
      setShowApplyForm(false);
      toast.success('Application submitted! 🎉');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to apply');
    }
    setApplying(false);
  };

  if (loading) return <div className="page-container" style={{ textAlign: 'center', paddingTop: 80 }}>Loading...</div>;
  if (!job) return null;

  return (
    <div className="job-detail page-container">
      <div className="job-detail-layout">
        {/* Main content */}
        <main>
          <div className="job-detail-header card">
            <div className="job-detail-company">
              <div className="detail-logo">{job.companyName?.charAt(0)}</div>
              <div>
                <div className="detail-company-name">{job.companyName}</div>
                <div className="detail-meta">{job.location} · {formatDistanceToNow(new Date(job.createdAt), { addSuffix: true })}</div>
              </div>
            </div>
            <h1 className="detail-title">{job.title}</h1>
            <div className="detail-tags">
              <span className="badge badge-accent">{job.jobType}</span>
              <span className="badge badge-gray">{job.category}</span>
              <span className="badge badge-gray">{job.experienceLevel} level</span>
              {job.salary?.min && <span className="badge badge-green">${job.salary.min.toLocaleString()}{job.salary.max ? `–$${job.salary.max.toLocaleString()}` : '+'} / {job.salary.period}</span>}
            </div>
          </div>

          <div className="card" style={{ marginTop: 16 }}>
            <h2 style={{ marginBottom: 16 }}>Job Description</h2>
            <div className="detail-body">{job.description}</div>
          </div>

          {job.requirements && (
            <div className="card" style={{ marginTop: 16 }}>
              <h2 style={{ marginBottom: 16 }}>Requirements</h2>
              <div className="detail-body">{job.requirements}</div>
            </div>
          )}

          {job.skills?.length > 0 && (
            <div className="card" style={{ marginTop: 16 }}>
              <h2 style={{ marginBottom: 16 }}>Skills</h2>
              <div className="skills-list">{job.skills.map(s => <span key={s} className="badge badge-accent">{s}</span>)}</div>
            </div>
          )}
        </main>

        {/* Sidebar */}
        <aside>
          <div className="apply-card card">
            <div className="apply-stats">
              <div><span className="stat-val">{job.applicationsCount}</span><span>Applicants</span></div>
              <div><span className="stat-val">{job.views}</span><span>Views</span></div>
            </div>
            <hr className="divider" />
            {applied ? (
              <div className="applied-badge">✅ Application Submitted</div>
            ) : user?.role === 'candidate' ? (
              <button className="btn-primary" style={{ width: '100%' }} onClick={() => setShowApplyForm(!showApplyForm)}>
                {showApplyForm ? 'Cancel' : 'Apply Now'}
              </button>
            ) : !user ? (
              <button className="btn-primary" style={{ width: '100%' }} onClick={() => navigate('/login')}>Login to Apply</button>
            ) : null}

            {showApplyForm && (
              <form onSubmit={handleApply} style={{ marginTop: 20 }}>
                <div className="form-group">
                  <label>Cover Letter</label>
                  <textarea rows={5} placeholder="Tell them why you're a great fit..." value={coverLetter} onChange={e => setCoverLetter(e.target.value)} />
                </div>
                <div className="form-group">
                  <label>Resume (optional — uses profile resume if not uploaded)</label>
                  <input type="file" accept=".pdf,.doc,.docx" onChange={e => setResume(e.target.files[0])} style={{ padding: '8px 0', border: 'none', background: 'transparent' }} />
                </div>
                <button type="submit" className="btn-primary" style={{ width: '100%' }} disabled={applying}>
                  {applying ? 'Submitting...' : 'Submit Application'}
                </button>
              </form>
            )}
          </div>

          {job.employer && (
            <div className="card" style={{ marginTop: 16 }}>
              <h3 style={{ marginBottom: 12 }}>About the Company</h3>
              <div style={{ fontWeight: 600 }}>{job.employer.companyName}</div>
              {job.employer.companyDescription && <p style={{ color: 'var(--muted)', fontSize: 14, marginTop: 8 }}>{job.employer.companyDescription}</p>}
              {job.employer.companyWebsite && <a href={job.employer.companyWebsite} target="_blank" rel="noreferrer" style={{ fontSize: 13 }}>🌐 Visit Website</a>}
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}
