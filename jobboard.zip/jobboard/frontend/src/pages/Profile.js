import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { updateProfile, uploadResume, uploadLogo } from '../utils/api';
import toast from 'react-hot-toast';

export default function Profile() {
  const { user, setUser } = useAuth();
  const [form, setForm] = useState({
    name: user.name, bio: user.bio || '', location: user.location || '',
    skills: user.skills?.join(', ') || '',
    companyName: user.companyName || '', companyDescription: user.companyDescription || '',
    companyWebsite: user.companyWebsite || ''
  });
  const [loading, setLoading] = useState(false);
  const [resumeFile, setResumeFile] = useState(null);
  const [logoFile, setLogoFile] = useState(null);

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSave = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = { ...form, skills: form.skills ? form.skills.split(',').map(s => s.trim()).filter(Boolean) : [] };
      const res = await updateProfile(data);
      setUser(prev => ({ ...prev, ...res.data.user }));
      toast.success('Profile updated!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    }
    setLoading(false);
  };

  const handleResumeUpload = async () => {
    if (!resumeFile) return;
    const fd = new FormData();
    fd.append('resume', resumeFile);
    try {
      const res = await uploadResume(fd);
      setUser(prev => ({ ...prev, resume: res.data.resume }));
      toast.success('Resume uploaded!');
    } catch {
      toast.error('Upload failed');
    }
  };

  const handleLogoUpload = async () => {
    if (!logoFile) return;
    const fd = new FormData();
    fd.append('logo', logoFile);
    try {
      const res = await uploadLogo(fd);
      setUser(prev => ({ ...prev, companyLogo: res.data.companyLogo }));
      toast.success('Logo uploaded!');
    } catch {
      toast.error('Upload failed');
    }
  };

  return (
    <div className="page-container">
      <h1 className="section-title">Profile Settings</h1>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 24, alignItems: 'start' }}>
        <div className="card">
          <form onSubmit={handleSave}>
            <div className="form-group">
              <label>Full Name</label>
              <input name="name" value={form.name} onChange={handleChange} required />
            </div>
            {user.role === 'candidate' && (
              <>
                <div className="form-group">
                  <label>Bio</label>
                  <textarea name="bio" rows={3} placeholder="Tell employers about yourself..." value={form.bio} onChange={handleChange} />
                </div>
                <div className="form-group">
                  <label>Location</label>
                  <input name="location" placeholder="e.g. San Francisco, CA" value={form.location} onChange={handleChange} />
                </div>
                <div className="form-group">
                  <label>Skills (comma separated)</label>
                  <input name="skills" placeholder="React, Python, Design..." value={form.skills} onChange={handleChange} />
                </div>
              </>
            )}
            {user.role === 'employer' && (
              <>
                <div className="form-group">
                  <label>Company Name</label>
                  <input name="companyName" value={form.companyName} onChange={handleChange} />
                </div>
                <div className="form-group">
                  <label>Company Description</label>
                  <textarea name="companyDescription" rows={3} value={form.companyDescription} onChange={handleChange} />
                </div>
                <div className="form-group">
                  <label>Company Website</label>
                  <input name="companyWebsite" placeholder="https://yourcompany.com" value={form.companyWebsite} onChange={handleChange} />
                </div>
              </>
            )}
            <button type="submit" className="btn-primary" disabled={loading}>{loading ? 'Saving...' : 'Save Profile'}</button>
          </form>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {user.role === 'candidate' && (
            <div className="card">
              <h3 style={{ marginBottom: 16 }}>Resume</h3>
              {user.resume?.url && (
                <div style={{ marginBottom: 12 }}>
                  <a href={user.resume.url} target="_blank" rel="noreferrer" className="btn-secondary" style={{ display: 'block', textAlign: 'center', padding: '8px', borderRadius: 8 }}>
                    📄 View Current Resume
                  </a>
                </div>
              )}
              <div className="form-group">
                <input type="file" accept=".pdf,.doc,.docx" onChange={e => setResumeFile(e.target.files[0])} style={{ border: 'none', background: 'transparent', padding: '4px 0' }} />
              </div>
              <button className="btn-secondary" style={{ width: '100%' }} onClick={handleResumeUpload} disabled={!resumeFile}>Upload Resume</button>
            </div>
          )}

          {user.role === 'employer' && (
            <div className="card">
              <h3 style={{ marginBottom: 16 }}>Company Logo</h3>
              {user.companyLogo?.url && <img src={user.companyLogo.url} alt="logo" style={{ width: 80, height: 80, objectFit: 'cover', borderRadius: 10, marginBottom: 12 }} />}
              <div className="form-group">
                <input type="file" accept="image/*" onChange={e => setLogoFile(e.target.files[0])} style={{ border: 'none', background: 'transparent', padding: '4px 0' }} />
              </div>
              <button className="btn-secondary" style={{ width: '100%' }} onClick={handleLogoUpload} disabled={!logoFile}>Upload Logo</button>
            </div>
          )}

          <div className="card">
            <h3 style={{ marginBottom: 8 }}>Account Info</h3>
            <div style={{ color: 'var(--muted)', fontSize: 14 }}>
              <div>📧 {user.email}</div>
              <div style={{ marginTop: 6 }}>🎭 Role: <span style={{ color: 'var(--accent)' }}>{user.role}</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
