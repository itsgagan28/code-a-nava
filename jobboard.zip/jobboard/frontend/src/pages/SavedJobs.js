import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getMe, saveJob } from '../utils/api';
import { useAuth } from '../context/AuthContext';
import JobCard from '../components/JobCard';
import toast from 'react-hot-toast';

export default function SavedJobs() {
  const { user, setUser } = useAuth();
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getMe().then(res => {
      setJobs(res.data.user.savedJobs || []);
      setLoading(false);
    });
  }, []);

  const handleUnsave = async (jobId) => {
    try {
      await saveJob(jobId);
      setJobs(prev => prev.filter(j => j._id !== jobId));
      toast.success('Job removed from saved');
    } catch {
      toast.error('Failed to unsave');
    }
  };

  if (loading) return <div className="page-container" style={{ textAlign: 'center', paddingTop: 80 }}>Loading...</div>;

  return (
    <div className="page-container">
      <h1 className="section-title">Saved Jobs ({jobs.length})</h1>
      {jobs.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: 48 }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>🔖</div>
          <h3>No saved jobs yet</h3>
          <p style={{ color: 'var(--muted)', marginBottom: 20 }}>Browse jobs and save the ones you like</p>
          <Link to="/jobs"><button className="btn-primary">Browse Jobs</button></Link>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 16 }}>
          {jobs.map(job => (
            <JobCard key={job._id} job={job} saved={true} onSave={handleUnsave} />
          ))}
        </div>
      )}
    </div>
  );
}
