import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getMyApplications, withdrawApplication } from '../utils/api';
import { formatDistanceToNow } from 'date-fns';
import toast from 'react-hot-toast';

const STATUS_BADGE = { pending: 'badge-yellow', reviewing: 'badge-blue', shortlisted: 'badge-green', rejected: 'badge-red', hired: 'badge-green' };

export default function Applications() {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getMyApplications().then(res => { setApplications(res.data.applications); setLoading(false); });
  }, []);

  const handleWithdraw = async (id) => {
    if (!window.confirm('Withdraw this application?')) return;
    try {
      await withdrawApplication(id);
      setApplications(prev => prev.filter(a => a._id !== id));
      toast.success('Application withdrawn');
    } catch {
      toast.error('Failed to withdraw');
    }
  };

  if (loading) return <div className="page-container" style={{ textAlign: 'center', paddingTop: 80 }}>Loading...</div>;

  return (
    <div className="page-container">
      <h1 className="section-title">My Applications ({applications.length})</h1>
      {applications.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: 48 }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>📬</div>
          <h3>No applications yet</h3>
          <p style={{ color: 'var(--muted)', marginBottom: 20 }}>Start applying to your dream jobs!</p>
          <Link to="/jobs"><button className="btn-primary">Browse Jobs</button></Link>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {applications.map(app => (
            <div key={app._id} className="card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 16 }}>{app.job?.title || 'Job Removed'}</div>
                <div style={{ color: 'var(--muted)', fontSize: 13, marginBottom: 8 }}>
                  {app.job?.companyName} · {app.job?.location} · {formatDistanceToNow(new Date(app.appliedAt), { addSuffix: true })}
                </div>
                {app.employerNotes && (
                  <div style={{ background: 'var(--surface2)', padding: '8px 12px', borderRadius: 6, fontSize: 13, color: 'var(--muted)' }}>
                    💬 {app.employerNotes}
                  </div>
                )}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <span className={`badge ${STATUS_BADGE[app.status] || 'badge-gray'}`}>{app.status}</span>
                {app.job?._id && <Link to={`/jobs/${app.job._id}`}><button className="btn-secondary" style={{ padding: '6px 12px', fontSize: 13 }}>View</button></Link>}
                {app.status === 'pending' && (
                  <button className="btn-danger" onClick={() => handleWithdraw(app._id)}>Withdraw</button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
