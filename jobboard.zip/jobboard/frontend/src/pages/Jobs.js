import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { getJobs, saveJob } from '../utils/api';
import { useAuth } from '../context/AuthContext';
import JobCard from '../components/JobCard';
import toast from 'react-hot-toast';
import './Jobs.css';

const CATEGORIES = ['', 'technology', 'marketing', 'design', 'finance', 'healthcare', 'education', 'sales', 'operations', 'hr', 'other'];
const JOB_TYPES = ['', 'full-time', 'part-time', 'contract', 'internship', 'remote'];
const EXP_LEVELS = ['', 'entry', 'mid', 'senior', 'lead', 'executive'];

export default function Jobs() {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [pages, setPages] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [savedJobIds, setSavedJobIds] = useState([]);
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();

  const [filters, setFilters] = useState({
    search: searchParams.get('search') || '',
    category: searchParams.get('category') || '',
    jobType: '',
    experienceLevel: '',
    location: '',
  });

  useEffect(() => {
    if (user?.savedJobs) setSavedJobIds(user.savedJobs.map(j => j._id || j));
  }, [user]);

  const fetchJobs = async (page = 1) => {
    setLoading(true);
    try {
      const params = { ...filters, page, limit: 9 };
      Object.keys(params).forEach(k => !params[k] && delete params[k]);
      const res = await getJobs(params);
      setJobs(res.data.jobs);
      setTotal(res.data.total);
      setPages(res.data.pages);
      setCurrentPage(res.data.currentPage);
    } catch {
      toast.error('Failed to load jobs');
    }
    setLoading(false);
  };

  useEffect(() => { fetchJobs(1); }, [filters]);

  const handleFilter = (key, value) => setFilters(prev => ({ ...prev, [key]: value }));

  const handleSearch = (e) => {
    e.preventDefault();
    fetchJobs(1);
  };

  const handleSave = async (jobId) => {
    if (!user) return toast.error('Please login to save jobs');
    try {
      const res = await saveJob(jobId);
      if (res.data.saved) {
        setSavedJobIds(prev => [...prev, jobId]);
        toast.success('Job saved!');
      } else {
        setSavedJobIds(prev => prev.filter(id => id !== jobId));
        toast.success('Job unsaved');
      }
    } catch {
      toast.error('Failed to save job');
    }
  };

  return (
    <div className="jobs-page page-container">
      <div className="jobs-layout">
        {/* Filters sidebar */}
        <aside className="filters-panel card">
          <h3 className="filter-title">Filters</h3>

          <form onSubmit={handleSearch} className="form-group">
            <input
              placeholder="Search jobs..."
              value={filters.search}
              onChange={e => handleFilter('search', e.target.value)}
            />
          </form>

          <div className="form-group">
            <label>Location</label>
            <input placeholder="City or remote" value={filters.location} onChange={e => handleFilter('location', e.target.value)} />
          </div>

          <div className="form-group">
            <label>Category</label>
            <select value={filters.category} onChange={e => handleFilter('category', e.target.value)}>
              {CATEGORIES.map(c => <option key={c} value={c}>{c || 'All Categories'}</option>)}
            </select>
          </div>

          <div className="form-group">
            <label>Job Type</label>
            <select value={filters.jobType} onChange={e => handleFilter('jobType', e.target.value)}>
              {JOB_TYPES.map(t => <option key={t} value={t}>{t || 'All Types'}</option>)}
            </select>
          </div>

          <div className="form-group">
            <label>Experience Level</label>
            <select value={filters.experienceLevel} onChange={e => handleFilter('experienceLevel', e.target.value)}>
              {EXP_LEVELS.map(l => <option key={l} value={l}>{l || 'All Levels'}</option>)}
            </select>
          </div>

          <button className="btn-secondary" style={{ width: '100%' }} onClick={() => setFilters({ search: '', category: '', jobType: '', experienceLevel: '', location: '' })}>
            Clear Filters
          </button>
        </aside>

        {/* Job listing */}
        <main className="jobs-main">
          <div className="jobs-header">
            <h2>{total} Jobs Found</h2>
          </div>

          {loading ? (
            <div className="loading-state">Loading jobs...</div>
          ) : jobs.length === 0 ? (
            <div className="empty-state card">
              <div style={{ fontSize: 48 }}>🔍</div>
              <h3>No jobs found</h3>
              <p>Try adjusting your filters</p>
            </div>
          ) : (
            <div className="jobs-grid">
              {jobs.map(job => (
                <JobCard
                  key={job._id}
                  job={job}
                  saved={savedJobIds.includes(job._id)}
                  onSave={user?.role === 'candidate' ? handleSave : null}
                />
              ))}
            </div>
          )}

          {pages > 1 && (
            <div className="pagination">
              <button className="btn-secondary" disabled={currentPage === 1} onClick={() => fetchJobs(currentPage - 1)}>← Prev</button>
              <span>Page {currentPage} of {pages}</span>
              <button className="btn-secondary" disabled={currentPage === pages} onClick={() => fetchJobs(currentPage + 1)}>Next →</button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
