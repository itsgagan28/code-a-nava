import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createJob } from '../utils/api';
import toast from 'react-hot-toast';
import './PostJob.css';

const CATEGORIES = ['technology', 'marketing', 'design', 'finance', 'healthcare', 'education', 'sales', 'operations', 'hr', 'other'];
const JOB_TYPES = ['full-time', 'part-time', 'contract', 'internship', 'remote'];
const EXP_LEVELS = ['entry', 'mid', 'senior', 'lead', 'executive'];

export default function PostJob() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    title: '', description: '', requirements: '', location: '',
    jobType: 'full-time', category: 'technology', experienceLevel: 'mid',
    salaryMin: '', salaryMax: '', salaryPeriod: 'yearly',
    skills: '', applicationDeadline: ''
  });

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = {
        title: form.title, description: form.description, requirements: form.requirements,
        location: form.location, jobType: form.jobType, category: form.category,
        experienceLevel: form.experienceLevel,
        skills: form.skills ? form.skills.split(',').map(s => s.trim()).filter(Boolean) : [],
        salary: form.salaryMin ? { min: +form.salaryMin, max: form.salaryMax ? +form.salaryMax : undefined, period: form.salaryPeriod } : undefined,
        applicationDeadline: form.applicationDeadline || undefined
      };
      await createJob(data);
      toast.success('Job posted successfully! 🎉');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to post job');
    }
    setLoading(false);
  };

  return (
    <div className="page-container">
      <h1 className="section-title">Post a New Job</h1>
      <div className="post-job-card card">
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Job Title *</label>
            <input name="title" placeholder="e.g. Senior React Developer" value={form.title} onChange={handleChange} required />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Category *</label>
              <select name="category" value={form.category} onChange={handleChange}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label>Job Type *</label>
              <select name="jobType" value={form.jobType} onChange={handleChange}>
                {JOB_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Location *</label>
              <input name="location" placeholder="e.g. New York, NY or Remote" value={form.location} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Experience Level</label>
              <select name="experienceLevel" value={form.experienceLevel} onChange={handleChange}>
                {EXP_LEVELS.map(l => <option key={l} value={l}>{l}</option>)}
              </select>
            </div>
          </div>

          <div className="form-group">
            <label>Description *</label>
            <textarea name="description" rows={6} placeholder="Describe the role, responsibilities, and your team..." value={form.description} onChange={handleChange} required />
          </div>

          <div className="form-group">
            <label>Requirements</label>
            <textarea name="requirements" rows={4} placeholder="List the qualifications and requirements..." value={form.requirements} onChange={handleChange} />
          </div>

          <div className="form-group">
            <label>Skills (comma separated)</label>
            <input name="skills" placeholder="React, Node.js, TypeScript..." value={form.skills} onChange={handleChange} />
          </div>

          <div className="form-row form-row-3">
            <div className="form-group">
              <label>Min Salary</label>
              <input type="number" name="salaryMin" placeholder="50000" value={form.salaryMin} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label>Max Salary</label>
              <input type="number" name="salaryMax" placeholder="80000" value={form.salaryMax} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label>Period</label>
              <select name="salaryPeriod" value={form.salaryPeriod} onChange={handleChange}>
                <option value="yearly">Yearly</option>
                <option value="monthly">Monthly</option>
                <option value="hourly">Hourly</option>
              </select>
            </div>
          </div>

          <div className="form-group">
            <label>Application Deadline</label>
            <input type="date" name="applicationDeadline" value={form.applicationDeadline} onChange={handleChange} />
          </div>

          <button type="submit" className="btn-primary" style={{ width: '100%', padding: '14px' }} disabled={loading}>
            {loading ? 'Posting...' : 'Post Job'}
          </button>
        </form>
      </div>
    </div>
  );
}
