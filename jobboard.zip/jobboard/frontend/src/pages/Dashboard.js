import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getMyJobs, getMyApplications } from '../utils/api';
import './Dashboard.css';

export default function Dashboard() {
  const { user } = useAuth();
  const [myJobs, setMyJobs] = useState([]);
  const [myApplications, setMyApplications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        if (user.role === 'employer') {
          const res = await getMyJobs();
          setMyJobs(res.data.jobs);
        } else {
          const res = await getMyApplications();
          setMyApplications(res.data.applications);
        }
      } catch {}
      setLoading(false);
    };
    load();
  }, [user]);

  const statusBadge = (status) => {
    const map = { pending: 'badge-yellow', reviewing: 'badge-blue', shortlisted: 'badge-green', rejected: 'badge-red', hired: 'badge-green' };
    return map[status] || 'badge-gray';
  };

  if (loading) return <div className="page-container" style={{ textAlign: 'center', paddingTop: 80 }}>Loading...</div>;

  return (
    <div className="page-container">
      <div className="dashboard-welcome">
        <div>
          <h1>Welcome back, {user.name.split(' ')[0]} 👋</h1>
          <p style={{ color: 'var(--muted)' }}>{user.role === 'employer' ? `Managing jobs for ${user.companyName}` : 'Track your job search progress'}</p>
        </div>
        {user.role === 'employer' ? (
          <Link to="/post-job"><button className="btn-primary">+ Post New Job</button></Link>
        ) : (
          <Link to="/jobs"><button className="btn-primary">Browse Jobs</button></Link>
        )}
      </div>

      {user.role === 'employer' ? (
        <div>
          <h2 className="section-title">My Job Postings ({myJobs.length})</h2>
          {myJobs.length === 0 ? (
            <div className="card" style={{ textAlign: 'center', padding: 48 }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>📋</div>
              <h3>No job postings yet</h3>
              <p style={{ color: 'var(--muted)', marginBottom: 20 }}>Create your first job listing</p>
              <Link to="/post-job"><button className="btn-primary">Post a Job</button></Link>
            </div>
          ) : (
            <div className="employer-jobs-list">
              {myJobs.map(job => (
                <div key={job._id} className="employer-job-row card">
                  <div className="ejr-info">
                    <div className="ejr-title">{job.title}</div>
                    <div className="ejr-meta">
                      <span className={`badge ${job.isActive ? 'badge-green' : 'badge-red'}`}>{job.isActive ? 'Active' : 'Inactive'}</span>
                      <span className="badge badge-gray">{job.jobType}</span>
                      <span style={{ color: 'var(--muted)', fontSize: 13 }}>👥 {job.applicationsCount} applicants</span>
                      <span style={{ color: 'var(--muted)', fontSize: 13 }}>👁 {job.views} views</span>
                    </div>
                  </div>
                  <div className="ejr-actions">
                    <Link to={`/manage-applications/${job._id}`}><button className="btn-secondary">View Applications</button></Link>
                    <Link to={`/edit-job/${job._id}`}><button className="btn-secondary">Edit</button></Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        <div>
          <h2 className="section-title">My Applications ({myApplications.length})</h2>
          {myApplications.length === 0 ? (
            <div className="card" style={{ textAlign: 'center', padding: 48 }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>🎯</div>
              <h3>No applications yet</h3>
              <p style={{ color: 'var(--muted)', marginBottom: 20 }}>Start applying to jobs</p>
              <Link to="/jobs"><button className="btn-primary">Browse Jobs</button></Link>
            </div>
          ) : (
            <div className="applications-list">
              {myApplications.slice(0, 5).map(app => (
                <div key={app._id} className="application-row card">
                  <div>
                    <div style={{ fontWeight: 600 }}>{app.job?.title || 'Job Removed'}</div>
                    <div style={{ color: 'var(--muted)', fontSize: 13 }}>{app.job?.companyName} · {app.job?.location}</div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <span className={`badge ${statusBadge(app.status)}`}>{app.status}</span>
                    {app.job?._id && <Link to={`/jobs/${app.job._id}`} style={{ fontSize: 13 }}>View Job →</Link>}
                  </div>
                </div>
              ))}
              {myApplications.length > 5 && (
                <Link to="/my-applications" style={{ display: 'block', textAlign: 'center', marginTop: 12 }}>
                  View all {myApplications.length} applications →
                </Link>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
