import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Home.css';

const CATEGORIES = ['Technology', 'Marketing', 'Design', 'Finance', 'Healthcare', 'Education', 'Sales', 'Operations'];

export default function Home() {
  const [search, setSearch] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    navigate(`/jobs?search=${encodeURIComponent(search)}`);
  };

  return (
    <div className="home">
      {/* Hero */}
      <section className="hero">
        <div className="hero-glow" />
        <div className="hero-content">
          <div className="hero-badge badge badge-accent">🚀 100+ new jobs this week</div>
          <h1 className="hero-title">
            Find Your<br />
            <span className="gradient-text">Dream Career</span>
          </h1>
          <p className="hero-subtitle">
            Connect with top employers. Upload your resume, track applications, and land your next role.
          </p>
          <form className="search-bar" onSubmit={handleSearch}>
            <input
              type="text"
              placeholder="Search jobs, companies, skills..."
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
            <button type="submit" className="btn-primary">Search Jobs</button>
          </form>
          <div className="hero-stats">
            <div className="stat"><span className="stat-num">10K+</span><span>Active Jobs</span></div>
            <div className="stat-divider" />
            <div className="stat"><span className="stat-num">5K+</span><span>Companies</span></div>
            <div className="stat-divider" />
            <div className="stat"><span className="stat-num">50K+</span><span>Candidates</span></div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="categories-section page-container">
        <h2 className="section-title">Browse by Category</h2>
        <div className="categories-grid">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              className="category-card"
              onClick={() => navigate(`/jobs?category=${cat.toLowerCase()}`)}
            >
              <span className="category-name">{cat}</span>
            </button>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="cta-section page-container">
        <div className="cta-grid">
          <div className="cta-card cta-employer card">
            <div className="cta-icon">🏢</div>
            <h3>Hiring Talent?</h3>
            <p>Post jobs and reach thousands of qualified candidates instantly.</p>
            <a href="/register"><button className="btn-primary">Post a Job</button></a>
          </div>
          <div className="cta-card cta-candidate card">
            <div className="cta-icon">🎯</div>
            <h3>Looking for Work?</h3>
            <p>Create your profile, upload your resume, and apply with one click.</p>
            <a href="/register"><button className="btn-primary">Get Started</button></a>
          </div>
        </div>
      </section>
    </div>
  );
}
