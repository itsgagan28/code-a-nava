import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getJobApplications, updateApplicationStatus, getJob } from '../utils/api';
import { formatDistanceToNow } from 'date-fns';
import toast from 'react-hot-toast';

const STATUSES = ['pending', 'reviewing', 'shortlisted', 'rejected', 'hired'];
const STATUS_BADGE = { pending: 'badge-yellow', reviewing: 'badge-blue', shortlisted: 'badge-green', rejected: 'badge-red', hired: 'badge-green' };

export default function ManageApplications() {
  const { jobId } = useParams();
  const navigate = useNavigate();
  const [applications, setApplications] = useState([]);
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    Promise.all([getJobApplications(jobId), getJob(jobId)]).then(([appRes, jobRes]) => {
      setApplications(appRes.data.applications);
      setJob(jobRes.data.job);
      setLoading(false);
    }).catch(() => navigate('/dashboard'));
  }, [jobId]);

  const handleStatusChange = async (appId, status, notes) => {
    try {
      const res = await updateApplicationStatus(appId, { status, employerNotes: notes });
      setApplications(prev => prev.map(a => a._id === appId ? { ...a, status, employerNotes: notes } : a));
      toast.success('Status updated');
    } catch {
      toast.error('Failed to update status');
    }
  };

  const filtered = filter === 'all' ? applications : applications.filter(a => a.status === filter);

  if (loading) return <div className="page-container" style={{ textAlign: 'center', paddingTop: 80 }}>Loading...</div>;

  return (
    <div className="page-container">
      <button className="btn-secondary" onClick={() => navigate('/dashboard')} style={{ marginBottom: 20 }}>← Back</button>
      <h1 className="section-title">{job?.title} — Applications</h1>
      <div style={{ color: 'var(--muted)', marginBottom: 24 }}>{applications.length} total applicants</div>

      {/* Filter tabs */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap' }}>
        {['all', ...STATUSES].map(s => (
          <button key={s} onClick={() => setFilter(s)}
            className={filter === s ? 'btn-primary' : 'btn-secondary'}
            style={{ padding: '6px 14px', fontSize: 13 }}>
            {s} {s === 'all' ? `(${applications.length})` : `(${applications.filter(a => a.status === s).length})`}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: 40 }}>No applications with this status</div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {filtered.map(app => (
            <ApplicationCard key={app._id} app={app} onUpdate={handleStatusChange} />
          ))}
        </div>
      )}
    </div>
  );
}

function ApplicationCard({ app, onUpdate }) {
  const [expanded, setExpanded] = useState(false);
  const [notes, setNotes] = useState(app.employerNotes || '');
  const [status, setStatus] = useState(app.status);

  const STATUS_BADGE = { pending: 'badge-yellow', reviewing: 'badge-blue', shortlisted: 'badge-green', rejected: 'badge-red', hired: 'badge-green' };

  return (
    <div className="card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <div style={{ fontWeight: 600, fontSize: 16 }}>{app.candidate?.name}</div>
          <div style={{ color: 'var(--muted)', fontSize: 13 }}>
            {app.candidate?.email} · Applied {formatDistanceToNow(new Date(app.appliedAt), { addSuffix: true })}
          </div>
          {app.candidate?.location && <div style={{ color: 'var(--muted)', fontSize: 13 }}>📍 {app.candidate.location}</div>}
          {app.candidate?.skills?.length > 0 && (
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 8 }}>
              {app.candidate.skills.map(s => <span key={s} className="badge badge-accent">{s}</span>)}
            </div>
          )}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span className={`badge ${STATUS_BADGE[app.status]}`}>{app.status}</span>
          <button className="btn-secondary" style={{ padding: '6px 12px', fontSize: 13 }} onClick={() => setExpanded(!expanded)}>
            {expanded ? 'Collapse' : 'Manage'}
          </button>
          {app.candidate?.resume?.url && (
            <a href={app.candidate.resume.url} target="_blank" rel="noreferrer">
              <button className="btn-secondary" style={{ padding: '6px 12px', fontSize: 13 }}>📄 Resume</button>
            </a>
          )}
        </div>
      </div>

      {app.coverLetter && (
        <div style={{ marginTop: 12, padding: '12px', background: 'var(--surface2)', borderRadius: 8, fontSize: 14, color: 'var(--muted)', fontStyle: 'italic' }}>
          "{app.coverLetter}"
        </div>
      )}

      {expanded && (
        <div style={{ marginTop: 16, borderTop: '1px solid var(--border)', paddingTop: 16 }}>
          <div className="form-row">
            <div className="form-group">
              <label>Update Status</label>
              <select value={status} onChange={e => setStatus(e.target.value)}>
                {['pending', 'reviewing', 'shortlisted', 'rejected', 'hired'].map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label>Notes for Candidate</label>
              <input value={notes} onChange={e => setNotes(e.target.value)} placeholder="Optional notes..." />
            </div>
          </div>
          <button className="btn-primary" onClick={() => onUpdate(app._id, status, notes)}>Save Changes</button>
        </div>
      )}
    </div>
  );
}
