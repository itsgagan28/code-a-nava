import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import './index.css';

import Navbar from './components/Navbar';
import Home from './pages/Home';
import Jobs from './pages/Jobs';
import JobDetail from './pages/JobDetail';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import PostJob from './pages/PostJob';
import EditJob from './pages/EditJob';
import Profile from './pages/Profile';
import Applications from './pages/Applications';
import ManageApplications from './pages/ManageApplications';
import SavedJobs from './pages/SavedJobs';

const PrivateRoute = ({ children, role }) => {
  const { user, loading } = useAuth();
  if (loading) return <div className="page-container" style={{ textAlign: 'center', paddingTop: 80 }}>Loading...</div>;
  if (!user) return <Navigate to="/login" />;
  if (role && user.role !== role) return <Navigate to="/dashboard" />;
  return children;
};

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Toaster position="top-right" toastOptions={{
          style: { background: '#1a1c28', color: '#f0f0f8', border: '1px solid #252736' }
        }} />
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/jobs" element={<Jobs />} />
          <Route path="/jobs/:id" element={<JobDetail />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
          <Route path="/profile" element={<PrivateRoute><Profile /></PrivateRoute>} />
          <Route path="/my-applications" element={<PrivateRoute role="candidate"><Applications /></PrivateRoute>} />
          <Route path="/saved-jobs" element={<PrivateRoute role="candidate"><SavedJobs /></PrivateRoute>} />
          <Route path="/post-job" element={<PrivateRoute role="employer"><PostJob /></PrivateRoute>} />
          <Route path="/edit-job/:id" element={<PrivateRoute role="employer"><EditJob /></PrivateRoute>} />
          <Route path="/manage-applications/:jobId" element={<PrivateRoute role="employer"><ManageApplications /></PrivateRoute>} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
